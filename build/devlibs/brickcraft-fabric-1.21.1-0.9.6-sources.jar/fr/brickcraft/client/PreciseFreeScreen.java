package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.PreciseFreeAssembly;
import fr.brickcraft.importer.PreciseProjectIO;
import fr.brickcraft.ldraw.LDrawLibrary;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/** V0.9.6: precise in-game editor with live parent 3D preview, no integer grid. */
public final class PreciseFreeScreen extends Screen {
    private static final double[] MOVE_STEPS={20,8,4,1,.25};
    private static final double[] ANGLE_STEPS={90,45,15,5,1,.25};
    private final ProjectImportScreen preview;
    private final PreciseFreeAssembly assembly;
    private final String filename;
    private TextFieldWidget partId,color,x,y,z,index,moveInput,angleInput;
    private ButtonWidget moveStepButton,angleStepButton;
    private int moveStep=0,angleStep=0;
    private String status="Selectionne une piece, ou ajoute-en une avec sa reference LDraw.";
    private boolean dirty=false;

    public PreciseFreeScreen(ProjectImportScreen preview,LDrawProjectReader.Result source,String filename){
        super(Text.literal("BrickCraft - Placement libre V0.9.6"));
        this.preview=preview;
        this.assembly=new PreciseFreeAssembly(source);
        this.filename=filename;
    }
    private void button(int x,int y,int w,int h,String text,Runnable callback){
        addDrawableChild(ButtonWidget.builder(Text.literal(text),b->callback.run()).dimensions(x,y,w,h).build());
    }
    private TextFieldWidget field(int x,int y,int w,String placeholder,int length){
        TextFieldWidget f=new TextFieldWidget(textRenderer,x,y,w,18,Text.literal(placeholder));
        f.setMaxLength(length);addDrawableChild(f);return f;
    }
    @Override protected void init(){
        int w=Math.min(418,Math.max(325,width*2/5));
        int left=10, usable=w-20;
        int quarter=(usable-12)/4,third=(usable-10)/3;
        button(left,39,quarter,19,"< Piece",()->pick(-1));
        button(left+quarter+4,39,quarter,19,"Piece >",()->pick(1));
        index=field(left+2*(quarter+4),39,quarter,"Numero",8);
        button(left+3*(quarter+4),39,quarter,19,"Aller",this::jump);
        partId=field(left,86,usable-115,"ID LDraw / 3005",96);
        color=field(left+usable-108,86,108,"Couleur",8);
        int fy=127;
        x=field(left,fy,third,"LDU X",24);
        y=field(left+third+5,fy,third,"LDU Y",24);
        z=field(left+(third+5)*2,fy,third,"LDU Z",24);
        int half=usable/2-3;
        moveStepButton=addDrawableChild(ButtonWidget.builder(Text.literal("Pas pos. >"),b->{
            moveStep=(moveStep+1)%MOVE_STEPS.length;updateStepTexts();
        }).dimensions(left,166,82,18).build());
        moveInput=field(left+86,166,half-87,"LDU",20);
        angleStepButton=addDrawableChild(ButtonWidget.builder(Text.literal("Pas rot. >"),b->{
            angleStep=(angleStep+1)%ANGLE_STEPS.length;updateStepTexts();
        }).dimensions(left+usable/2+3,166,82,18).build());
        angleInput=field(left+usable/2+89,166,half-87,"Degres",20);
        updateStepTexts();
        int ay=195;
        for(int c=0;c<3;c++){
            PreciseFreeAssembly.Axis axis=PreciseFreeAssembly.Axis.values()[c];
            int px=left+c*(third+5);
            button(px,ay,third/2-2,19,""+axis+" -",()->stepMove(axis,-1));
            button(px+third/2+2,ay,third/2-2,19,""+axis+" +",()->stepMove(axis,1));
            button(px,ay+27,third/2-2,19,"R"+axis+" -",()->stepRotate(axis,-1));
            button(px+third/2+2,ay+27,third/2-2,19,"R"+axis+" +",()->stepRotate(axis,1));
        }
        button(left,259,usable/2-3,19,"Appliquer champs",this::applyFields);
        button(left+usable/2+3,259,usable/2-3,19,"Rotation 0",()->change(assembly.resetRotation(),"Rotation remise a zero"));
        button(left,286,third,19,"Ajouter",this::add);
        button(left+third+5,286,third,19,"Dupliquer",()->change(assembly.duplicate(),"Piece dupliquee"));
        button(left+(third+5)*2,286,third,19,"Supprimer",()->change(assembly.delete(),"Piece supprimee"));
        button(left,316,usable/2-3,19,"Annuler",()->change(assembly.undo(),"Annulation"));
        button(left+usable/2+3,316,usable/2-3,19,"Retablir",()->change(assembly.redo(),"Retablissement"));
        button(left,Math.max(342,height-61),usable,19,"Enregistrer un nouveau .bcpx",this::save);
        button(left,Math.max(366,height-36),usable,19,"Retour a l'apercu / projection",()->client.setScreen(preview));
        refreshFields();
    }
    private void updateStepTexts(){
        moveInput.setText(fmt(MOVE_STEPS[moveStep]));
        angleInput.setText(fmt(ANGLE_STEPS[angleStep]));
    }
    private static String fmt(double v){return v==(long)v?Long.toString((long)v):Double.toString(v);}
    private static double stepValue(TextFieldWidget field,double max){
        double value=Double.parseDouble(field.getText().strip().replace(',','.'));
        if(!Double.isFinite(value)||value<=0||value>max)throw new IllegalArgumentException("Pas requis entre 0 et "+max);
        return value;
    }
    private void refreshFields(){
        var p=assembly.selected();
        index.setText(assembly.selectedIndex()<0?"-":Integer.toString(assembly.selectedIndex()+1));
        if(p==null){partId.setText("3005");color.setText("4");x.setText("0");y.setText("0");z.setText("0");}
        else {partId.setText(p.partId());color.setText(Integer.toString(p.color()));
            x.setText(fmt(p.x()));y.setText(fmt(p.y()));z.setText(fmt(p.z()));}
    }
    private void pick(int dir){
        if(assembly.size()==0){status="Aucune piece. Utilise Ajouter.";return;}
        assembly.select(Math.floorMod(assembly.selectedIndex()+dir,assembly.size()));refreshFields();
    }
    private void jump(){
        try{if(!assembly.select(Integer.parseInt(index.getText())-1))throw new IllegalArgumentException();refreshFields();}
        catch(Exception ex){status="Numero invalide : entre une valeur entre 1 et "+assembly.size();}
    }
    private LDrawProjectReader.Instance fromFields(double[] mat){
        return new LDrawProjectReader.Instance(partId.getText().strip().replace(".dat", ""),
                Integer.parseInt(color.getText().strip()),Double.parseDouble(x.getText().strip().replace(',','.')),
                Double.parseDouble(y.getText().strip().replace(',','.')),
                Double.parseDouble(z.getText().strip().replace(',','.')),mat);
    }
    private void applyFields(){
        try{var p=assembly.selected();
            if(p==null){status="Aucune piece selectionnee : utilise Ajouter";return;}
            change(assembly.replace(fromFields(p.matrix())),"Modifications appliquees");
        }catch(Exception ex){status="Champs invalides : "+ex.getMessage();}
    }
    private void add(){
        try{change(assembly.add(fromFields(PreciseFreeAssembly.identity())),"Piece ajoutee (rotation initiale 0 deg)");}
        catch(Exception ex){status="Ajout refuse : "+ex.getMessage();}
    }
    private void stepMove(PreciseFreeAssembly.Axis axis,int direction){
        try{change(assembly.move(axis,direction*stepValue(moveInput,1000)),"Deplacement "+axis+" de "+fmt(direction*stepValue(moveInput,1000))+" LDU");}
        catch(Exception ex){status="Deplacement refuse : "+ex.getMessage();}
    }
    private void stepRotate(PreciseFreeAssembly.Axis axis,int direction){
        try{change(assembly.rotate(axis,direction*stepValue(angleInput,360)),"Rotation "+axis+" de "+fmt(direction*stepValue(angleInput,360))+" deg");}
        catch(Exception ex){status="Rotation refusee : "+ex.getMessage();}
    }
    private void change(boolean success,String message){
        if(!success){status="Aucune piece selectionnee";return;}
        dirty=true;refreshFields();preview.applyFreeEdits(assembly.result());
        status=message+" | "+assembly.size()+" pieces";
    }
    private void save(){
        if(assembly.size()==0){status="Ajoute au moins une piece avant de sauver";return;}
        try{
            Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
            Files.createDirectories(folder);
            String stem=filename.replaceAll("(?i)\\.(io|ldr|mpd|bcpx)$","").replaceAll("[^a-zA-Z0-9_-]","_");
            if(stem.isEmpty())stem="atelier";
            Path dest=folder.resolve(stem+"_free_v096.bcpx");
            int suffix=2;
            while(Files.exists(dest)){dest=folder.resolve(stem+"_free_v096_"+(suffix++)+".bcpx");}
            PreciseProjectIO.save(dest,assembly.result());dirty=false;
            status="Sauvegarde : "+dest.getFileName()+" (source intacte)";
            preview.refreshFreeFiles(dest);
        }catch(Exception ex){status="Erreur de sauvegarde : "+ex.getMessage();}
    }
    @Override public void renderBackground(DrawContext draw,int mx,int my,float delta){}
    @Override public void render(DrawContext draw,int mx,int my,float delta){
        // Reuse the source-accurate LDraw mesh preview rather than approximating the edited
        // part as a voxel. The parent's widgets render behind this opaque editor panel.
        preview.render(draw,mx,my,delta);
        int w=Math.min(418,Math.max(325,width*2/5));
        draw.fill(3,27,w+2,height-6,0xF4172636);
        draw.fill(3,27,w+2,30,0xFF55CFD8);
        draw.drawTextWithShadow(textRenderer,"BRICKCRAFT / PLACEMENT LIBRE 0.9.6",10,10,0xFFE7F8FF);
        draw.drawTextWithShadow(textRenderer,"Piece "+(assembly.selectedIndex()+1)+" / "+assembly.size()+
                (dirty?"  * Non enregistre":""),10,64,0xFF9DE4E3);
        draw.drawTextWithShadow(textRenderer,"Reference / code couleur",10,75,0xFFC0CEDA);
        draw.drawTextWithShadow(textRenderer,"Origine LDraw : X / Y / Z (decimales)",10,112,0xFFC0CEDA);
        draw.drawTextWithShadow(textRenderer,"1 stud = 20 LDU  |  1 plate = 8 LDU",10,151,0xFFE7C98F);
        if(height>435){
            draw.drawTextWithShadow(textRenderer,"Positions libres - aucune grille Minecraft",10,349,0xFF9ABBC9);
            draw.drawTextWithShadow(textRenderer,"Rotation sur la matrice 3D d'origine",10,361,0xFF9ABBC9);
            draw.drawTextWithShadow(textRenderer,"Ctrl+Z/Y : annuler/retablir  Ctrl+S : sauver",10,376,0xFF9ABBC9);
        }
        draw.fill(0,height-25,width,height,0xFF122334);
        String message=status;
        while(textRenderer.getWidth(message)>width-25 && message.length()>4)message=message.substring(0,message.length()-4)+"...";
        draw.drawTextWithShadow(textRenderer,message,10,height-18,0xFFFFDA91);
        super.render(draw,mx,my,delta);
    }
    @Override public boolean keyPressed(int key,int scancode,int modifiers){
        if((modifiers & GLFW.GLFW_MOD_CONTROL)!=0){
            if(key==GLFW.GLFW_KEY_Z){change(assembly.undo(),"Annulation");return true;}
            if(key==GLFW.GLFW_KEY_Y){change(assembly.redo(),"Retablissement");return true;}
            if(key==GLFW.GLFW_KEY_S){save();return true;}
            if(key==GLFW.GLFW_KEY_D){change(assembly.duplicate(),"Piece dupliquee");return true;}
        }
        if(key==GLFW.GLFW_KEY_ESCAPE){client.setScreen(preview);return true;}
        return super.keyPressed(key,scancode,modifiers);
    }
}
