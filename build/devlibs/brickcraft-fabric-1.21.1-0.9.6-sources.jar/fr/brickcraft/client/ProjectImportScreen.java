package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.StudioProjectAnalysis;
import fr.brickcraft.importer.BrickCraftProjectConverter;
import fr.brickcraft.importer.PreciseProjectIO;
import fr.brickcraft.importer.PreciseLDrawGeometry;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.net.PreciseExportPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import fr.brickcraft.ldraw.LDrawLibrary;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Direct .io/.mpd/.ldr loader, with lossless diagnostics and a source-coordinate preview. */
public final class ProjectImportScreen extends Screen {
    private final BrickStudioScreen parent;
    private final Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
    private List<Path> sources=List.of();
    private int index=0;
    private LDrawProjectReader.Result current;
    private StudioProjectAnalysis.Summary summary;
    private String status="Depose un fichier .io, .mpd ou .ldr dans le dossier imports.";
    private double orbit=.72, zoom=1.0, panX=0, panY=0;
    private boolean orbiting=false,panning=false;
    private int lastX,lastY;
    /** 0=points, 1=oriented bounding boxes, 2=actual LDraw triangles with adaptive LOD. */
    private int previewMode=2;
    // A bounded per-scene cache avoids decoding a huge .dat on every rendered frame.
    private final Map<String,LDrawLibrary.Mesh> meshes=new HashMap<>();
    private final Set<String> noMesh=new HashSet<>();
    private int cachedTriangles=0;
    private static final int MAX_CACHED_TRIANGLES=350_000;
    private static final int MAX_PART_TRIANGLES=2_500;
    private static final int MAX_RENDER_TRIANGLES=12_000;
    private int trianglesRendered=0;
    private int realMeshesRendered=0;
    private List<PreviewPart> previewParts=List.of();
    private double[] previewBounds=null; // min X/Y/Z, max X/Y/Z in original LDU
    private record PreviewPart(double[][] corners, int color, double depthX, double depthY, double depthZ,
                               LDrawProjectReader.Instance instance){}
    private record Dot(int x,int y,double depth,int color){}
    private record Pixel(int x,int y){}
    private record Face(Pixel[] verts,double depth,int color){}
    public ProjectImportScreen(BrickStudioScreen parent){
        super(Text.literal("BrickCraft - Importer un projet BrickLink"));
        this.parent=parent;
        reloadFiles();
    }
    private void reloadFiles(){
        try{
            Files.createDirectories(folder);
            try(var stream=Files.list(folder)){
                sources=stream.filter(Files::isRegularFile).filter(p->{
                    String n=p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".io")||n.endsWith(".mpd")||n.endsWith(".ldr")||n.endsWith(".bcpx");
                }).sorted(Comparator.comparing(p->p.getFileName().toString(),String.CASE_INSENSITIVE_ORDER)).limit(200).toList();
            }
            index=Math.min(Math.max(0,index),Math.max(0,sources.size()-1));
        }catch(IOException e){status="Lecture du dossier impossible : "+e.getMessage();sources=List.of();}
    }
    private Path selectedFile(){return sources.isEmpty()?null:sources.get(index);}
    private void select(int offset){
        if(sources.isEmpty())return;
        index=Math.floorMod(index+offset,sources.size());
        current=null;summary=null;previewParts=List.of();previewBounds=null;meshes.clear();noMesh.clear();cachedTriangles=0;
        status="Selection : "+selectedFile().getFileName();
    }
    private void analyze(){
        Path source=selectedFile();
        if(source==null){status="Aucun fichier. Copie ton .io dans config/brickcraft/imports/";return;}
        try{
            current=source.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".bcpx")?
                    PreciseProjectIO.read(source):LDrawProjectReader.inspect(source);
            summary=StudioProjectAnalysis.analyze(current);
            meshes.clear();noMesh.clear();cachedTriangles=0;
            buildPreview();
            status="Charge : "+summary.quickStatus()+" (points / volumes / maillages)";
            panX=panY=0;zoom=1;
            saveReport();
        }catch(Exception e){current=null;summary=null;previewParts=List.of();previewBounds=null;
            status="Erreur d'analyse : "+e.getMessage();}
    }
    private void savePrecise(){
        if(current==null||selectedFile()==null){status="Analyse d'abord un projet";return;}
        try {
            String original=selectedFile().getFileName().toString();
            String name=original.toLowerCase(Locale.ROOT).endsWith(".bcpx")?original:
                    original.replaceAll("[^a-zA-Z0-9._-]","_")+".bcpx";
            Path output=folder.resolve(name);
            PreciseProjectIO.save(output,current);
            status="Sauvegarde precise (sans arrondi) : "+name;
            reloadFiles();
        }catch(IOException e){status="BCPX : "+e.getMessage();}
    }
    private void cyclePreview(){previewMode=(previewMode+1)%3;clearAndInit();}
    private String modeName(){return switch(previewMode){case 0->"points";case 1->"volumes";default->"maillages";};}
    private void saveReport()throws IOException {
        if(summary==null || selectedFile()==null)return;
        String name=selectedFile().getFileName().toString().replaceAll("[^a-zA-Z0-9._-]","_");
        Path report=folder.resolve("reports").resolve(name+".diagnostic.txt");
        Files.createDirectories(report.getParent());
        Files.writeString(report,StudioProjectAnalysis.report(summary,selectedFile().getFileName().toString()));
    }
    private void convert(){
        if(current==null){status="Analyse d'abord le projet";return;}
        if(summary.missingInstances()>0 || summary.angled()>0){
            status="Import sans perte impossible : references manquantes ou rotations libres (voir rapport)";return;
        }
        try{
            BrickCraftProjectConverter.Conversion c=BrickCraftProjectConverter.convert(current);
            if(!c.success()){
                status="Conversion refusee : "+c.errors().get(0);
                return;
            }
            if(parent.acceptImportedProject(c.grid(),c.pieces())){
                client.setScreen(parent);
            }else status="Le Studio refuse ce projet (limites ou collisions)";
        }catch(Exception e){status="Conversion echouee : "+e.getMessage();}
    }
    /** Visual-only, server-validated BCPX projection. The classic solid-brick world is untouched. */
    private void projectWorld(){
        if(current==null){status="Analyse un projet avant de le projeter";return;}
        if(client.player==null || client.world==null || client.interactionManager==null ||
                !client.interactionManager.hasCreativeInventory()){
            status="Projection disponible uniquement en mode Creatif";return;
        }
        HitResult target=client.player.raycast(12.0,1.0f,false);
        if(!(target instanceof BlockHitResult hit) || target.getType()!=HitResult.Type.BLOCK){
            status="Vise un bloc au sol avant d'ouvrir le Studio";return;
        }
        BlockPos anchor=hit.getBlockPos().offset(hit.getSide());
        if(!client.world.getBlockState(anchor).isAir()){
            status="Espace d'ancrage occupe : vise une surface avec de l'air au-dessus";return;
        }
        try{
            var bounds=PreciseWorldModel.analyze(current.parts());
            if(anchor.getY()+bounds.height()+1>=client.world.getTopY()){
                status="Chateau trop haut pour cet endroit";return;
            }
            ClientPlayNetworking.send(PreciseExportPayload.begin(anchor,current.parts().size()));
            for(int offset=0;offset<current.parts().size();offset+=PreciseExportPayload.BATCH_SIZE){
                int end=Math.min(current.parts().size(),offset+PreciseExportPayload.BATCH_SIZE);
                ClientPlayNetworking.send(PreciseExportPayload.batch(offset,current.parts().subList(offset,end)));
            }
            ClientPlayNetworking.send(PreciseExportPayload.commit());
            status="Projection envoyee : "+current.parts().size()+" pieces, "+bounds.mappedPrints()+
                    " imprimees sans texture. Retourne en jeu pour voir le resultat.";
        }catch(Exception e){status="Projection refusee : "+e.getMessage();}
    }
    private void addButton(int x,int y,int w,int h,String label,Runnable click){
        if(w<16)return;
        addDrawableChild(ButtonWidget.builder(Text.literal(label),b->click.run()).dimensions(x,y,w,h).build());
    }
    /** V0.9.6: the advanced editor retains original doubles/matrices and reuses this preview. */
    private void openFreeEditor(){
        LDrawProjectReader.Result source=current!=null?current:
                new LDrawProjectReader.Result("brickcraft_free.ldr",0,List.of(),List.of());
        String file=selectedFile()==null?"atelier.ldr":selectedFile().getFileName().toString();
        if(source.parts().size()>PreciseWorldModel.MAX_PARTS){
            status="Editeur libre limite a 4096 pieces; utilise un sous-modele.";return;
        }
        client.setScreen(new PreciseFreeScreen(this,source,file));
    }
    void applyFreeEdits(LDrawProjectReader.Result result){
        current=result;
        // Keep LDraw preview meshes cached when only one transform changes.
        if(current.parts().isEmpty()){summary=null;previewParts=List.of();previewBounds=null;return;}
        summary=StudioProjectAnalysis.analyze(current);
        buildPreview();
        status="Atelier libre : "+current.parts().size()+" pieces (modifications non enregistrees)";
    }
    void refreshFreeFiles(Path destination){
        reloadFiles();
        int found=sources.indexOf(destination);
        if(found>=0)index=found;
    }
    @Override protected void init(){
        int pWidth=Math.max(228,Math.min(315,width/3));
        addButton(10,40,(pWidth-25)/2,20,"< Projet",()->select(-1));
        addButton((pWidth+5)/2,40,(pWidth-25)/2,20,"Projet >",()->select(1));
        addButton(10,67,pWidth-20,20,"Actualiser les fichiers",()->{reloadFiles();status="Dossier actualise";});
        addButton(10,93,pWidth-20,20,"1. Analyser / previsualiser",this::analyze);
        addButton(10,120,pWidth-20,20,"2. Importer dans le Studio (strict)",this::convert);
        addButton(10,145,pWidth-20,18,"Apercu : "+modeName()+" (V)",this::cyclePreview);
        addButton(10,167,pWidth-20,19,"EDITEUR LIBRE 0.9.6",this::openFreeEditor);
        addButton(10,190,pWidth-20,18,"Sauvegarder precision (.bcpx)",this::savePrecise);
        addButton(10,211,pWidth-20,19,"3. Projeter dans le monde (BETA)",this::projectWorld);
        addButton(10,height-47,pWidth-20,20,"Retour au Studio",()->client.setScreen(parent));
    }
    @Override public void renderBackground(DrawContext context,int mx,int my,float delta){}
    private void drawText(DrawContext ctx,String s,int x,int y,int max,int color){
        if(max<10)return;
        if(textRenderer.getWidth(s)>max){
            String suffix="...";
            int n=s.length();
            while(n>0 && textRenderer.getWidth(s.substring(0,n)+suffix)>max)n--;
            s=s.substring(0,n)+suffix;
        }
        ctx.drawTextWithShadow(textRenderer,s,x,y,color);
    }
    @Override public void render(DrawContext ctx,int mx,int my,float dt){
        ctx.fill(0,0,width,height,0xFF0B111A);
        int side=Math.max(228,Math.min(315,width/3));
        int left=side+6, top=36, right=width-8,bottom=height-34;
        ctx.fill(4,30,side,bottom,0xFF162330);
        ctx.fill(left,top,right,bottom,0xFF0A1C29);
        drawText(ctx,"BRICKCRAFT  /  IMPORT IO-LDRAW 0.9.6",10,10,width-20,0xFFE2F4FF);
        // All diagnostics are constrained above the footer button, at every GUI scale.
        int statsEnd=height-54;
        ctx.enableScissor(6,246,side-4,Math.max(247,statsEnd));
        drawText(ctx,"Fichiers : "+sources.size(),12,250,side-22,0xFF9BC4D7);
        drawText(ctx,selectedFile()==null?"Aucun fichier detecte":selectedFile().getFileName().toString(),12,265,side-22,0xFFFFFFFF);
        if(summary!=null){
            int y=289;
            String[] lines={
                "Pieces : "+summary.pieces()+" | Formes : "+summary.designs(),
                "Couleurs : "+summary.colors()+" | Sous-modeles : "+summary.project().submodels(),
                "Manquantes : "+summary.missingInstances()+" occurrences",
                "Rotations libres : "+summary.angled(),
                "Decalages X/Z : "+summary.fractionalX()+" / "+summary.fractionalZ(),
                "Hauteurs fines : "+summary.fractionalY(),
                "Details : imports/reports/*.txt"
            };
            for(String line:lines){
                if(y+10>statsEnd)break;
                drawText(ctx,line,12,y,side-22,y==289?0xFF71E2D5:0xFFA7C6D8);
                y+=15;
            }
        }else{
            drawText(ctx,"Place tes projets dans :",12,289,side-20,0xFF9FC4D9);
            drawText(ctx,"config/brickcraft/imports/",12,305,side-20,0xFF8EDBE1);
            drawText(ctx,"Formats : .io .ldr .mpd .bcpx",12,321,side-20,0xFF9FC4D9);
        }
        ctx.disableScissor();
        drawText(ctx,"Clic droit : orbite | Molette : zoom | Milieu : deplacer",left+7,top+8,right-left-14,0xFFB0D9E8);
        drawText(ctx,switch(previewMode){
            case 0 -> "Origines des pieces (rapide)";
            case 1 -> "Volumes orientes (gabarits)";
            default -> "Maillages LDraw exacts avec niveau de detail adaptatif";
        },left+7,top+22,right-left-14,0xFF9BB9C8);
        if(summary!=null){
            if(previewMode==0)renderDots(ctx,left+5,top+38,right-5,bottom-5);
            else renderVolumes(ctx,left+5,top+38,right-5,bottom-5,previewMode==2);
        }
        // The footer always has its own opaque band, so no overdraw from the viewport.
        ctx.fill(0,height-24,width,height,0xFF142638);
        drawText(ctx,status,10,height-18,width-20,0xFFEED29A);
        super.render(ctx,mx,my,dt);
    }
    /**
     * Source coordinates are preserved: each part box is transformed by its full
     * 3x3 LDraw matrix. No grid rounding, replacement design or world export here.
     * The boxes are only a fast diagnostic preview, not actual part triangles.
     */
    private void buildPreview(){
        if(summary==null){previewParts=List.of();previewBounds=null;return;}
        var source=summary.project().parts();
        java.util.Map<String,double[]> boundsCache=new java.util.HashMap<>();
        ArrayList<PreviewPart> result=new ArrayList<>(source.size());
        double[] all={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,
                      Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
        for(var p:source){
            // The actual LDraw bounds refer to its local origin, not the normalized Minecraft mesh.
            double[] local=boundsCache.computeIfAbsent(p.partId(),id->{
                String actual=fr.brickcraft.importer.PreciseReferenceMapper.geometryId(id);
                double[] b=actual==null?null:LDrawLibrary.originalBounds(actual);
                return b!=null?b:new double[]{-10,-12,-10,10,12,10};
            });
            double[] m=p.matrix();
            double[][] corners=new double[8][3];
            for(int k=0;k<8;k++){
                double x=((k&1)==0)?local[0]:local[3];
                double y=((k&2)==0)?local[1]:local[4];
                double z=((k&4)==0)?local[2]:local[5];
                double[] point={p.x()+m[0]*x+m[1]*y+m[2]*z,
                                p.y()+m[3]*x+m[4]*y+m[5]*z,
                                p.z()+m[6]*x+m[7]*y+m[8]*z};
                corners[k]=point;
                for(int axis=0;axis<3;axis++){
                    all[axis]=Math.min(all[axis],point[axis]);
                    all[axis+3]=Math.max(all[axis+3],point[axis]);
                }
            }
            var color=LDrawLibrary.color(p.color());
            int argb=color==null?0xFFCED4DE:0xFF000000|color.rgb();
            result.add(new PreviewPart(corners,argb,p.x(),p.y(),p.z(),p));
        }
        previewParts=List.copyOf(result);
        previewBounds=all;
    }

    private void renderVolumes(DrawContext ctx,int x1,int y1,int x2,int y2,boolean detailed){
        if(previewParts.isEmpty() || previewBounds==null || x2<=x1 || y2<=y1)return;
        double[] b=previewBounds;
        double cx=(b[0]+b[3])/2,cy=(b[1]+b[4])/2,cz=(b[2]+b[5])/2;
        double sx=Math.max(20,b[3]-b[0]),sy=Math.max(8,b[4]-b[1]),sz=Math.max(20,b[5]-b[2]);
        double co=Math.cos(orbit),si=Math.sin(orbit);
        double boundW=1,boundH=1;
        for(int i=0;i<8;i++){
            double x=((i&1)==0?-sx:sx)/2;
            double y=((i&2)==0?-sy:sy)/2;
            double z=((i&4)==0?-sz:sz)/2;
            boundW=Math.max(boundW,Math.abs(x*co-z*si));
            boundH=Math.max(boundH,Math.abs((x*si+z*co)*.40+y*.86));
        }
        double unit=Math.max(0.0001,Math.min((x2-x1-36)/(2*boundW),(y2-y1-36)/(2*boundH))*zoom);
        double centerX=(x1+x2)*.5+panX,centerY=(y1+y2)*.5+panY;
        // Painters' order for opaque gabarits. The low LOD is deliberately cheap.
        ArrayList<PreviewPart> ordered=new ArrayList<>(previewParts);
        ordered.sort(Comparator.comparingDouble(p->(p.depthX()-cx)*si+(p.depthZ()-cz)*co-(p.depthY()-cy)*.55));
        ctx.enableScissor(x1,y1,x2,y2);
        int rendered=0;
        trianglesRendered=0;realMeshesRendered=0;
        int[] loadsLeft={2};
        for(PreviewPart part:ordered){
            Pixel[] pts=new Pixel[8];
            int minx=Integer.MAX_VALUE,miny=Integer.MAX_VALUE,maxx=Integer.MIN_VALUE,maxy=Integer.MIN_VALUE;
            for(int k=0;k<8;k++){
                double[] v=part.corners()[k];
                double x=v[0]-cx,y=v[1]-cy,z=v[2]-cz;
                int px=(int)Math.round(centerX+(x*co-z*si)*unit);
                int py=(int)Math.round(centerY+((x*si+z*co)*.4+y*.86)*unit);
                pts[k]=new Pixel(px,py);
                minx=Math.min(minx,px);maxx=Math.max(maxx,px);
                miny=Math.min(miny,py);maxy=Math.max(maxy,py);
            }
            if(maxx<x1 || minx>x2 || maxy<y1 || miny>y2)continue;
            // Small distant parts are 2px dots; larger parts show 3D gabarits.
            if((maxx-minx)*(maxy-miny)<9){
                int px=(minx+maxx)/2,py=(miny+maxy)/2;
                ctx.fill(px-1,py-1,px+2,py+2,part.color());
            }else if(detailed && (maxx-minx)*(maxy-miny)>42 &&
                    drawMesh(ctx,part,cx,cy,cz,co,si,unit,centerX,centerY,x1,y1,x2,y2,loadsLeft)){
                realMeshesRendered++;
            }else{
                // Sort all six faces for this part, including arbitrary LDraw rotation.
                int[][] faces={{0,4,5,1},{2,3,7,6},{0,2,6,4},
                               {1,5,7,3},{0,1,3,2},{4,6,7,5}};
                int[] shades={78,112,84,96,90,73};
                ArrayList<Face> orderedFaces=new ArrayList<>(6);
                for(int f=0;f<faces.length;f++){
                    Pixel[] v=new Pixel[4];double depth=0;
                    for(int k=0;k<4;k++){
                        int ix=faces[f][k];v[k]=pts[ix];
                        depth+=(part.corners()[ix][0]-cx)*si+(part.corners()[ix][2]-cz)*co-(part.corners()[ix][1]-cy)*.55;
                    }
                    orderedFaces.add(new Face(v,depth,shade(part.color(),shades[f])));
                }
                orderedFaces.sort(Comparator.comparingDouble(Face::depth));
                for(Face face:orderedFaces)fillFace(ctx,face.verts(),face.color(),x1,y1,x2,y2);
            }
            rendered++;
        }
        ctx.disableScissor();
        drawText(ctx,detailed?"Detail : "+realMeshesRendered+" formes reelles / "+rendered+
                " pieces, "+trianglesRendered+" triangles (LOD)":
                "Apercu : "+rendered+" volumes",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    /** A bounded, lazy mesh cache: expensive .dat files are never expanded for every instance/frame. */
    private LDrawLibrary.Mesh previewMesh(String id,int[] loadsLeft){
        if(meshes.containsKey(id))return meshes.get(id);
        if(noMesh.contains(id)||loadsLeft[0]<=0)return null;
        loadsLeft[0]--;
        LDrawLibrary.Mesh mesh=LDrawLibrary.mesh(id);
        if(mesh==null || mesh.isEmpty() || mesh.triangles()>MAX_PART_TRIANGLES ||
                cachedTriangles+mesh.triangles()>MAX_CACHED_TRIANGLES){
            noMesh.add(id);return null;
        }
        cachedTriangles+=mesh.triangles();meshes.put(id,mesh);
        return mesh;
    }
    private boolean drawMesh(DrawContext ctx,PreviewPart part,double cx,double cy,double cz,
                             double co,double si,double unit,double centerX,double centerY,
                             int x1,int y1,int x2,int y2,int[] loadsLeft){
        var src=part.instance();
        LDrawLibrary.Mesh mesh=previewMesh(src.partId(),loadsLeft);
        if(mesh==null || trianglesRendered+mesh.triangles()>MAX_RENDER_TRIANGLES)return false;
        double[] bounds=LDrawLibrary.originalBounds(src.partId());
        if(bounds==null)return false;
        float[] xyz=mesh.xyz();int[] faceColors=mesh.colors();
        double[] m=src.matrix(); // Fetch the matrix once; the rasterizer runs many triangles/frame.
        ArrayList<Face> faces=new ArrayList<>(mesh.triangles());
        for(int i=0;i<mesh.triangles();i++){
            Pixel[] vertices=new Pixel[3];double[] wx=new double[3],wy=new double[3],wz=new double[3];
            for(int j=0;j<3;j++){
                int k=i*9+j*3;
                double lx=bounds[0]+xyz[k]*20.0;
                double ly=bounds[4]-xyz[k+1]*20.0;
                double lz=bounds[2]+xyz[k+2]*20.0;
                wx[j]=src.x()+m[0]*lx+m[1]*ly+m[2]*lz;
                wy[j]=src.y()+m[3]*lx+m[4]*ly+m[5]*lz;
                wz[j]=src.z()+m[6]*lx+m[7]*ly+m[8]*lz;
                double x=wx[j]-cx,y=wy[j]-cy,z=wz[j]-cz;
                vertices[j]=new Pixel((int)Math.round(centerX+(x*co-z*si)*unit),
                        (int)Math.round(centerY+((x*si+z*co)*.40+y*.86)*unit));
            }
            double ux=wx[1]-wx[0],uy=wy[1]-wy[0],uz=wz[1]-wz[0];
            double vx=wx[2]-wx[0],vy=wy[2]-wy[0],vz=wz[2]-wz[0];
            double nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
            double length=Math.sqrt(nx*nx+ny*ny+nz*nz);
            if(length<0.0000001)continue;
            // Double-sided triangles: no assumption about BFC winding or mirrored MPD transforms.
            double light=.74+.15*Math.abs(ny)/length+.12*Math.abs(nx*si+nz*co)/length;
            int argb=LDrawLibrary.meshColor(faceColors[i],src.color(),part.color()&0xFFFFFF);
            int tint=shade(argb,(int)Math.round(light*100));
            double depth=((wx[0]+wx[1]+wx[2])/3-cx)*si+
                         ((wz[0]+wz[1]+wz[2])/3-cz)*co-
                         ((wy[0]+wy[1]+wy[2])/3-cy)*.55;
            faces.add(new Face(vertices,depth,tint));
        }
        faces.sort(Comparator.comparingDouble(Face::depth));
        for(Face f:faces)fillFace(ctx,f.verts(),f.color(),x1,y1,x2,y2);
        trianglesRendered+=mesh.triangles();
        return true;
    }
    private static int shade(int color,int factor){
        int r=Math.min(255,((color>>>16)&255)*factor/100),g=Math.min(255,((color>>>8)&255)*factor/100);
        int b=Math.min(255,(color&255)*factor/100);
        return (color&0xFF000000)|(r<<16)|(g<<8)|b;
    }
    private static void fillFace(DrawContext ctx,Pixel[] v,int color,int x1,int y1,int x2,int y2){
        int lo=Integer.MAX_VALUE,hi=Integer.MIN_VALUE;
        for(Pixel p:v){lo=Math.min(lo,p.y());hi=Math.max(hi,p.y());}
        lo=Math.max(lo,y1);hi=Math.min(hi,y2-1);
        for(int y=lo;y<=hi;y++){
            double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
            for(int i=0;i<v.length;i++){
                Pixel a=v[i],b=v[(i+1)%v.length];
                if(a.y()==b.y()||y<Math.min(a.y(),b.y())||y>=Math.max(a.y(),b.y()))continue;
                double xx=a.x()+(double)(y-a.y())*(b.x()-a.x())/(b.y()-a.y());
                min=Math.min(min,xx);max=Math.max(max,xx);
            }
            if(max>=min){
                int lx=Math.max(x1,(int)Math.floor(min));int hx=Math.min(x2,(int)Math.ceil(max)+1);
                if(hx>lx)ctx.fill(lx,y,hx,y+1,color);
            }
        }
    }

    private void renderDots(DrawContext ctx,int x1,int y1,int x2,int y2){
        if(summary==null||x2<=x1||y2<=y1)return;
        int count=summary.project().parts().size();
        if(count==0)return;
        double spanX=Math.max(20,summary.maxX()-summary.minX());
        double spanZ=Math.max(20,summary.maxZ()-summary.minZ());
        double spanY=Math.max(8,summary.maxY()-summary.minY());
        double c=Math.cos(orbit),s=Math.sin(orbit);
        double[][] sample={{0,0,0},{spanX,0,0},{0,0,spanZ},{spanX,0,spanZ},
                           {0,spanY,0},{spanX,spanY,0},{0,spanY,spanZ},{spanX,spanY,spanZ}};
        double boundX=1,boundY=1;
        for(double[] v:sample){
            double px=(v[0]-spanX/2)*c-(v[2]-spanZ/2)*s;
            double py=((v[0]-spanX/2)*s+(v[2]-spanZ/2)*c)*.40-(v[1]-spanY/2)*.86;
            boundX=Math.max(boundX,Math.abs(px));boundY=Math.max(boundY,Math.abs(py));
        }
        double unit=Math.min((x2-x1-32)/2.0/boundX,(y2-y1-32)/2.0/boundY)*zoom;
        double centerX=(x1+x2)/2.+panX,centerY=(y1+y2)/2.+panY;
        ArrayList<Dot> dots=new ArrayList<>(count);
        for(var p:summary.project().parts()){
            double xx=p.x()-summary.minX()-spanX/2;
            double zz=p.z()-summary.minZ()-spanZ/2;
            double yy=summary.maxY()-p.y()-spanY/2;
            double screenX=centerX+(xx*c-zz*s)*unit;
            double depth=xx*s+zz*c;
            double screenY=centerY+(depth*.40-yy*.86)*unit;
            if(screenX<x1+1||screenX>x2-1||screenY<y1+1||screenY>y2-1)continue;
            var color=LDrawLibrary.color(p.color());
            dots.add(new Dot((int)screenX,(int)screenY,depth,color==null?0xFFCED4DE:0xFF000000|color.rgb()));
        }
        dots.sort(Comparator.comparingDouble(Dot::depth));
        ctx.enableScissor(x1,y1,x2,y2);
        for(Dot d:dots){
            int size=Math.max(2,Math.min(5,(int)(unit*8)));
            ctx.fill(d.x-size/2,d.y-size/2,d.x+size/2+1,d.y+size/2+1,d.color);
        }
        ctx.disableScissor();
        drawText(ctx,count+" origines de pieces (mode rapide)",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    @Override public boolean mouseClicked(double x,double y,int btn){
        if(x>=Math.max(228,Math.min(315,width/3))+6 && y>36 && y<height-34){
            if(btn==1){orbiting=true;lastX=(int)x;lastY=(int)y;return true;}
            if(btn==2){panning=true;lastX=(int)x;lastY=(int)y;return true;}
        }
        return super.mouseClicked(x,y,btn);
    }
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){
        if(orbiting && button==1){orbit+=dx*.01;return true;}
        if(panning && button==2){panX+=dx;panY+=dy;return true;}
        return super.mouseDragged(x,y,button,dx,dy);
    }
    @Override public boolean mouseReleased(double x,double y,int btn){
        if(btn==1)orbiting=false;
        if(btn==2)panning=false;
        return super.mouseReleased(x,y,btn);
    }
    @Override public boolean mouseScrolled(double x,double y,double horiz,double vert){
        if(x>Math.max(228,Math.min(315,width/3))){zoom=Math.max(.1,Math.min(15,zoom*Math.pow(1.15,vert)));return true;}
        return super.mouseScrolled(x,y,horiz,vert);
    }
    @Override public boolean keyPressed(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE){client.setScreen(parent);return true;}
        if(key==GLFW.GLFW_KEY_R){reloadFiles();return true;}
        if(key==GLFW.GLFW_KEY_ENTER){analyze();return true;}
        if(key==GLFW.GLFW_KEY_V){cyclePreview();return true;}
        if((mods & GLFW.GLFW_MOD_CONTROL)!=0 && key==GLFW.GLFW_KEY_S){savePrecise();return true;}
        return super.keyPressed(key,scan,mods);
    }
}
