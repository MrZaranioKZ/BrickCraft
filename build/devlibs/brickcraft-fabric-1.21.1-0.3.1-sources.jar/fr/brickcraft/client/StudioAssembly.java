package fr.brickcraft.client;

import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Local, undoable editor model. World/NBT/network formats are untouched.
 * Pure Java + BrickPiece: all editing and stacking rules can be tested without a client.
 */
public final class StudioAssembly {
    public static final int GRID = 12;
    public static final int MAX_TOP = 66; // 33 plates, in 1/5 block units
    private static final int MAX_PIECES = 256;
    private static final int HISTORY = 64;

    private final List<BrickPiece> pieces = new ArrayList<>();
    private final Deque<List<BrickPiece>> undo = new ArrayDeque<>();
    private final Deque<List<BrickPiece>> redo = new ArrayDeque<>();

    public List<BrickPiece> pieces() { return List.copyOf(pieces); }
    public int size() { return pieces.size(); }
    public boolean isEmpty() {return pieces.isEmpty();}
    public BrickPiece get(int index) {return index >= 0 && index < pieces.size() ? pieces.get(index) : null;}
    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }

    /** Find the next free LEGO-aligned layer for the candidate's horizontal footprint. */
    public int snapTop(int x,int z,BrickKind kind,int angle,int floor,int exclude) {
        return snapTop(x,z,kind,angle,0,0,floor,exclude);
    }
    public int snapTop(int x,int z,BrickKind kind,int angle,int pitch,int roll,int floor,int exclude) {
        int top=Math.max(0,floor);
        BrickPiece candidate=new BrickPiece(kind,0,x,0,z,Math.floorMod(angle,360)/90,
                Math.floorMod(angle,360),pitch,roll);
        for(int i=0;i<pieces.size();i++) {
            if(i==exclude)continue;
            BrickPiece p=pieces.get(i);
            if(candidate.horizontalOverlaps(p))top=Math.max(top,p.top());
        }
        return top;
    }

    public boolean canPlace(BrickPiece candidate, int exclude) {
        if (candidate == null || !candidate.valid() || candidate.x()<0 || candidate.z()<0 ||
                candidate.y()<0 || candidate.x()+candidate.width()>GRID ||
                candidate.z()+candidate.length()>GRID || candidate.top()>MAX_TOP) return false;
        for (int i = 0; i < pieces.size(); i++) {
            if (i != exclude && candidate.intersects(pieces.get(i))) return false;
        }
        return true;
    }

    public boolean add(BrickPiece piece) {
        if (pieces.size()>=MAX_PIECES || !canPlace(piece,-1)) return false;
        checkpoint();
        pieces.add(piece);
        return true;
    }

    public boolean replace(int index, BrickPiece piece) {
        if (get(index)==null || !canPlace(piece,index)) return false;
        if (pieces.get(index).equals(piece)) return true;
        checkpoint();
        pieces.set(index,piece);
        return true;
    }

    public boolean remove(int index) {
        if (get(index)==null) return false;
        checkpoint();
        pieces.remove(index);
        return true;
    }

    public boolean clear() {
        if (pieces.isEmpty()) return false;
        checkpoint();
        pieces.clear();
        return true;
    }

    public boolean undo() {
        if (undo.isEmpty()) return false;
        redo.push(List.copyOf(pieces));
        restore(undo.pop());
        return true;
    }

    public boolean redo() {
        if (redo.isEmpty()) return false;
        undo.push(List.copyOf(pieces));
        restore(redo.pop());
        return true;
    }

    private void checkpoint() {
        undo.push(List.copyOf(pieces));
        while (undo.size()>HISTORY) undo.removeLast();
        redo.clear();
    }

    private void restore(List<BrickPiece> saved) {
        pieces.clear();
        pieces.addAll(saved);
    }
}
