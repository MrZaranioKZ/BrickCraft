package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickCatalog;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;

/** Searchable in-world palette, with exact color+shape element ID lookup. */
public final class BrickQuickScreen extends Screen {
    private String query="";
    private TextFieldWidget search;
    private int page=0,colCount,rows,perPage,leftX,leftW,rightX,rightW,topY,cardW;
    public BrickQuickScreen(){super(Text.literal("BrickCraft - palette rapide"));}
    private List<BrickKind> matches(){return BrickCatalog.search(query);}
    @Override protected void init(){
        leftX=12;rightW=Math.min(188,Math.max(120,width/3));rightX=width-rightW-12;
        leftW=Math.max(90,rightX-leftX-12);topY=66;
        colCount=leftW>=330?3:2;
        rows=Math.max(2,Math.min(6,(height-144)/30));perPage=colCount*rows;
        cardW=(leftW-4*(colCount-1))/colCount;
        search=new TextFieldWidget(textRenderer,leftX,33,leftW,20,Text.literal("Recherche : 1x4, 3004, 6258572..."));
        search.setMaxLength(60);search.setText(query);
        search.setChangedListener(text->{
            query=text;page=0;
            BrickCatalog.Entry element=BrickCatalog.findElement(text);
            if(element!=null){BrickSelection.kind=element.kind();BrickSelection.rgb=element.rgb();}
        });
        addDrawableChild(search);
        int bottom=Math.min(height-46,topY+rows*30+6);
        button(leftX,bottom,Math.max(42,leftW/2-3),20,"< Page",()->page=Math.max(0,page-1));
        button(leftX+Math.max(42,leftW/2-3)+5,bottom,Math.max(42,leftW/2-3),20,
                "Page >",()->page=Math.min(Math.max(0,(matches().size()-1)/perPage),page+1));
        int y=topY+164;
        button(rightX,y,rightW/3-3,19,"Y -",()->BrickSelection.rotate(-1));
        button(rightX+rightW/3,y,rightW/3-3,19,"Y +",()->BrickSelection.rotate(1));
        button(rightX+rightW*2/3,y,rightW/3-3,19,"Pas",BrickSelection::cycleStep);
        button(rightX,y+24,rightW/2-2,19,"X +",()->BrickSelection.rotatePitch(1));
        button(rightX+rightW/2+2,y+24,rightW/2-2,19,"Z +",()->BrickSelection.rotateRoll(1));
        button(rightX,y+48,rightW,19,"Reset rotation",BrickSelection::resetRotation);
        button(rightX,y+77,rightW,19,"Retour en jeu",this::close);
    }
    private void button(int x,int y,int w,int h,String label,Runnable action){
        if(y+h>=height-15 || w<18)return;
        addDrawableChild(ButtonWidget.builder(Text.literal(label),b->action.run())
                .dimensions(x,y,w,h).build());
    }
    @Override public void renderBackground(DrawContext ctx,int mx,int my,float delta){}
    @Override public void render(DrawContext ctx,int mx,int my,float delta){
        ctx.fill(0,0,width,height,0xE9091420);
        ctx.fill(leftX-5,topY-37,rightX-6,height-38,0xFF152634);
        ctx.fill(rightX-5,topY-37,width-8,height-38,0xFF152634);
        ctx.drawTextWithShadow(textRenderer,"BRICKCRAFT | Recherche et construction",12,10,0xFFE6F3FF);
        List<BrickKind> kinds=matches();
        page=Math.min(page,Math.max(0,(kinds.size()-1)/perPage));
        ctx.drawTextWithShadow(textRenderer,"Pieces : "+kinds.size()+" resultat(s)",leftX,topY-12,0xFF8BCBE4);
        ctx.drawTextWithShadow(textRenderer,"Couleurs",rightX,topY-12,0xFF8BCBE4);
        for(int i=page*perPage;i<Math.min(kinds.size(),(page+1)*perPage);i++){
            BrickKind k=kinds.get(i);int slot=i-page*perPage;
            int x=leftX+(slot%colCount)*(cardW+4),y=topY+(slot/colCount)*30;
            ctx.fill(x-1,y-1,x+cardW+1,y+27,k==BrickSelection.kind?0xFF70DDCE:0xFF345366);
            ctx.fill(x,y,x+cardW,y+26,0xFF344556);
            ctx.drawItem(new ItemStack(BrickCraft.PART_ITEMS.get(k)),x+3,y+5);
            String name=k.title.replace("Brique ","B ").replace("Plaque ","P ")
                    .replace("Tuile ","T ").replace("Pente ","S ").replace('×','x');
            ctx.drawTextWithShadow(textRenderer,name,x+23,y+8,0xFFE9F5F8);
        }
        int cellW=Math.max(22,(rightW-9)/4);
        for(int i=0;i<BrickPalette.COLORS.length;i++){
            int x=rightX+(i%4)*cellW,y=topY+(i/4)*26,c=BrickPalette.COLORS[i];
            ctx.fill(x,y,x+cellW-4,y+23,c==BrickSelection.rgb?0xFFFFFFFF:0xFF45596C);
            ctx.fill(x+2,y+2,x+cellW-6,y+21,0xFF000000|c);
        }
        ctx.drawTextWithShadow(textRenderer,BrickSelection.colorName(),rightX,topY+143,0xFFFFE5B1);
        ctx.drawTextWithShadow(textRenderer,"Y="+BrickSelection.angle+" X="+BrickSelection.pitch+" Z="+BrickSelection.roll,
                rightX,topY+152,0xFFC2E2ED);
        ctx.drawTextWithShadow(textRenderer,"Selection : "+BrickSelection.kind.title,leftX,height-31,0xFFB9DDEB);
        ctx.drawTextWithShadow(textRenderer,"Entree : recherche | Echap : fermer",leftX,height-16,0xFF91B0C3);
        super.render(ctx,mx,my,delta);
    }
    @Override public boolean mouseClicked(double x,double y,int button){
        if(button==0){
            List<BrickKind> kinds=matches();
            for(int i=page*perPage;i<Math.min(kinds.size(),(page+1)*perPage);i++){
                int slot=i-page*perPage,xx=leftX+(slot%colCount)*(cardW+4),yy=topY+(slot/colCount)*30;
                if(x>=xx&&x<xx+cardW&&y>=yy&&y<yy+26){
                    BrickSelection.kind=kinds.get(i);
                    BrickCatalog.Entry element=BrickCatalog.findElement(query);
                    if(element!=null&&element.kind()==BrickSelection.kind)BrickSelection.rgb=element.rgb();
                    return true;
                }
            }
            int cellW=Math.max(22,(rightW-9)/4);
            for(int i=0;i<BrickPalette.COLORS.length;i++){
                int xx=rightX+(i%4)*cellW,yy=topY+(i/4)*26;
                if(x>=xx&&x<xx+cellW-4&&y>=yy&&y<yy+23){BrickSelection.rgb=BrickPalette.COLORS[i];return true;}
            }
        }
        return super.mouseClicked(x,y,button);
    }
    @Override public boolean keyPressed(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE){close();return true;}
        if(search!=null&&search.isFocused())return super.keyPressed(key,scan,mods);
        if(key==GLFW.GLFW_KEY_N){close();return true;}
        if(key==GLFW.GLFW_KEY_R){BrickSelection.rotate((mods&GLFW.GLFW_MOD_SHIFT)!=0?-1:1);return true;}
        if(key==GLFW.GLFW_KEY_X){BrickSelection.rotatePitch(1);return true;}
        if(key==GLFW.GLFW_KEY_Z){BrickSelection.rotateRoll(1);return true;}
        if(key==GLFW.GLFW_KEY_H){BrickSelection.resetRotation();return true;}
        if(key==GLFW.GLFW_KEY_G){BrickSelection.cycleStep();return true;}
        if(key==GLFW.GLFW_KEY_C){BrickSelection.nextColor();return true;}
        return super.keyPressed(key,scan,mods);
    }
    @Override public boolean shouldPause(){return false;}
}
