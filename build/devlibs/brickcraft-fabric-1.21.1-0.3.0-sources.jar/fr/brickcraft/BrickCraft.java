package fr.brickcraft;

import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.world.BrickPartItem;
import java.util.EnumMap;
import java.util.Map;
import fr.brickcraft.net.BrickActionPayload;
import fr.brickcraft.world.BrickCellBlock;
import fr.brickcraft.world.BrickCellEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import java.util.List;

public final class BrickCraft implements ModInitializer {
    public static final BrickCellBlock CELL = Registry.register(Registries.BLOCK,
            Identifier.of("brickcraft", "cell"),
            new BrickCellBlock(AbstractBlock.Settings.create().nonOpaque().strength(.3f)));
    public static final Item TOOL = Registry.register(Registries.ITEM,
            Identifier.of("brickcraft", "builder_wand"), new Item(new Item.Settings().maxCount(1)));
    public static final Map<BrickKind, BrickPartItem> PART_ITEMS=new EnumMap<>(BrickKind.class);
    static {
        for (BrickKind kind : BrickKind.values()) {
            BrickPartItem item = Registry.register(Registries.ITEM,
                    Identifier.of("brickcraft",kind.name().toLowerCase(java.util.Locale.ROOT)),
                    new BrickPartItem(kind,new Item.Settings().maxCount(64)));
            PART_ITEMS.put(kind,item);
        }
    }
    public static final BlockEntityType<BrickCellEntity> CELL_ENTITY = Registry.register(
            Registries.BLOCK_ENTITY_TYPE, Identifier.of("brickcraft", "cell"),
            FabricBlockEntityTypeBuilder.create(BrickCellEntity::new, CELL).build());

    @Override public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> entries.add(TOOL));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.BUILDING_BLOCKS).register(entries -> {
            for (BrickKind kind : BrickKind.values()) entries.add(PART_ITEMS.get(kind));
        });
        PayloadTypeRegistry.playC2S().register(BrickActionPayload.ID, BrickActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BrickActionPayload.ID, (packet, context) -> {
            ServerPlayerEntity player = context.player();
            if (player.isSpectator() ||
                    !(player.getMainHandStack().isOf(TOOL) ||
                      player.getMainHandStack().getItem() instanceof BrickPartItem)) return;
            handle(player.getServerWorld(),player,packet);
        });
    }

    private static void handle(ServerWorld world, ServerPlayerEntity player, BrickActionPayload packet) {
        BlockPos hit = packet.hit();
        if (!world.isInBuildLimit(hit) || !world.isChunkLoaded(hit)
                || player.squaredDistanceTo(Vec3d.ofCenter(hit)) > 100.0) return;
        if (!world.canPlayerModifyAt(player, hit)) return;
        BrickPiece intent = packet.piece();
        if (intent == null || !intent.valid() ||
                (player.getMainHandStack().getItem() instanceof BrickPartItem selectedItem
                && selectedItem.kind() != intent.kind()) || !Float.isFinite(packet.localX()) ||
                !Float.isFinite(packet.localY()) || !Float.isFinite(packet.localZ())) return;

        if (packet.remove()) {
            if (world.getBlockEntity(hit) instanceof BrickCellEntity cell) {
                BrickPiece selected = cell.pickAt(hit.getY()+packet.localY(), packet.side()==Direction.UP);
                if (selected != null) remove(world,player,selected);
            }
            return;
        }

        final BrickPiece candidate;
        if (packet.studio()) {
            // Local studio model spans 0..11 studs and 0..60 units. Anchor is server-checked.
            if (intent.x()<0 || intent.x()>11 || intent.z()<0 || intent.z()>11 ||
                    intent.y()<0 || intent.y()>60 || !world.getBlockState(hit).isAir() &&
                    !world.getBlockState(hit).isOf(CELL)) return;
            candidate = new BrickPiece(intent.kind(),intent.rgb(), hit.getX()+intent.x(),
                    hit.getY()*5+intent.y(),hit.getZ()+intent.z(),intent.turn(),intent.angle());
        } else {
            if (packet.localX() < -.01f || packet.localX() > 1.01f ||
                    packet.localY() < -.01f || packet.localY() > 1.01f ||
                    packet.localZ() < -.01f || packet.localZ() > 1.01f) return;
            boolean lego = world.getBlockState(hit).isOf(CELL);
            if (!lego && world.getBlockState(hit).isAir()) return;
            Direction side = packet.side();
            int px = hit.getX() + side.getOffsetX();
            int pz = hit.getZ() + side.getOffsetZ();
            int baseUnits = (hit.getY()+side.getOffsetY())*5;
            if (lego && world.getBlockEntity(hit) instanceof BrickCellEntity cell) {
                BrickPiece selected = cell.pickAt(hit.getY()+packet.localY(),side==Direction.UP);
                if (selected != null) {
                    if (side == Direction.UP) {
                        px = hit.getX(); pz = hit.getZ(); baseUnits = selected.top();
                    } else if (side.getAxis().isHorizontal()) {
                        baseUnits = selected.y();
                    }
                }
            }
            candidate = new BrickPiece(intent.kind(),intent.rgb(),px,baseUnits,pz,intent.turn(),intent.angle());
        }
        if (!place(world, player, candidate) && !packet.studio()) {
            player.sendMessage(Text.literal("BrickCraft : place bloquee (collision / terrain / distance)"), true);
        }
    }

    /** Validate the complete footprint BEFORE touching any world block. */
    private static boolean place(ServerWorld world, ServerPlayerEntity player, BrickPiece piece) {
        if (!piece.valid()) return false;
        List<BlockPos> locations = piece.occupiedCells();
        if (locations.size()>256) return false;
        for (BlockPos pos : locations) {
            if (!world.isInBuildLimit(pos) || !world.isChunkLoaded(pos)
                    || !world.canPlayerModifyAt(player,pos)
                    || player.squaredDistanceTo(Vec3d.ofCenter(pos))>256) return false;
            if (world.getBlockState(pos).isAir()) continue;
            if (!(world.getBlockEntity(pos) instanceof BrickCellEntity cell) || !cell.canAdd(piece)) return false;
        }
        for (BlockPos pos : locations) {
            if (world.getBlockState(pos).isAir()) world.setBlockState(pos,CELL.getDefaultState(),3);
            if (world.getBlockEntity(pos) instanceof BrickCellEntity cell) cell.add(piece);
        }
        return true;
    }

    /** A LEGO piece is always removed from every fragment cell it occupies. */
    private static boolean remove(ServerWorld world, ServerPlayerEntity player, BrickPiece piece) {
        List<BlockPos> locations=piece.occupiedCells();
        for (BlockPos pos:locations) {
            if (!world.isChunkLoaded(pos) || !world.canPlayerModifyAt(player,pos)
                    || !(world.getBlockEntity(pos) instanceof BrickCellEntity cell)
                    || !cell.pieces().contains(piece)) return false;
        }
        for (BlockPos pos:locations) {
            if (world.getBlockEntity(pos) instanceof BrickCellEntity cell && cell.remove(piece)
                    && cell.pieces().isEmpty()) world.setBlockState(pos,Blocks.AIR.getDefaultState(),3);
        }
        return true;
    }
}
