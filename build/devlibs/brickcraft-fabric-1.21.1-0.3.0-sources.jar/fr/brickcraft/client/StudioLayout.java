package fr.brickcraft.client;

/**
 * Screen geometry in Minecraft's *scaled GUI pixels*, never physical pixels.
 * Only one side panel is visible: the stage retains room even at GUI scale 3/4.
 * Has no Minecraft dependencies so layout behavior can be regression-tested.
 */
public record StudioLayout(
    int width, int height,
    int panelX, int panelW,
    int stageX, int stageRight,
    int stageTop, int stageBottom,
    int footerY
) {
    public static StudioLayout calculate(int width, int height) {
        int side = Math.max(100, Math.min(174, width / 3));
        // Keep the stage useful when Minecraft's GUI scale makes width tiny.
        if (width - side - 18 < 145) side = Math.max(88, width - 163);
        int stageX = 6 + side + 7;
        return new StudioLayout(width, height, 6, side,
                stageX, width - 6, 52, Math.max(82, height - 47), height - 42);
    }

    public int stageWidth() { return Math.max(1, stageRight - stageX); }
    public int stageHeight() { return Math.max(1, stageBottom - stageTop); }
    public boolean insideStage(double x, double y) {
        return x >= stageX && x < stageRight && y >= stageTop + 24 && y < stageBottom;
    }
}
