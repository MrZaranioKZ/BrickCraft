package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Pocket build palette. Works independently from Studio and keeps the vanilla hotbar:
 * select a real brick item in creative inventory, OR select a brick here for the wand.
 */
public final class BrickQuickScreen extends Screen {
    private int page=0;
    private int colCount,rowCount,perPage,leftX,leftW,rightX,rightW,topY;
    public BrickQuickScreen() {super(Text.literal("BrickCraft - construction rapide"));}

    @Override protected void init() {
        leftX=12; rightW=Math.min(184,Math.max(120,width/3));
        rightX=width-rightW-12;
        leftW=rightX-leftX-12; topY=42;
        colCount=leftW>=320?3:2;
        rowCount=Math.max(2,Math.min(6,(height-108)/29));
        perPage=colCount*rowCount;
        BrickKind[] kinds=BrickKind.values();
        int pages=(kinds.length+perPage-1)/perPage;
        page=Math.clamp(page,0,Math.max(0,pages-1));
        int gap=4;
        int buttonW=Math.max(20,(leftW-gap*(colCount-1))/colCount);
        for (int i=page*perPage;i<Math.min(kinds.length,(page+1)*perPage);i++) {
            BrickKind kind=kinds[i]; int slot=i-page*perPage;
            int x=leftX+(slot%colCount)*(buttonW+gap), y=topY+(slot/colCount)*29;
            addDrawableChild(ButtonWidget.builder(Text.literal(abbrev(kind)),b->{
                BrickSelection.kind=kind;
            }).dimensions(x,y,buttonW,25).build());
        }
        int bottom=Math.min(height-50,topY+rowCount*29+5);
        addButton(leftX,bottom,Math.max(35,leftW/3),20,"<",()->{page=Math.max(0,page-1);clearAndInit();});
        addButton(leftX+Math.max(35,leftW/3)+3,bottom,Math.max(35,leftW/3),20,">",()->{page=Math.min(pages-1,page+1);clearAndInit();});
        int ax=rightX, ay=topY+125;
        addButton(ax,ay,Math.max(30,rightW/3-3),19,"-",()->BrickSelection.rotate(-1));
        addButton(ax+rightW/3,ay,Math.max(30,rightW/3-3),19,"+",()->BrickSelection.rotate(1));
        addButton(ax+2*rightW/3,ay,Math.max(30,rightW/3-2),19,"Pas",BrickSelection::cycleStep);
        addButton(rightX,ay+26,rightW,19,"Revenir au jeu",this::close);
    }

    private void addButton(int x,int y,int w,int h,String title,Runnable callback) {
        if(x+w<=width && y+h<height-15 && w>=20)
            addDrawableChild(ButtonWidget.builder(Text.literal(title),b->callback.run())
                    .dimensions(x,y,w,h).build());
    }
    private static String abbrev(BrickKind kind) {
        return kind.title.replace("Brique ","B ").replace("Plaque ","P ")
                .replace("Tuile ","T ").replace("Pente ","S ").replace('×','x');
    }
    @Override public void renderBackground(DrawContext ctx,int mx,int my,float delta) {}
    @Override public void render(DrawContext ctx,int mx,int my,float delta) {
        ctx.fill(0,0,width,height,0xE9091420);
        ctx.fill(leftX-5,topY-18,rightX-6,height-37,0xFF152634);
        ctx.fill(rightX-5,topY-18,width-8,height-37,0xFF152634);
        super.render(ctx,mx,my,delta);
        ctx.drawTextWithShadow(textRenderer,"BRICKCRAFT | Palette rapide",12,11,0xFFE6F3FF);
        ctx.drawTextWithShadow(textRenderer,"Pieces ("+(page+1)+")",leftX,topY-14,0xFF8BCBE4);
        ctx.drawTextWithShadow(textRenderer,"Couleurs",rightX,topY-14,0xFF8BCBE4);
        int gap=4,buttonW=Math.max(20,(leftW-gap*(colCount-1))/colCount);
        BrickKind[] kinds=BrickKind.values();
        for (int i=page*perPage;i<Math.min(kinds.length,(page+1)*perPage);i++) {
            BrickKind kind=kinds[i];int slot=i-page*perPage;
            int x=leftX+(slot%colCount)*(buttonW+gap),y=topY+(slot/colCount)*29;
            if(kind==BrickSelection.kind) {
                ctx.fill(x-2,y-2,x+buttonW+2,y+27,0xFF75E4D7);
            }
            ctx.drawItem(new ItemStack(BrickCraft.PART_ITEMS.get(kind)),x+3,y+4);
        }
        int cellW=Math.max(22,(rightW-9)/4);
        for(int i=0;i<BrickPalette.COLORS.length;i++) {
            int x=rightX+(i%4)*cellW,y=topY+(i/4)*28;
            int c=BrickPalette.COLORS[i];
            ctx.fill(x,y,x+cellW-4,y+24,c==BrickSelection.rgb?0xFFFFFFFF:0xFF45596C);
            ctx.fill(x+2,y+2,x+cellW-6,y+22,0xFF000000|c);
        }
        ctx.drawTextWithShadow(textRenderer,BrickSelection.colorName(),rightX,topY+115,0xFFFFE5B1);
        ctx.drawTextWithShadow(textRenderer,"Angle : "+BrickSelection.angle+"° / "+BrickSelection.step()+"°",rightX,
                topY+174,0xFFC2E2ED);
        ctx.drawTextWithShadow(textRenderer,"Baguette : "+abbrev(BrickSelection.kind),leftX,
                height-30,0xFFB9DDEB);
        ctx.drawTextWithShadow(textRenderer,"B / Studio  |  N / Palette  |  Echap",leftX,
                height-15,0xFF91B0C3);
    }

    @Override public boolean mouseClicked(double x,double y,int button) {
        if(button==0) {
            int cellW=Math.max(22,(rightW-9)/4);
            for(int i=0;i<BrickPalette.COLORS.length;i++) {
                int xx=rightX+(i%4)*cellW,yy=topY+(i/4)*28;
                if(x>=xx && x<xx+cellW-4 && y>=yy && y<yy+24) {
                    BrickSelection.rgb=BrickPalette.COLORS[i];return true;
                }
            }
        }
        return super.mouseClicked(x,y,button);
    }
    @Override public boolean keyPressed(int key,int scan,int modifiers) {
        if(key==GLFW.GLFW_KEY_R) {BrickSelection.rotate((modifiers&GLFW.GLFW_MOD_SHIFT)!=0?-1:1);return true;}
        if(key==GLFW.GLFW_KEY_G) {BrickSelection.cycleStep();return true;}
        if(key==GLFW.GLFW_KEY_C) {BrickSelection.nextColor();return true;}
        if(key==GLFW.GLFW_KEY_ESCAPE || key==GLFW.GLFW_KEY_N){close();return true;}
        return super.keyPressed(key,scan,modifiers);
    }
    @Override public boolean shouldPause(){return false;}
}
