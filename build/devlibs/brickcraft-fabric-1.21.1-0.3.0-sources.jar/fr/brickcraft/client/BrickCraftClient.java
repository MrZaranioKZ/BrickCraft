package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.world.BrickPartItem;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class BrickCraftClient implements ClientModInitializer {
    private static KeyBinding studioKey,nextKey,turnKey,colorKey,quickKey,stepKey;

    @Override public void onInitializeClient() {
        BlockEntityRendererRegistry.register(BrickCraft.CELL_ENTITY, BrickCellRenderer::new);
        studioKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.studio",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_B,"category.brickcraft"));
        nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.next",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_V,"category.brickcraft"));
        turnKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.turn",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_R,"category.brickcraft"));

        quickKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.quick",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_N,"category.brickcraft"));
        stepKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.step",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_G,"category.brickcraft"));
        colorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.color",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_C,"category.brickcraft"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (studioKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null)
                    client.setScreen(new BrickStudioScreen(resolveTarget(client)));
            }
            while (quickKey.wasPressed()) if (client.currentScreen==null && client.player!=null)
                client.setScreen(new BrickQuickScreen());
            while (stepKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.cycleStep();
                if(client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : pas de rotation " + BrickSelection.step() + "°"),true);
            }
            while (nextKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.nextKind();
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : "+BrickSelection.kind.title),true);
            }
            while (colorKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.nextColor();
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : " + BrickSelection.colorName()),true);
            }
            while (turnKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.rotate(client.player!=null && client.player.isSneaking() ? -1 : 1);
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : rotation "+BrickSelection.angle+"° (pas "+BrickSelection.step()+"°)"),true);
            }
        });
        HudRenderCallback.EVENT.register((draw,tick) -> {
            MinecraftClient client=MinecraftClient.getInstance();
            if(client.player==null || client.currentScreen!=null || client.options.hudHidden) return;
            boolean active=client.player.getMainHandStack().isOf(BrickCraft.TOOL)
                    || client.player.getMainHandStack().getItem() instanceof BrickPartItem;
            if(!active)return;
            BrickKind kind=client.player.getMainHandStack().getItem() instanceof BrickPartItem item
                    ? item.kind():BrickSelection.kind;
            int x=6,y=draw.getScaledWindowHeight()-76;
            int w=Math.max(170,client.textRenderer.getWidth(kind.title)+22);
            draw.fill(x-3,y-3,x+w+3,y+48,0xB5102230);
            draw.fill(x,y+3,x+8,y+15,0xFF000000|BrickSelection.rgb);
            draw.drawTextWithShadow(client.textRenderer,kind.title,x+13,y+4,0xFFEAF6FF);
            draw.drawTextWithShadow(client.textRenderer,
                    BrickSelection.colorName()+"  |  "+BrickSelection.angle+"° ("+BrickSelection.step()+"°)",
                    x+3,y+20,0xFFF2DDA1);
            draw.drawTextWithShadow(client.textRenderer,"N : pieces / couleurs   G : pas",x+3,y+34,0xFF99C0D1);
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand!=Hand.MAIN_HAND || !(player.getStackInHand(hand).isOf(BrickCraft.TOOL) ||
                    player.getStackInHand(hand).getItem() instanceof BrickPartItem))
                return ActionResult.PASS;
            if (world.isClient) {
                BrickKind kind=player.getStackInHand(hand).getItem() instanceof BrickPartItem item
                        ? item.kind() : BrickSelection.kind;
                BrickPiece selection=BrickPiece.atAngle(kind,BrickSelection.rgb,0,0,0,BrickSelection.angle);
                ClientPlayNetworking.send(new BrickActionPayload(
                    hit.getBlockPos(),hit.getSide(),
                    (float)(hit.getPos().x-hit.getBlockPos().getX()),
                    (float)(hit.getPos().y-hit.getBlockPos().getY()),
                    (float)(hit.getPos().z-hit.getBlockPos().getZ()),
                    player.isSneaking(),false,selection));
            }
            return ActionResult.SUCCESS;
        });
    }

    public static BlockPos resolveTarget(MinecraftClient client) {
        if (client.world == null || !(client.crosshairTarget instanceof BlockHitResult hit)) return null;
        // Studio origin is placed NEXT TO a targeted normal block, vanilla-style.
        // A new model can also start from the top of an existing LEGO cell.
        if (client.world.getBlockState(hit.getBlockPos()).isOf(BrickCraft.CELL))
            return hit.getSide().getAxis().isVertical()
                    ? hit.getBlockPos().up() : hit.getBlockPos().offset(hit.getSide());
        return hit.getBlockPos().offset(hit.getSide());
    }
}
