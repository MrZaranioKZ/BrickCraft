package fr.brickcraft.client;

import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PreciseWorldEditPayload;
import fr.brickcraft.world.PreciseDisplayEntity;
import fr.brickcraft.world.PreciseWorldEditMath;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.*;

/**
 * Direct-in-world manipulation. F4 toggles editor. The mouse ray selects ORIGINAL
 * oriented LEGO volumes rather than Minecraft blocks. Axis + wheel commits a small,
 * server-authorized LDU / matrix delta, persisted in the projection block entity.
 */
public final class PreciseWorldEditor {
    private PreciseWorldEditor(){}
    private static boolean enabled,rotation;
    private static int axis=0,index=-1;
    private static BlockPos anchor;
    private static String status="";
    public static boolean enabled(){return enabled;}
    public static void reset(){enabled=false;index=-1;anchor=null;status="";}
    public static boolean toggle(MinecraftClient client){
        enabled=!enabled;index=-1;anchor=null;rotation=false;axis=0;
        status=enabled?"Clic gauche : choisir une piece LEGO. F4 : quitter.":"";
        if(client.player!=null)client.player.sendMessage(Text.literal(
                "BrickCraft : edition en monde "+(enabled?"ACTIVE":"DESACTIVEE")),true);
        return enabled;
    }
    private static PreciseDisplayEntity selected(MinecraftClient client){
        if(anchor==null||index<0||client.world==null)return null;
        if(!(client.world.getBlockEntity(anchor) instanceof PreciseDisplayEntity be))return null;
        return be.model()!=null&&index<be.model().parts().size()?be:null;
    }
    private static double[] bounds(String part){
        String mapped=PreciseReferenceMapper.geometryId(part);
        return mapped==null?null:LDrawLibrary.originalBounds(mapped);
    }
    private record Selection(BlockPos anchor,WorldPiecePicker.Hit hit){}
    public static boolean attack(MinecraftClient client){
        if(!enabled||client.currentScreen!=null||client.player==null||client.world==null)return false;
        Vec3d from=client.player.getEyePos(),dir=client.player.getRotationVec(1.0f);
        ArrayList<Selection> hits=new ArrayList<>();
        for(PreciseDisplayEntity be:PreciseDisplayRenderer.activeProjections(client.world)){
            var model=be.model();if(model==null)continue;
            BlockPos a=be.getPos();
            for(var hit:WorldPiecePicker.hits(model.parts(),model.minX(),model.minY(),model.minZ(),
                    a.getX(),a.getY(),a.getZ(),from.x,from.y,from.z,dir.x,dir.y,dir.z,12.0,
                    PreciseWorldEditor::bounds))hits.add(new Selection(a,hit));
        }
        hits.sort(Comparator.comparingDouble(s->s.hit().distance()));
        if(hits.isEmpty()){
            index=-1;anchor=null;status="Aucune piece sous le viseur (portee : 12 blocs).";
        }else{
            int found=0;
            if(client.player.isSneaking()&&anchor!=null){
                for(int i=0;i<hits.size();i++)if(anchor.equals(hits.get(i).anchor()) && index==hits.get(i).hit().index()){
                    found=(i+1)%hits.size();break;
                }
            }
            Selection chosen=hits.get(found);
            index=chosen.hit().index();anchor=chosen.anchor();
            PreciseDisplayEntity be=selected(client);
            status="Piece #"+(index+1)+" : "+(be==null?"?":be.model().parts().get(index).partId());
        }
        return true; // Cancel vanilla punching / breaking while editing a virtual assembly.
    }
    public static boolean modeKey(boolean rotate){
        if(!enabled)return false;rotation=rotate;
        status=rotate?"Rotation : choisis X/Y/Z, puis molette.":"Deplacement : choisis X/Y/Z, puis molette.";
        return true;
    }
    public static boolean chooseAxis(int next){
        if(!enabled)return false;axis=next;
        status="Axe "+"XYZ".charAt(axis)+(rotation?" (rotation)":" (deplacement)");return true;
    }
    public static boolean resetRotation(){
        if(!enabled)return false;
        send(PreciseWorldEditMath.RESET,0);return true;
    }
    public static boolean undo(){if(!enabled)return false;send(PreciseWorldEditMath.UNDO,0);return true;}
    private static void send(byte operation,double amount){
        MinecraftClient client=MinecraftClient.getInstance();
        if(client.player==null||client.currentScreen!=null)return;
        PreciseDisplayEntity be=selected(client);
        if(be==null){status="Selectionne d'abord une piece (clic gauche).";return;}
        if(!client.player.isCreative()){status="Mode Creatif requis pour modifier le monde.";return;}
        ClientPlayNetworking.send(new PreciseWorldEditPayload(anchor,index,operation,(byte)axis,amount));
        status="Piece #"+(index+1)+" "+(operation==PreciseWorldEditMath.MOVE?"deplacee":"rotation")+
                " | " +"XYZ".charAt(axis)+" "+(operation==PreciseWorldEditMath.RESET?"reset":amount);
    }
    public static boolean scroll(double vertical){
        if(!enabled)return false;
        MinecraftClient client=MinecraftClient.getInstance();
        if(client.currentScreen!=null||client.player==null)return false;
        if(vertical==0)return true;
        boolean fine=client.player.isSneaking();
        double step=rotation?(fine?1:15):(fine?1:20);
        send(rotation?PreciseWorldEditMath.ROTATE:PreciseWorldEditMath.MOVE,
                Math.signum(vertical)*step);
        return true; // Prevent hotbar scrolling while the world editor is active.
    }
    public static void renderHud(DrawContext d,MinecraftClient client){
        if(!enabled||client.player==null||client.currentScreen!=null)return;
        int height=d.getScaledWindowHeight(),width=d.getScaledWindowWidth();
        int py=Math.max(8,height-70),px=8;
        String one="BRICKCRAFT WORLD EDIT | "+(rotation?"ROTATION":"DEPLACEMENT")+
                " | AXE "+"XYZ".charAt(axis)+" | F4: quitter";
        String two="Clic: selection | Maj+Clic: superposees | G/R: mode | X/Y/Z: axe";
        String three="Molette: +/- "+(rotation?"15 deg":"20 LDU")+" | Maj+molette: fin | H: rotation 0 | Ctrl+Z: annuler";
        int w=Math.max(client.textRenderer.getWidth(one),Math.max(client.textRenderer.getWidth(two),
                client.textRenderer.getWidth(three)))+10;
        w=Math.min(w,width-16);
        d.fill(px-4,py-4,px+w,py+49,0xDD0A2534);
        d.drawTextWithShadow(client.textRenderer,one,px,py,0xFF5CE3DF);
        d.drawTextWithShadow(client.textRenderer,two,px,py+12,0xFFDBF4FA);
        d.drawTextWithShadow(client.textRenderer,three,px,py+24,0xFFEDC98E);
        String selected=anchor==null?status:"#"+(index+1)+" @ "+anchor.toShortString()+" | "+status;
        if(selected.length()>Math.max(12,w/6))selected=selected.substring(0,Math.max(10,w/6-3))+"...";
        d.drawTextWithShadow(client.textRenderer,selected,px,py+36,0xFF9EDADE);
    }
    /** Selection outline in world coordinates, including rotations. No 3D mesh allocations. */
    public static void initOverlay(){
        WorldRenderEvents.AFTER_ENTITIES.register(context->{
            if(!enabled)return;
            MinecraftClient client=MinecraftClient.getInstance();
            PreciseDisplayEntity be=selected(client);
            if(be==null||context.consumers()==null||context.matrixStack()==null)return;
            PreciseWorldModel model=be.model();
            var p=model.parts().get(index);double[] b=bounds(p.partId());if(b==null)return;
            BlockPos a=be.getPos();
            double[][] corners=WorldPiecePicker.corners(p,b,model.minX(),model.minY(),model.minZ(),
                    a.getX(),a.getY(),a.getZ());
            MatrixStack matrices=context.matrixStack();Vec3d cam=context.camera().getPos();
            matrices.push();matrices.translate(-cam.x,-cam.y,-cam.z);
            VertexConsumer lines=context.consumers().getBuffer(RenderLayer.getLines());
            for(int i=0;i<8;i++)for(int bit:new int[]{1,2,4})if((i&bit)==0)
                line(lines,matrices,corners[i],corners[i|bit],0xFFF7D67B);
            // LDraw X/Z positive world axes, LDraw Y positive points down in Minecraft.
            double ox=a.getX()+p.x()/20-model.minX();
            double oy=a.getY()-p.y()/20-model.minY();
            double oz=a.getZ()+p.z()/20-model.minZ();
            double[] center={ox,oy,oz};
            line(lines,matrices,center,new double[]{ox+1.2,oy,oz},0xFFFF6666);
            line(lines,matrices,center,new double[]{ox,oy+1.2,oz},0xFF77FFAA);
            line(lines,matrices,center,new double[]{ox,oy,oz+1.2},0xFF66BFFF);
            matrices.pop();
        });
    }
    private static void line(VertexConsumer lines,MatrixStack stack,double[] a,double[] b,int c){
        var m=stack.peek().getPositionMatrix();
        lines.vertex(m,(float)a[0],(float)a[1],(float)a[2]).color(c).normal(0,1,0);
        lines.vertex(m,(float)b[0],(float)b[1],(float)b[2]).color(c).normal(0,1,0);
    }
}
