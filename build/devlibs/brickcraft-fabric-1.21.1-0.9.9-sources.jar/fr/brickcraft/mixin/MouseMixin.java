package fr.brickcraft.mixin;

import fr.brickcraft.client.PreciseWorldEditor;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** In world-edit mode the wheel moves/rotates LEGO instead of changing the hotbar. */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method="onMouseScroll",at=@At("HEAD"),cancellable=true)
    private void brickcraft$legoWheel(long window,double horizontal,double vertical,CallbackInfo ci){
        if(PreciseWorldEditor.scroll(vertical))ci.cancel();
    }
}
