package fr.brickcraft.core;

import java.util.Map;

/**
 * V0.7 stud-to-undercavity alignment for horizontal rectilinear LEGO pieces.
 * LDraw parts need a real connector database for Technic, hinges, clips, tiles,
 * slopes, or non-90-degree oriented parts. Never guess connectors for those.
 */
public final class ConnectorSnapper {
    private ConnectorSnapper() {}
    private record Studs(int x,int z) {}
    // Known classic LDraw design IDs. This is deliberately not the entire catalog.
    private static final Map<String,Studs> KNOWN=Map.ofEntries(
        Map.entry("3005",new Studs(1,1)),Map.entry("3004",new Studs(1,2)),
        Map.entry("3622",new Studs(1,3)),Map.entry("3010",new Studs(1,4)),
        Map.entry("3009",new Studs(1,6)),Map.entry("3003",new Studs(2,2)),
        Map.entry("3002",new Studs(2,3)),Map.entry("3001",new Studs(2,4)),
        Map.entry("2456",new Studs(2,6)),Map.entry("3007",new Studs(2,8)),
        Map.entry("3024",new Studs(1,1)),Map.entry("3023",new Studs(1,2)),
        Map.entry("3022",new Studs(2,2)),Map.entry("3020",new Studs(2,4)));
    private static Studs footprint(BrickPiece p){
        if(p.tilted() || p.angle()%90!=0 || p.kind().slope)return null;
        if(p.kind()!=BrickKind.LDRAW_PART)return new Studs(p.kind().width,p.kind().length);
        Studs s=KNOWN.get(p.partId().toLowerCase(java.util.Locale.ROOT));
        if(s==null)return null;
        // Ignore a mesh with unexpected geometry, rather than connecting to invented studs.
        if(Math.abs(p.bodyWidth()-s.x())>0.35 || Math.abs(p.bodyDepth()-s.z())>0.35)return null;
        return s;
    }
    private static boolean topStuds(BrickPiece p){return p.kind()==BrickKind.LDRAW_PART || p.kind().studs;}

    /** Return a corrected position only when the source has known studs and the target has
     * a known rectangular underside footprint. This does not bypass collisions/protection. */
    public static BrickPiece alignOnTop(BrickPiece target,BrickPiece support,double clickX,double clickZ){
        Studs base=footprint(support),upper=footprint(target);
        if(base==null || upper==null || !topStuds(support))return target;
        if(!Double.isFinite(clickX)||!Double.isFinite(clickZ))return target;
        // Find stud closest to the actual clicked point; must really be close to a stud.
        double best=Double.POSITIVE_INFINITY;
        double sx=0,sz=0;
        for(int i=0;i<base.x;i++)for(int j=0;j<base.z;j++){
            double[] p=support.stud(i,j);
            double d=Math.hypot(p[0]-clickX,p[1]-clickZ);
            if(d<best){best=d;sx=p[0];sz=p[1];}
        }
        if(best>0.78)return target;
        // Align the incoming stud nearest to the clicked stud. Coordinates stay integers
        // because the current world-storage format cannot encode fractional anchors.
        double delta=Double.POSITIVE_INFINITY;
        int dx=0,dz=0;
        for(int i=0;i<upper.x;i++)for(int j=0;j<upper.z;j++){
            double[] p=target.stud(i,j);
            int mx=(int)Math.round(sx-p[0]),mz=(int)Math.round(sz-p[1]);
            double error=Math.abs(sx-p[0]-mx)+Math.abs(sz-p[1]-mz);
            double move=Math.abs(mx)+Math.abs(mz);
            double score=error*100+move;
            if(score<delta){delta=score;dx=mx;dz=mz;}
        }
        if(delta>10)return target;
        return target.withPosition(target.x()+dx,support.top(),target.z()+dz);
    }
}
