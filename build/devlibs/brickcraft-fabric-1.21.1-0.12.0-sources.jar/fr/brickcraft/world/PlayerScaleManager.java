package fr.brickcraft.world;

import fr.brickcraft.net.PlayerScalePayload;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.Locale;

/** Uses vanilla GENERIC_SCALE: model, camera eye height AND server/client collision box stay in sync. */
public final class PlayerScaleManager {
    private PlayerScaleManager(){}
    public static final double MIN=0.125,MAX=4.0;
    private static final Identifier MODIFIER_ID=Identifier.of("brickcraft","player_exploration_scale");
    public static boolean allowed(double value){return Double.isFinite(value)&&value>=MIN&&value<=MAX;}
    public static void receive(ServerPlayerEntity player,PlayerScalePayload packet){
        double requested=packet.scale();
        if(!allowed(requested)||player.isSpectator()||
           !(player.isCreative() || player.getServer().isSingleplayer())){
            player.sendMessage(Text.literal("BrickCraft : taille refusee (partie solo ou mode creatif requis)"),false);return;
        }
        var attribute=player.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if(attribute==null)return;
        double oldEffectiveScale=attribute.getValue();
        EntityAttributeModifier previous=attribute.getModifier(MODIFIER_ID);
        attribute.removeModifier(MODIFIER_ID);
        if(Math.abs(requested-1.0)>0.00001)
            attribute.addPersistentModifier(new EntityAttributeModifier(MODIFIER_ID,requested-1.0,
                    EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE));
        player.calculateDimensions();
        // Avoid growing inside walls. A failed change restores the former attribute and bounding box.
        if(attribute.getValue()>oldEffectiveScale+1e-5 &&
           !player.getWorld().isSpaceEmpty(player,player.getBoundingBox())){
            attribute.removeModifier(MODIFIER_ID);
            if(previous!=null)attribute.addPersistentModifier(previous);
            player.calculateDimensions();
            player.sendMessage(Text.literal("BrickCraft : agrandissement impossible ici (obstacle). Deplace-toi."),false);
            return;
        }
        player.sendMessage(Text.literal(String.format(Locale.ROOT,
                "BrickCraft : taille x%.3f | hitbox et yeux adaptes (U pour regler)",requested)),true);
    }
    /** Retain the setting across respawns, if vanilla recreates the attribute container. */
    public static void respawn(ServerPlayerEntity oldPlayer,ServerPlayerEntity newPlayer,boolean alive){
        var oldAttr=oldPlayer.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        var nextAttr=newPlayer.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if(oldAttr==null||nextAttr==null)return;
        EntityAttributeModifier old=oldAttr.getModifier(MODIFIER_ID);
        if(old!=null){nextAttr.overwritePersistentModifier(old);newPlayer.calculateDimensions();}
    }
}
