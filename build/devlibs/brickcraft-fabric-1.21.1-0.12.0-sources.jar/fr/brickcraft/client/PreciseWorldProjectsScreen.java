package fr.brickcraft.client;

import fr.brickcraft.net.PreciseManagePayload;
import fr.brickcraft.net.PrecisePhysicsPayload;
import fr.brickcraft.net.PreciseManageStatusPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.List;

/** Dedicated world-projection manager: it never deletes a file on disk. */
public final class PreciseWorldProjectsScreen extends Screen {
    private final Screen previous;
    private List<PreciseManageStatusPayload.Entry> entries=List.of();
    private int selected=-1,page=0;
    private String status="Recherche des projections chargees...";
    private static final int PER_PAGE=6;
    private boolean requested=false;
    public PreciseWorldProjectsScreen(Screen previous){
        super(Text.literal("BrickCraft - Projections du monde"));this.previous=previous;
    }
    private void button(int x,int y,int w,int h,String text,Runnable callback){
        addDrawableChild(ButtonWidget.builder(Text.literal(text),b->callback.run()).dimensions(x,y,w,h).build());
    }
    @Override protected void init(){
        rebuild();
        if(!requested){requested=true;refresh();}
    }
    private void rebuild(){
        clearChildren();
        int x=Math.max(10,width/2-235),w=Math.min(470,width-20);
        int listY=68;
        for(int row=0;row<PER_PAGE;row++){
            final int which=page*PER_PAGE+row;
            if(which>=entries.size())break;
            var p=entries.get(which);
            button(x,listY+row*29,w,23,(which==selected?"[CHOISI] ":"")+
                    "#"+(which+1)+" | "+p.pieces()+" pieces | "+p.anchor().toShortString(),
                    ()->{selected=which;rebuild();});
        }
        int navY=Math.min(Math.max(listY+PER_PAGE*29+6,height-140),height-116);
        button(x,navY,(w-8)/2,20,"< Page",()->{page=Math.max(0,page-1);rebuild();});
        button(x+(w+8)/2,navY,(w-8)/2,20,"Page >",()->{
            page=Math.min(Math.max(0,(entries.size()-1)/PER_PAGE),page+1);rebuild();});
        button(x,navY+26,(w-8)/2,22,"Physique ON",()->askPhysics(true));
        button(x+(w+8)/2,navY+26,(w-8)/2,22,"Physique OFF",()->askPhysics(false));
        button(x,navY+54,w,20,"Retirer la projection selectionnee",this::askRemove);
        int third=(w-16)/3;
        button(x,navY+80,third,20,"Taille/hitbox (U)",
                ()->client.setScreen(new BrickPlayerScaleScreen(this)));
        button(x+third+8,navY+80,third,20,"Actualiser",this::refresh);
        button(x+2*(third+8),navY+80,third,20,"Retour import",()->client.setScreen(previous));
    }
    private void refresh(){
        if(client.player==null||client.world==null){status="Ouvre un monde pour gerer ses projections.";return;}
        status="Recherche des ancres dans les chunks charges (192 blocs)...";
        ClientPlayNetworking.send(PreciseManagePayload.list());
    }
    private void askPhysics(boolean enable){
        if(selected<0||selected>=entries.size()){status="Selectionne une projection d'abord.";return;}
        var p=entries.get(selected);
        String warning=enable?"Collisions fines LDraw (1/8 bloc), trous et pentes preservés. Plus couteux que la physique cubique.":
                "Retire uniquement les cellules appartenant a cette projection.";
        client.setScreen(new BrickConfirmScreen(this,enable?"Activer les collisions LEGO precises ?":"Retirer les collisions LEGO ?",
                warning,()->{status="Modification physique demandee au serveur...";
                    ClientPlayNetworking.send(new PrecisePhysicsPayload(p.anchor(),enable));}));
    }
    private void askRemove(){
        if(selected<0||selected>=entries.size()){status="Selectionne une projection dans la liste.";return;}
        var p=entries.get(selected);
        client.setScreen(new BrickConfirmScreen(this,"Retirer cette projection du monde ?",
                p.pieces()+" pieces, ancre "+p.anchor().toShortString()+". Le fichier original sera conserve.",
                ()->{status="Retrait demande au serveur...";ClientPlayNetworking.send(PreciseManagePayload.remove(p.anchor()));}));
    }
    public void receive(PreciseManageStatusPayload response){
        status=response.message();
        if(response.event()==PreciseManageStatusPayload.LIST){
            entries=response.projects();selected=-1;page=0;rebuild();
        }else if(response.event()==PreciseManageStatusPayload.REMOVED){
            entries=List.of();selected=-1;page=0;rebuild();refresh();
        }
    }
    @Override public void renderBackground(DrawContext ctx,int mouseX,int mouseY,float delta){}
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
        ctx.fill(0,0,width,height,0xFF0A1420);
        int x=Math.max(10,width/2-235),w=Math.min(470,width-20);
        ctx.fill(x-5,34,x+w+5,height-19,0xFF142535);
        ctx.fill(x-5,34,x+w+5,38,0xFF55CFD8);
        ctx.drawTextWithShadow(textRenderer,"BRICKCRAFT / PROJECTIONS 0.9.7",
                (width-textRenderer.getWidth("BRICKCRAFT / PROJECTIONS 0.9.7"))/2,14,0xFFE7F8FF);
        ctx.drawTextWithShadow(textRenderer,"Projections proches : "+entries.size()+" | page "+(page+1),x+4,45,0xFFA5CBD9);
        if(entries.isEmpty()){
            String empty="Aucune projection chargee dans les 192 blocs autour de toi.";
            ctx.drawTextWithShadow(textRenderer,empty,(width-textRenderer.getWidth(empty))/2,115,0xFFE7C992);
        }
        String message=status;
        while(textRenderer.getWidth(message)>width-24 && message.length()>8)
            message=message.substring(0,message.length()-4)+"...";
        ctx.fill(0,height-18,width,height,0xFF102132);
        ctx.drawTextWithShadow(textRenderer,message,10,height-14,0xFFE5CE94);
        super.render(ctx,mouseX,mouseY,delta);
    }
    @Override public void close(){client.setScreen(previous);}
}
