package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PrecisePhysicsPayload;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import java.util.*;

/** Conservative optional FULL VOXEL physics. Mutates only AIR, never overwrites existing terrain.
 * Every intended cell is registered on the anchor BEFORE placement, so cleanup can be retried. */
public final class PrecisePhysicsManager {
    private PrecisePhysicsManager(){}
    private record Job(ServerWorld world,BlockPos anchor,ServerPlayerEntity player,long[] cells,boolean enable,int next){}
    private static final Map<String,Job> JOBS=new LinkedHashMap<>();
    private static String key(ServerWorld world,BlockPos pos){return world.getRegistryKey().getValue()+":"+pos.asLong();}
    private static void say(ServerPlayerEntity p,String msg){if(p!=null)p.sendMessage(Text.literal("BrickCraft physique : "+msg),false);}
    public static void receive(ServerPlayerEntity player,PrecisePhysicsPayload data){
        ServerWorld world=player.getServerWorld();BlockPos anchor=data.anchor();
        if(!player.isCreative()||player.isSpectator()||player.squaredDistanceTo(anchor.getX()+.5,anchor.getY()+.5,anchor.getZ()+.5)>192*192||
           !world.isChunkLoaded(anchor)||!world.canPlayerModifyAt(player,anchor)||
           !(world.getBlockEntity(anchor) instanceof PreciseDisplayEntity be)||be.model()==null){
            say(player,"refuse : mode creatif, permissions et ancre chargee requis");return;
        }
        if(data.enable()){
            try{
                if(be.collisionCells().length>0){
                    long[] saved=be.collisionCells();
                    JOBS.put(key(world,anchor),new Job(world,anchor,player,saved,true,0));
                    say(player,"reprise de l'activation : "+saved.length+" cellules suivies");return;
                }
                var model=be.model();
                var cells=PreciseCollisionPlan.build(model.parts(),model.minX(),model.minY(),model.minZ(),
                        anchor.getX(),anchor.getY(),anchor.getZ(),id->{
                            String ref=PreciseReferenceMapper.geometryId(id);
                            return ref==null?null:LDrawLibrary.originalBounds(ref);
                        });
                java.util.ArrayList<Long> targets=new java.util.ArrayList<>();int solid=0;
                for(var c:cells){
                    BlockPos pos=new BlockPos(c.x(),c.y(),c.z());
                    if(!world.isInBuildLimit(pos)||!world.isChunkLoaded(pos)||!world.canPlayerModifyAt(player,pos))
                        throw new IllegalArgumentException("zone non chargee ou protegee : "+pos.toShortString());
                    if(world.getBlockState(pos).isAir())targets.add(pos.asLong());
                    else if(world.getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                        throw new IllegalArgumentException("collision avec une autre projection");
                    else solid++; // Existing terrain already has a physical collision; do not touch it.
                }
                long[] values=targets.stream().mapToLong(Long::longValue).toArray();
                if(values.length==0){say(player,"aucune cellule libre necessaire (terrain existant)");return;}
                be.setCollisionCells(values); // persisted ownership BEFORE generating proxy blocks
                JOBS.put(key(world,anchor),new Job(world,anchor,player,values,true,0));
                say(player,"activation progressive : "+values.length+" cellules, "+solid+" deja occupees par le terrain");
            }catch(Exception e){say(player,"refuse sans modifier le terrain : "+e.getMessage());}
        }else{
            long[] existing=be.collisionCells();
            if(existing.length==0){say(player,"aucune collision a retirer");return;}
            JOBS.put(key(world,anchor),new Job(world,anchor,player,existing,false,0));
            say(player,"retrait progressif de "+existing.length+" cellules");
        }
    }
    public static void tick(MinecraftServer server){
        var iter=JOBS.entrySet().iterator();int budget=128;
        while(iter.hasNext()&&budget>0){
            var entry=iter.next();Job job=entry.getValue();
            if(job.world().getBlockEntity(job.anchor()) instanceof PreciseDisplayEntity be){
                int i=job.next();
                while(i<job.cells().length && budget>0){
                    BlockPos pos=BlockPos.fromLong(job.cells()[i]);
                    if(job.world().isChunkLoaded(pos)){
                        if(job.enable()){
                            if(job.world().getBlockState(pos).isAir())
                                job.world().setBlockState(pos,BrickCraft.PRECISE_COLLISION.getDefaultState(),3);
                        }else if(job.world().getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                            job.world().setBlockState(pos,Blocks.AIR.getDefaultState(),3);
                    }
                    i++;budget--;
                }
                if(i>=job.cells().length){
                    if(!job.enable())be.setCollisionCells(new long[0]);
                    say(job.player(),(job.enable()?"activee":"retiree")+" : "+job.cells().length+" cellules traitees");
                    iter.remove();
                }else entry.setValue(new Job(job.world(),job.anchor(),job.player(),job.cells(),job.enable(),i));
            }else{iter.remove();} // Anchor removed: onStateReplaced has already run cleanup.
        }
    }
    /** Invoked only by anchor removal. Never removes unrelated Minecraft blocks. */
    public static void cleanup(ServerWorld world,PreciseDisplayEntity be){
        JOBS.remove(key(world,be.getPos()));
        for(long key:be.collisionCells()){
            BlockPos pos=BlockPos.fromLong(key);
            if(world.isChunkLoaded(pos)&&world.getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                world.setBlockState(pos,Blocks.AIR.getDefaultState(),3);
        }
        be.setCollisionCells(new long[0]);
    }
}
