package fr.brickcraft.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;

/** Invisible but solid voxel, created ONLY by a confirmed physics operation. No item is registered. */
public final class PreciseCollisionBlock extends Block {
    public PreciseCollisionBlock(Settings settings){super(settings);}
    @Override protected BlockRenderType getRenderType(BlockState state){return BlockRenderType.INVISIBLE;}
    @Override protected VoxelShape getOutlineShape(BlockState state,BlockView world,BlockPos pos,ShapeContext ctx){
        return VoxelShapes.empty(); // Do not interfere with the regular LEGO picker or block selection.
    }
    @Override protected VoxelShape getCollisionShape(BlockState state,BlockView world,BlockPos pos,ShapeContext ctx){
        return VoxelShapes.fullCube();
    }
}
