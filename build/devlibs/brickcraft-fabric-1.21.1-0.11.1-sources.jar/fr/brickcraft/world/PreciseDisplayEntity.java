package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseWorldModel;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;
import java.io.IOException;

/** Single-NBT-anchor storage; keep compressed original bytes even if complete.zip is missing. */
public final class PreciseDisplayEntity extends BlockEntity {
    private PreciseWorldModel model;
    private byte[] packed=new byte[0];
    private boolean decodeAttempted=false;
    private long[] collisionCells=new long[0];
    public long[] collisionCells(){return collisionCells.clone();}
    public void setCollisionCells(long[] cells){collisionCells=cells.clone();markDirty();}
    public PreciseDisplayEntity(BlockPos pos,BlockState state){super(BrickCraft.PRECISE_ENTITY,pos,state);}
    public PreciseWorldModel model(){
        if(model==null && packed.length>0 && !decodeAttempted){
            decodeAttempted=true;
            try{model=PreciseWorldModel.readBytes(packed);}catch(IOException ignored){}
        }
        return model;
    }
    public void setModel(PreciseWorldModel value)throws IOException{
        byte[] bytes=value.writeBytes();
        this.model=value;this.packed=bytes;this.decodeAttempted=true;markDirty();
        if(world instanceof net.minecraft.server.world.ServerWorld server)server.getChunkManager().markForUpdate(pos);
    }
    @Override protected void writeNbt(NbtCompound nbt,RegistryWrapper.WrapperLookup registry){
        super.writeNbt(nbt,registry);
        nbt.putByteArray("BrickCraftPreciseV1",packed);
        nbt.putLongArray("BrickCraftPhysicsCells",collisionCells);
    }
    @Override public void readNbt(NbtCompound nbt,RegistryWrapper.WrapperLookup registry){
        super.readNbt(nbt,registry);
        packed=nbt.getByteArray("BrickCraftPreciseV1");model=null;decodeAttempted=false;
        collisionCells=nbt.getLongArray("BrickCraftPhysicsCells");
        // Preserve corrupted/missing-library data in NBT instead of silently deleting it.
        if(packed.length>0)model();
    }
    @Override public @Nullable Packet<ClientPlayPacketListener> toUpdatePacket(){
        return BlockEntityUpdateS2CPacket.create(this);
    }
    @Override public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registry){
        return createNbt(registry);
    }
}
