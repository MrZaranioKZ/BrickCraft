package fr.brickcraft.mixin;

import fr.brickcraft.client.BrickCraftClient;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Intercept vanilla middle-click ONLY on BrickCraft cells; leave normal blocks unchanged. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Inject(method="doItemPick",at=@At("HEAD"),cancellable=true)
    private void brickcraft$pickBrick(CallbackInfo ci){
        if(BrickCraftClient.pickBrick((MinecraftClient)(Object)this))ci.cancel();
    }
}
