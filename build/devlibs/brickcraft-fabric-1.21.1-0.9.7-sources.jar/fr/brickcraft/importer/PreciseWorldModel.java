package fr.brickcraft.importer;

import fr.brickcraft.ldraw.LDrawLibrary;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Immutable, lossless LDraw assembly for a world-space VISUAL projection (not physical LEGO). */
public final class PreciseWorldModel {
    public static final int MAX_PARTS=4096;
    private static final int MAGIC=0x42505731; // BPW1
    private final List<LDrawProjectReader.Instance> parts;
    private final double minX,minY,minZ,maxX,maxY,maxZ;
    private final int mappedPrints;

    public record Bounds(double minX,double minY,double minZ,double maxX,double maxY,double maxZ,int mappedPrints) {
        public double width(){return maxX-minX;}
        public double height(){return maxY-minY;}
        public double depth(){return maxZ-minZ;}
    }
    private PreciseWorldModel(List<LDrawProjectReader.Instance> parts,Bounds bounds){
        this.parts=List.copyOf(parts);
        this.minX=bounds.minX();this.minY=bounds.minY();this.minZ=bounds.minZ();
        this.maxX=bounds.maxX();this.maxY=bounds.maxY();this.maxZ=bounds.maxZ();
        this.mappedPrints=bounds.mappedPrints();
    }
    public List<LDrawProjectReader.Instance> parts(){return parts;}
    public int mappedPrints(){return mappedPrints;}
    public double minX(){return minX;}public double minY(){return minY;}public double minZ(){return minZ;}
    public double width(){return maxX-minX;}public double height(){return maxY-minY;}public double depth(){return maxZ-minZ;}
    public static boolean validMatrix(double[] m){
        if(m==null||m.length!=9)return false;
        for(double v:m)if(!Double.isFinite(v)||Math.abs(v)>1.001)return false;
        for(int i=0;i<3;i++)for(int j=i;j<3;j++){
            double d=0;for(int k=0;k<3;k++)d+=m[i*3+k]*m[j*3+k];
            if(Math.abs(d-(i==j?1:0))>.025)return false;
        }
        return true;
    }
    public static Bounds analyze(List<LDrawProjectReader.Instance> parts){
        if(parts.isEmpty()||parts.size()>MAX_PARTS)throw new IllegalArgumentException("Projet : 1 a 4096 pieces maximum");
        double[] lo={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY};
        double[] hi={Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
        int prints=0;
        for(LDrawProjectReader.Instance p:parts){
            if(p.partId()==null || p.partId().length()>96 || !p.partId().matches("[A-Za-z0-9_./-]{1,96}") ||
                    !Double.isFinite(p.x())||!Double.isFinite(p.y())||!Double.isFinite(p.z()) ||
                    Math.abs(p.x())>100000 || Math.abs(p.y())>100000 || Math.abs(p.z())>100000 ||
                    !validMatrix(p.matrix()))throw new IllegalArgumentException("Position, reference ou matrice invalide : "+p.partId());
            String resolved=PreciseReferenceMapper.geometryId(p.partId());
            if(resolved==null)throw new IllegalArgumentException("Modele LDraw introuvable : "+p.partId());
            if(PreciseReferenceMapper.losesPrint(p.partId(),resolved))prints++;
            double[] b=LDrawLibrary.originalBounds(resolved);
            if(b==null)throw new IllegalArgumentException("Geometrie LDraw non chargeable : "+p.partId());
            // LDraw Y increases down. Minecraft Y increases up.
            for(int mask=0;mask<8;mask++){
                double lx=b[(mask&1)==0?0:3],ly=b[(mask&2)==0?1:4],lz=b[(mask&4)==0?2:5];
                double[] m=p.matrix();
                double x=(p.x()+m[0]*lx+m[1]*ly+m[2]*lz)/20.0;
                double y=-(p.y()+m[3]*lx+m[4]*ly+m[5]*lz)/20.0;
                double z=(p.z()+m[6]*lx+m[7]*ly+m[8]*lz)/20.0;
                double[] v={x,y,z};
                for(int i=0;i<3;i++){lo[i]=Math.min(lo[i],v[i]);hi[i]=Math.max(hi[i],v[i]);}
            }
        }
        Bounds bounds=new Bounds(lo[0],lo[1],lo[2],hi[0],hi[1],hi[2],prints);
        if(bounds.width()>128 || bounds.depth()>128 || bounds.height()>128)
            throw new IllegalArgumentException("Projection depasse 128 blocs sur un axe");
        return bounds;
    }
    public static PreciseWorldModel create(List<LDrawProjectReader.Instance> parts){
        return new PreciseWorldModel(parts,analyze(parts));
    }
    /** Short compressed representation for chunk NBT and block-entity update packets. */
    public byte[] writeBytes()throws IOException{
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(var out=new DataOutputStream(new GZIPOutputStream(bytes))){
            out.writeInt(MAGIC);out.writeInt(parts.size());
            for(var p:parts){
                out.writeUTF(p.partId());out.writeInt(p.color());
                out.writeDouble(p.x());out.writeDouble(p.y());out.writeDouble(p.z());
                for(double d:p.matrix())out.writeDouble(d);
            }
        }
        byte[] result=bytes.toByteArray();
        if(result.length>1024*1024)throw new IOException("Projection compressee trop volumineuse");
        return result;
    }
    public static PreciseWorldModel readBytes(byte[] bytes)throws IOException{
        if(bytes.length<12 || bytes.length>1024*1024)throw new IOException("NBT precise trop volumineux ou vide");
        try(var in=new DataInputStream(new GZIPInputStream(new ByteArrayInputStream(bytes)))){
            if(in.readInt()!=MAGIC)throw new IOException("Signature precise invalide");
            int count=in.readInt();if(count<1||count>MAX_PARTS)throw new IOException("Nombre de pieces invalide");
            ArrayList<LDrawProjectReader.Instance> parts=new ArrayList<>(count);
            for(int i=0;i<count;i++){
                String id=in.readUTF();int color=in.readInt();
                double x=in.readDouble(),y=in.readDouble(),z=in.readDouble();
                double[] m=new double[9];for(int j=0;j<9;j++)m[j]=in.readDouble();
                if(id.isEmpty()||id.length()>96||!Double.isFinite(x)||!Double.isFinite(y)||!Double.isFinite(z)||!validMatrix(m))
                    throw new IOException("Corruption du projet precise");
                parts.add(new LDrawProjectReader.Instance(id,color,x,y,z,m));
            }
            if(in.read()!=-1)throw new IOException("Donnees inattendues");
            return create(parts);
        }catch(IllegalArgumentException ex){throw new IOException("Donnees invalides : "+ex.getMessage(),ex);}
    }
}
