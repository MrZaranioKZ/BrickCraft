package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PrecisePhysicsPayload;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import java.util.*;

/** LDraw surface + multi-axis parity rasterization, quantized to 8^3 micro-voxels per cell.
 * Only AIR is filled; all cell ownership is recorded on the anchor BEFORE block placement.
 * A voxel mask is persisted on EACH proxy BlockEntity and synced to clients. */
public final class PrecisePhysicsManager {
    private PrecisePhysicsManager(){}
    private record Job(ServerWorld world,BlockPos anchor,ServerPlayerEntity player,long[] cells,
                       Map<Long,long[]> masks,long[] anchorMask,boolean enable,int next){}
    private static final Map<String,Job> JOBS=new LinkedHashMap<>();
    private static String key(ServerWorld world,BlockPos pos){return world.getRegistryKey().getValue()+":"+pos.asLong();}
    private static void say(ServerPlayerEntity p,String msg){if(p!=null)p.sendMessage(Text.literal("BrickCraft physique : "+msg),false);}
    public static void receive(ServerPlayerEntity player,PrecisePhysicsPayload data){
        ServerWorld world=player.getServerWorld();BlockPos anchor=data.anchor();
        if(!player.isCreative()||player.isSpectator()||player.squaredDistanceTo(anchor.getX()+.5,anchor.getY()+.5,anchor.getZ()+.5)>192*192||
           !world.isChunkLoaded(anchor)||!world.canPlayerModifyAt(player,anchor)||
           !(world.getBlockEntity(anchor) instanceof PreciseDisplayEntity be)||be.model()==null){
            say(player,"refuse : mode creatif, permissions et ancre chargee requis");return;
        }
        if(JOBS.containsKey(key(world,anchor))){say(player,"operation deja en cours sur cette projection");return;}
        if(data.enable()){
            try{
                var model=be.model();
                // Original library mesh, never reduced by the GPU triangle/LOD slider.
                Map<String,PreciseMeshCollisionPlan.Geometry> geometryCache=new HashMap<>();
                var result=PreciseMeshCollisionPlan.build(model.parts(),model.minX(),model.minY(),model.minZ(),
                        anchor.getX(),anchor.getY(),anchor.getZ(),id->geometryCache.computeIfAbsent(id,partId->{
                            String ref=PreciseReferenceMapper.geometryId(partId);
                            if(ref==null)return null;
                            double[] bounds=LDrawLibrary.originalBounds(ref);
                            LDrawLibrary.Mesh mesh=LDrawLibrary.mesh(ref);
                            return bounds==null||mesh==null?null:new PreciseMeshCollisionPlan.Geometry(mesh.xyz(),bounds);
                        }));
                long[] anchorMask=result.masks().getOrDefault(
                        new PreciseMeshCollisionPlan.Cell(anchor.getX(),anchor.getY(),anchor.getZ()),new long[0]);
                Map<Long,long[]> prepared=new LinkedHashMap<>();
                for(var cell:result.masks().entrySet()){
                    var c=cell.getKey();
                    if(c.x()==anchor.getX()&&c.y()==anchor.getY()&&c.z()==anchor.getZ())continue;
                    prepared.put(new BlockPos(c.x(),c.y(),c.z()).asLong(),cell.getValue());
                }
                long[] previous=be.collisionCells();
                if(previous.length>0){
                    // Resume an interrupted job without replacing any existing terrain or foreign proxies.
                    Map<Long,long[]> owned=new LinkedHashMap<>();
                    for(long pos:previous)if(prepared.containsKey(pos))owned.put(pos,prepared.get(pos));
                    if(owned.size()!=previous.length){
                        say(player,"anciennes collisions incompatibles : Physique OFF puis ON requis");return;
                    }
                    for(long encoded:previous){
                        BlockPos pos=BlockPos.fromLong(encoded);
                        if(!world.isChunkLoaded(pos)||!world.canPlayerModifyAt(player,pos))
                            throw new IllegalArgumentException("zone non chargee/protegee : "+pos.toShortString());
                        if(!world.getBlockState(pos).isAir()&&!world.getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                            throw new IllegalArgumentException("terrain modifie : "+pos.toShortString());
                    }
                    JOBS.put(key(world,anchor),new Job(world,anchor,player,previous,owned,anchorMask,true,0));
                    say(player,"reprise ou mise a jour de "+previous.length+" cellules 1/8 bloc");return;
                }
                Map<Long,long[]> free=new LinkedHashMap<>();int terrain=0;
                for(var entry:prepared.entrySet()){
                    BlockPos pos=BlockPos.fromLong(entry.getKey());
                    if(!world.isInBuildLimit(pos)||!world.isChunkLoaded(pos)||!world.canPlayerModifyAt(player,pos))
                        throw new IllegalArgumentException("zone non chargee ou protegee : "+pos.toShortString());
                    if(world.getBlockState(pos).isAir())free.put(entry.getKey(),entry.getValue());
                    else if(world.getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                        throw new IllegalArgumentException("collision avec une autre projection");
                    else terrain++;
                }
                long[] keys=free.keySet().stream().mapToLong(Long::longValue).toArray();
                if(keys.length==0){
                    be.setAnchorCollisionMask(anchorMask);
                    say(player,"seule l'ancre a une forme libre (autres cellules occupees par le terrain)");return;
                }
                be.setCollisionCells(keys); // ownership persisted before any world mutation
                JOBS.put(key(world,anchor),new Job(world,anchor,player,keys,free,anchorMask,true,0));
                say(player,"maillage reel : "+keys.length+" blocs x 8^3 sous-voxels, "+result.triangles()+
                        " triangles, "+terrain+" cellules IGNOREES (terrain existant). Placement progressif.");
            }catch(Exception e){say(player,"refuse avant pose : "+e.getMessage());}
        }else{
            long[] existing=be.collisionCells();
            if(existing.length==0 && !be.hasAnchorCollision()){say(player,"aucune collision a retirer");return;}
            JOBS.put(key(world,anchor),new Job(world,anchor,player,existing,Map.of(),new long[0],false,0));
            say(player,"retrait progressif de "+existing.length+" cellules");
        }
    }
    public static void tick(MinecraftServer server){
        var iter=JOBS.entrySet().iterator();int budget=128;
        while(iter.hasNext()&&budget>0){
            var entry=iter.next();Job job=entry.getValue();
            if(job.world().getBlockEntity(job.anchor()) instanceof PreciseDisplayEntity be){
                int i=job.next();
                while(i<job.cells().length && budget>0){
                    long encoded=job.cells()[i];BlockPos pos=BlockPos.fromLong(encoded);
                    if(!job.world().isChunkLoaded(pos))break; // Never silently skip an unloaded cell.
                    {
                        if(job.enable()){
                            if(job.world().getBlockState(pos).isAir())
                                job.world().setBlockState(pos,BrickCraft.PRECISE_COLLISION.getDefaultState(),3);
                            if(job.world().getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION)&&
                               job.world().getBlockEntity(pos) instanceof PreciseCollisionEntity cell){
                                long[] mask=job.masks().get(encoded);
                                if(mask!=null)cell.setMask(mask);
                            }
                        }else if(job.world().getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                            job.world().setBlockState(pos,Blocks.AIR.getDefaultState(),3);
                    }
                    i++;budget--;
                }
                if(i>=job.cells().length){
                    if(!job.enable())be.setCollisionCells(new long[0]);
                    be.setAnchorCollisionMask(job.enable()?job.anchorMask():new long[0]);
                    say(job.player(),(job.enable()?"activee (LDraw, 1/8 bloc)":"retiree")+
                            " : "+job.cells().length+" cellules traitees");
                    iter.remove();
                }else entry.setValue(new Job(job.world(),job.anchor(),job.player(),job.cells(),job.masks(),job.anchorMask(),job.enable(),i));
            }else iter.remove(); // anchor's onStateReplaced already invoked cleanup
        }
    }
    /** Triggered by anchor destruction; only touches loaded chunks and our own collision blocks. */
    public static void cleanup(ServerWorld world,PreciseDisplayEntity be){
        JOBS.remove(key(world,be.getPos()));
        for(long key:be.collisionCells()){
            BlockPos pos=BlockPos.fromLong(key);
            if(world.isChunkLoaded(pos)&&world.getBlockState(pos).isOf(BrickCraft.PRECISE_COLLISION))
                world.setBlockState(pos,Blocks.AIR.getDefaultState(),3);
        }
        be.setCollisionCells(new long[0]);
        be.setAnchorCollisionMask(new long[0]);
    }
}
