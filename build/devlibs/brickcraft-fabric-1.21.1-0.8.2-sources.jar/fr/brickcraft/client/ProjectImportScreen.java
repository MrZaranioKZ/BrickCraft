package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.StudioProjectAnalysis;
import fr.brickcraft.importer.BrickCraftProjectConverter;
import fr.brickcraft.ldraw.LDrawLibrary;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Direct .io/.mpd/.ldr loader, with lossless diagnostics and a source-coordinate preview. */
public final class ProjectImportScreen extends Screen {
    private final BrickStudioScreen parent;
    private final Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
    private List<Path> sources=List.of();
    private int index=0;
    private LDrawProjectReader.Result current;
    private StudioProjectAnalysis.Summary summary;
    private String status="Depose un fichier .io, .mpd ou .ldr dans le dossier imports.";
    private double orbit=.72, zoom=1.0, panX=0, panY=0;
    private boolean orbiting=false,panning=false;
    private int lastX,lastY;
    /** Points are fastest; volumes use the original LDraw bounding geometry and rotations. */
    private boolean volumePreview=true;
    private List<PreviewPart> previewParts=List.of();
    private double[] previewBounds=null; // min X/Y/Z, max X/Y/Z in original LDU
    private record PreviewPart(double[][] corners, int color, double depthX, double depthY, double depthZ){}
    private record Dot(int x,int y,double depth,int color){}
    private record Pixel(int x,int y){}
    private record Face(Pixel[] verts,double depth,int color){}
    public ProjectImportScreen(BrickStudioScreen parent){
        super(Text.literal("BrickCraft - Importer un projet BrickLink"));
        this.parent=parent;
        reloadFiles();
    }
    private void reloadFiles(){
        try{
            Files.createDirectories(folder);
            try(var stream=Files.list(folder)){
                sources=stream.filter(Files::isRegularFile).filter(p->{
                    String n=p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".io")||n.endsWith(".mpd")||n.endsWith(".ldr");
                }).sorted(Comparator.comparing(p->p.getFileName().toString(),String.CASE_INSENSITIVE_ORDER)).limit(200).toList();
            }
            index=Math.min(Math.max(0,index),Math.max(0,sources.size()-1));
        }catch(IOException e){status="Lecture du dossier impossible : "+e.getMessage();sources=List.of();}
    }
    private Path selectedFile(){return sources.isEmpty()?null:sources.get(index);}
    private void select(int offset){
        if(sources.isEmpty())return;
        index=Math.floorMod(index+offset,sources.size());
        current=null;summary=null;previewParts=List.of();previewBounds=null;
        status="Selection : "+selectedFile().getFileName();
    }
    private void analyze(){
        Path source=selectedFile();
        if(source==null){status="Aucun fichier. Copie ton .io dans config/brickcraft/imports/";return;}
        try{
            current=LDrawProjectReader.inspect(source);
            summary=StudioProjectAnalysis.analyze(current);
            buildPreview();
            status="Charge : "+summary.quickStatus()+" (apercu des volumes LDraw)";
            panX=panY=0;zoom=1;
            saveReport();
        }catch(Exception e){current=null;summary=null;previewParts=List.of();previewBounds=null;
            status="Erreur d'analyse : "+e.getMessage();}
    }
    private void saveReport()throws IOException {
        if(summary==null || selectedFile()==null)return;
        String name=selectedFile().getFileName().toString().replaceAll("[^a-zA-Z0-9._-]","_");
        Path report=folder.resolve("reports").resolve(name+".diagnostic.txt");
        Files.createDirectories(report.getParent());
        Files.writeString(report,StudioProjectAnalysis.report(summary,selectedFile().getFileName().toString()));
    }
    private void convert(){
        if(current==null){status="Analyse d'abord le projet";return;}
        if(summary.missingInstances()>0 || summary.angled()>0){
            status="Import sans perte impossible : references manquantes ou rotations libres (voir rapport)";return;
        }
        try{
            BrickCraftProjectConverter.Conversion c=BrickCraftProjectConverter.convert(current);
            if(!c.success()){
                status="Conversion refusee : "+c.errors().get(0);
                return;
            }
            if(parent.acceptImportedProject(c.grid(),c.pieces())){
                client.setScreen(parent);
            }else status="Le Studio refuse ce projet (limites ou collisions)";
        }catch(Exception e){status="Conversion echouee : "+e.getMessage();}
    }
    private void addButton(int x,int y,int w,int h,String label,Runnable click){
        if(w<16)return;
        addDrawableChild(ButtonWidget.builder(Text.literal(label),b->click.run()).dimensions(x,y,w,h).build());
    }
    @Override protected void init(){
        int pWidth=Math.max(228,Math.min(315,width/3));
        addButton(10,40,(pWidth-25)/2,20,"< Projet",()->select(-1));
        addButton((pWidth+5)/2,40,(pWidth-25)/2,20,"Projet >",()->select(1));
        addButton(10,67,pWidth-20,20,"Actualiser les fichiers",()->{reloadFiles();status="Dossier actualise";});
        addButton(10,93,pWidth-20,20,"1. Analyser / previsualiser",this::analyze);
        addButton(10,120,pWidth-20,20,"2. Importer dans le Studio (strict)",this::convert);
        addButton(10,147,pWidth-20,18,volumePreview?"Apercu : volumes (changer)":"Apercu : points (changer)",()->{
            volumePreview=!volumePreview;clearAndInit();
        });
        addButton(10,height-47,pWidth-20,20,"Retour au Studio",()->client.setScreen(parent));
    }
    @Override public void renderBackground(DrawContext context,int mx,int my,float delta){}
    private void drawText(DrawContext ctx,String s,int x,int y,int max,int color){
        if(max<10)return;
        if(textRenderer.getWidth(s)>max){
            String suffix="...";
            int n=s.length();
            while(n>0 && textRenderer.getWidth(s.substring(0,n)+suffix)>max)n--;
            s=s.substring(0,n)+suffix;
        }
        ctx.drawTextWithShadow(textRenderer,s,x,y,color);
    }
    @Override public void render(DrawContext ctx,int mx,int my,float dt){
        ctx.fill(0,0,width,height,0xFF0B111A);
        int side=Math.max(228,Math.min(315,width/3));
        int left=side+6, top=36, right=width-8,bottom=height-34;
        ctx.fill(4,30,side,bottom,0xFF162330);
        ctx.fill(left,top,right,bottom,0xFF0A1C29);
        drawText(ctx,"BRICKCRAFT  /  IMPORT IO-LDRAW 0.8.2",10,10,width-20,0xFFE2F4FF);
        // All diagnostics are constrained above the footer button, at every GUI scale.
        int statsEnd=height-54;
        ctx.enableScissor(6,169,side-4,Math.max(170,statsEnd));
        drawText(ctx,"Fichiers : "+sources.size(),12,174,side-22,0xFF9BC4D7);
        drawText(ctx,selectedFile()==null?"Aucun fichier detecte":selectedFile().getFileName().toString(),12,191,side-22,0xFFFFFFFF);
        if(summary!=null){
            int y=218;
            String[] lines={
                "Pieces : "+summary.pieces()+" | Formes : "+summary.designs(),
                "Couleurs : "+summary.colors()+" | Sous-modeles : "+summary.project().submodels(),
                "Manquantes : "+summary.missingInstances()+" occurrences",
                "Rotations libres : "+summary.angled(),
                "Decalages X/Z : "+summary.fractionalX()+" / "+summary.fractionalZ(),
                "Hauteurs fines : "+summary.fractionalY(),
                "Details : imports/reports/*.txt"
            };
            for(String line:lines){
                if(y+10>statsEnd)break;
                drawText(ctx,line,12,y,side-22,y==218?0xFF71E2D5:0xFFA7C6D8);
                y+=15;
            }
        }else{
            drawText(ctx,"Place tes projets dans :",12,218,side-20,0xFF9FC4D9);
            drawText(ctx,"config/brickcraft/imports/",12,235,side-20,0xFF8EDBE1);
            drawText(ctx,"Formats : .io, .ldr, .mpd",12,252,side-20,0xFF9FC4D9);
        }
        ctx.disableScissor();
        drawText(ctx,"Clic droit : orbite | Molette : zoom | Milieu : deplacer",left+7,top+8,right-left-14,0xFFB0D9E8);
        drawText(ctx,volumePreview?"Volumes LDraw orientes (gabarits, sans surfaces exactes)":
                "Origines colorees des pieces (mode rapide)",left+7,top+22,right-left-14,0xFF9BB9C8);
        if(summary!=null){
            if(volumePreview)renderVolumes(ctx,left+5,top+38,right-5,bottom-5);
            else renderDots(ctx,left+5,top+38,right-5,bottom-5);
        }
        // The footer always has its own opaque band, so no overdraw from the viewport.
        ctx.fill(0,height-24,width,height,0xFF142638);
        drawText(ctx,status,10,height-18,width-20,0xFFEED29A);
        super.render(ctx,mx,my,dt);
    }
    /**
     * Source coordinates are preserved: each part box is transformed by its full
     * 3x3 LDraw matrix. No grid rounding, replacement design or world export here.
     * The boxes are only a fast diagnostic preview, not actual part triangles.
     */
    private void buildPreview(){
        if(summary==null){previewParts=List.of();previewBounds=null;return;}
        var source=summary.project().parts();
        java.util.Map<String,double[]> boundsCache=new java.util.HashMap<>();
        ArrayList<PreviewPart> result=new ArrayList<>(source.size());
        double[] all={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,
                      Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
        for(var p:source){
            // The actual LDraw bounds refer to its local origin, not the normalized Minecraft mesh.
            double[] local=boundsCache.computeIfAbsent(p.partId(),id->{
                double[] b=LDrawLibrary.originalBounds(id);
                return b!=null?b:new double[]{-10,-12,-10,10,12,10};
            });
            double[] m=p.matrix();
            double[][] corners=new double[8][3];
            for(int k=0;k<8;k++){
                double x=((k&1)==0)?local[0]:local[3];
                double y=((k&2)==0)?local[1]:local[4];
                double z=((k&4)==0)?local[2]:local[5];
                double[] point={p.x()+m[0]*x+m[1]*y+m[2]*z,
                                p.y()+m[3]*x+m[4]*y+m[5]*z,
                                p.z()+m[6]*x+m[7]*y+m[8]*z};
                corners[k]=point;
                for(int axis=0;axis<3;axis++){
                    all[axis]=Math.min(all[axis],point[axis]);
                    all[axis+3]=Math.max(all[axis+3],point[axis]);
                }
            }
            var color=LDrawLibrary.color(p.color());
            int argb=color==null?0xFFCED4DE:0xFF000000|color.rgb();
            result.add(new PreviewPart(corners,argb,p.x(),p.y(),p.z()));
        }
        previewParts=List.copyOf(result);
        previewBounds=all;
    }

    private void renderVolumes(DrawContext ctx,int x1,int y1,int x2,int y2){
        if(previewParts.isEmpty() || previewBounds==null || x2<=x1 || y2<=y1)return;
        double[] b=previewBounds;
        double cx=(b[0]+b[3])/2,cy=(b[1]+b[4])/2,cz=(b[2]+b[5])/2;
        double sx=Math.max(20,b[3]-b[0]),sy=Math.max(8,b[4]-b[1]),sz=Math.max(20,b[5]-b[2]);
        double co=Math.cos(orbit),si=Math.sin(orbit);
        double boundW=1,boundH=1;
        for(int i=0;i<8;i++){
            double x=((i&1)==0?-sx:sx)/2;
            double y=((i&2)==0?-sy:sy)/2;
            double z=((i&4)==0?-sz:sz)/2;
            boundW=Math.max(boundW,Math.abs(x*co-z*si));
            boundH=Math.max(boundH,Math.abs((x*si+z*co)*.40+y*.86));
        }
        double unit=Math.max(0.0001,Math.min((x2-x1-36)/(2*boundW),(y2-y1-36)/(2*boundH))*zoom);
        double centerX=(x1+x2)*.5+panX,centerY=(y1+y2)*.5+panY;
        // Painters' order for opaque gabarits. The low LOD is deliberately cheap.
        ArrayList<PreviewPart> ordered=new ArrayList<>(previewParts);
        ordered.sort(Comparator.comparingDouble(p->(p.depthX()-cx)*si+(p.depthZ()-cz)*co-(p.depthY()-cy)*.55));
        ctx.enableScissor(x1,y1,x2,y2);
        int rendered=0;
        for(PreviewPart part:ordered){
            Pixel[] pts=new Pixel[8];
            int minx=Integer.MAX_VALUE,miny=Integer.MAX_VALUE,maxx=Integer.MIN_VALUE,maxy=Integer.MIN_VALUE;
            for(int k=0;k<8;k++){
                double[] v=part.corners()[k];
                double x=v[0]-cx,y=v[1]-cy,z=v[2]-cz;
                int px=(int)Math.round(centerX+(x*co-z*si)*unit);
                int py=(int)Math.round(centerY+((x*si+z*co)*.4+y*.86)*unit);
                pts[k]=new Pixel(px,py);
                minx=Math.min(minx,px);maxx=Math.max(maxx,px);
                miny=Math.min(miny,py);maxy=Math.max(maxy,py);
            }
            if(maxx<x1 || minx>x2 || maxy<y1 || miny>y2)continue;
            // Small distant parts are 2px dots; larger parts show 3D gabarits.
            if((maxx-minx)*(maxy-miny)<9){
                int px=(minx+maxx)/2,py=(miny+maxy)/2;
                ctx.fill(px-1,py-1,px+2,py+2,part.color());
            }else{
                // Sort all six faces for this part, including arbitrary LDraw rotation.
                int[][] faces={{0,4,5,1},{2,3,7,6},{0,2,6,4},
                               {1,5,7,3},{0,1,3,2},{4,6,7,5}};
                int[] shades={78,112,84,96,90,73};
                ArrayList<Face> orderedFaces=new ArrayList<>(6);
                for(int f=0;f<faces.length;f++){
                    Pixel[] v=new Pixel[4];double depth=0;
                    for(int k=0;k<4;k++){
                        int ix=faces[f][k];v[k]=pts[ix];
                        depth+=(part.corners()[ix][0]-cx)*si+(part.corners()[ix][2]-cz)*co-(part.corners()[ix][1]-cy)*.55;
                    }
                    orderedFaces.add(new Face(v,depth,shade(part.color(),shades[f])));
                }
                orderedFaces.sort(Comparator.comparingDouble(Face::depth));
                for(Face face:orderedFaces)fillFace(ctx,face.verts(),face.color(),x1,y1,x2,y2);
            }
            rendered++;
        }
        ctx.disableScissor();
        drawText(ctx,"Apercu: "+rendered+" volumes (gabarits, pas maillages exacts)",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    private static int shade(int color,int factor){
        int r=Math.min(255,((color>>>16)&255)*factor/100),g=Math.min(255,((color>>>8)&255)*factor/100);
        int b=Math.min(255,(color&255)*factor/100);
        return (color&0xFF000000)|(r<<16)|(g<<8)|b;
    }
    private static void fillFace(DrawContext ctx,Pixel[] v,int color,int x1,int y1,int x2,int y2){
        int lo=Integer.MAX_VALUE,hi=Integer.MIN_VALUE;
        for(Pixel p:v){lo=Math.min(lo,p.y());hi=Math.max(hi,p.y());}
        lo=Math.max(lo,y1);hi=Math.min(hi,y2-1);
        for(int y=lo;y<=hi;y++){
            double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
            for(int i=0;i<v.length;i++){
                Pixel a=v[i],b=v[(i+1)%v.length];
                if(a.y()==b.y()||y<Math.min(a.y(),b.y())||y>=Math.max(a.y(),b.y()))continue;
                double xx=a.x()+(double)(y-a.y())*(b.x()-a.x())/(b.y()-a.y());
                min=Math.min(min,xx);max=Math.max(max,xx);
            }
            if(max>=min){
                int lx=Math.max(x1,(int)Math.floor(min));int hx=Math.min(x2,(int)Math.ceil(max)+1);
                if(hx>lx)ctx.fill(lx,y,hx,y+1,color);
            }
        }
    }

    private void renderDots(DrawContext ctx,int x1,int y1,int x2,int y2){
        if(summary==null||x2<=x1||y2<=y1)return;
        int count=summary.project().parts().size();
        if(count==0)return;
        double spanX=Math.max(20,summary.maxX()-summary.minX());
        double spanZ=Math.max(20,summary.maxZ()-summary.minZ());
        double spanY=Math.max(8,summary.maxY()-summary.minY());
        double c=Math.cos(orbit),s=Math.sin(orbit);
        double[][] sample={{0,0,0},{spanX,0,0},{0,0,spanZ},{spanX,0,spanZ},
                           {0,spanY,0},{spanX,spanY,0},{0,spanY,spanZ},{spanX,spanY,spanZ}};
        double boundX=1,boundY=1;
        for(double[] v:sample){
            double px=(v[0]-spanX/2)*c-(v[2]-spanZ/2)*s;
            double py=((v[0]-spanX/2)*s+(v[2]-spanZ/2)*c)*.40-(v[1]-spanY/2)*.86;
            boundX=Math.max(boundX,Math.abs(px));boundY=Math.max(boundY,Math.abs(py));
        }
        double unit=Math.min((x2-x1-32)/2.0/boundX,(y2-y1-32)/2.0/boundY)*zoom;
        double centerX=(x1+x2)/2.+panX,centerY=(y1+y2)/2.+panY;
        ArrayList<Dot> dots=new ArrayList<>(count);
        for(var p:summary.project().parts()){
            double xx=p.x()-summary.minX()-spanX/2;
            double zz=p.z()-summary.minZ()-spanZ/2;
            double yy=summary.maxY()-p.y()-spanY/2;
            double screenX=centerX+(xx*c-zz*s)*unit;
            double depth=xx*s+zz*c;
            double screenY=centerY+(depth*.40-yy*.86)*unit;
            if(screenX<x1+1||screenX>x2-1||screenY<y1+1||screenY>y2-1)continue;
            var color=LDrawLibrary.color(p.color());
            dots.add(new Dot((int)screenX,(int)screenY,depth,color==null?0xFFCED4DE:0xFF000000|color.rgb()));
        }
        dots.sort(Comparator.comparingDouble(Dot::depth));
        ctx.enableScissor(x1,y1,x2,y2);
        for(Dot d:dots){
            int size=Math.max(2,Math.min(5,(int)(unit*8)));
            ctx.fill(d.x-size/2,d.y-size/2,d.x+size/2+1,d.y+size/2+1,d.color);
        }
        ctx.disableScissor();
        drawText(ctx,count+" origines de pieces (mode rapide)",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    @Override public boolean mouseClicked(double x,double y,int btn){
        if(x>=Math.max(228,Math.min(315,width/3))+6 && y>36 && y<height-34){
            if(btn==1){orbiting=true;lastX=(int)x;lastY=(int)y;return true;}
            if(btn==2){panning=true;lastX=(int)x;lastY=(int)y;return true;}
        }
        return super.mouseClicked(x,y,btn);
    }
    @Override public boolean mouseDragged(double x,double y,int button,double dx,double dy){
        if(orbiting && button==1){orbit+=dx*.01;return true;}
        if(panning && button==2){panX+=dx;panY+=dy;return true;}
        return super.mouseDragged(x,y,button,dx,dy);
    }
    @Override public boolean mouseReleased(double x,double y,int btn){
        if(btn==1)orbiting=false;
        if(btn==2)panning=false;
        return super.mouseReleased(x,y,btn);
    }
    @Override public boolean mouseScrolled(double x,double y,double horiz,double vert){
        if(x>Math.max(228,Math.min(315,width/3))){zoom=Math.max(.1,Math.min(15,zoom*Math.pow(1.15,vert)));return true;}
        return super.mouseScrolled(x,y,horiz,vert);
    }
    @Override public boolean keyPressed(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE){client.setScreen(parent);return true;}
        if(key==GLFW.GLFW_KEY_R){reloadFiles();return true;}
        if(key==GLFW.GLFW_KEY_ENTER){analyze();return true;}
        if(key==GLFW.GLFW_KEY_V){volumePreview=!volumePreview;clearAndInit();return true;}
        return super.keyPressed(key,scan,mods);
    }
}
