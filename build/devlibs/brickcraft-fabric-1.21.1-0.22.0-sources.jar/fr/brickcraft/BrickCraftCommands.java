package fr.brickcraft;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.ldraw.LDrawLibrary;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.argument.BlockPosArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import java.util.Locale;
import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

/** Server-authoritative LEGO placement, usable from chat, /execute, functions and command blocks. */
public final class BrickCraftCommands {
    private BrickCraftCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher,registryAccess,environment)->{
            var root=literal("brickcraft").requires(source->source.hasPermissionLevel(2))
                    .executes(c->help(c.getSource()));
            root.then(literal("help").executes(c->help(c.getSource())));
            root.then(literal("list").executes(c->{
                StringBuilder names=new StringBuilder();
                for(BrickKind kind:BrickKind.values())if(kind!=BrickKind.LDRAW_PART){
                    if(names.length()>0)names.append(", ");
                    names.append(kind.name().toLowerCase(Locale.ROOT));
                }
                c.getSource().sendFeedback(()->Text.literal("BrickCraft : "+names),false);
                return 1;
            }));
            root.then(literal("place").then(argument("kind",StringArgumentType.word())
                    .suggests((c,b)->{
                        for(BrickKind k:BrickKind.values())if(k!=BrickKind.LDRAW_PART)
                            b.suggest(k.name().toLowerCase(Locale.ROOT));
                        return b.buildFuture();
                    })
                    .then(positionBranch(false))));
            root.then(literal("ldraw").then(argument("part",StringArgumentType.word())
                    .suggests((c,b)->{
                        for(var p:LDrawLibrary.search(b.getRemaining(),36))b.suggest(p.id());
                        return b.buildFuture();
                    })
                    .then(positionBranch(true))));
            root.then(literal("give").then(argument("part",StringArgumentType.word())
                    .suggests((c,b)->{
                        for(var p:LDrawLibrary.search(b.getRemaining(),36))b.suggest(p.id());
                        return b.buildFuture();
                    })
                    .executes(c->give(c,1))
                    .then(argument("count",IntegerArgumentType.integer(1,64))
                            .executes(c->give(c,IntegerArgumentType.getInteger(c,"count"))))));
            dispatcher.register(root);
        });
    }

    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<ServerCommandSource, net.minecraft.command.argument.PosArgument> positionBranch(boolean ldraw) {
        return argument("pos",BlockPosArgumentType.blockPos())
                .executes(c->place(c,ldraw,false,false))
                .then(argument("color",StringArgumentType.word())
                        .executes(c->place(c,ldraw,true,false))
                        .then(argument("angle",IntegerArgumentType.integer(-359,359))
                                .executes(c->place(c,ldraw,true,true))));
    }

    private static int help(ServerCommandSource source){
        source.sendFeedback(()->Text.literal("BrickCraft : /brickcraft place <forme> <x y z> [couleur] [angle]"),false);
        source.sendFeedback(()->Text.literal("BrickCraft : /brickcraft ldraw <ref> <x y z> [couleur] [angle]"),false);
        source.sendFeedback(()->Text.literal("BrickCraft : /brickcraft give <ref> [quantite] | /brickcraft list"),false);
        source.sendFeedback(()->Text.literal("Couleurs : rouge, blanc, blue, #FF0000 ou 0xFF0000. Coordonnees relatives ~ admises."),false);
        return 1;
    }

    private static int place(CommandContext<ServerCommandSource> c,boolean ldraw,boolean withColor,boolean withAngle){
        ServerCommandSource source=c.getSource();
        String ref=StringArgumentType.getString(c,ldraw?"part":"kind");
        BrickKind kind;
        String id="";
        if(ldraw){
            id=ref.toLowerCase(Locale.ROOT);
            if(!id.matches("[a-z0-9_-]{1,32}") || !LDrawLibrary.contains(id) || LDrawLibrary.mesh(id)==null){
                source.sendError(Text.literal("Reference LDraw absente : "+ref));return 0;
            }
            kind=BrickKind.LDRAW_PART;
        }else{
            try{kind=BrickKind.valueOf(ref.toUpperCase(Locale.ROOT));}
            catch(IllegalArgumentException ex){source.sendError(Text.literal("Forme inconnue. /brickcraft list"));return 0;}
            if(kind==BrickKind.LDRAW_PART){source.sendError(Text.literal("Utilise /brickcraft ldraw <ref> ..."));return 0;}
        }
        int color=0xF4F4F4;
        try{
            if(withColor)color=BrickCommandPalette.rgb(StringArgumentType.getString(c,"color"));
        }catch(IllegalArgumentException ex){source.sendError(Text.literal(ex.getMessage()));return 0;}
        int yaw=withAngle?Math.floorMod(IntegerArgumentType.getInteger(c,"angle"),360):0;
        BlockPos target=BlockPosArgumentType.getBlockPos(c,"pos");
        if(!source.getWorld().isInBuildLimit(target)||!source.getWorld().isChunkLoaded(target)){
            source.sendError(Text.literal("Chunk non charge ou hors du monde : "+target.toShortString()));return 0;
        }
        BrickPiece piece=new BrickPiece(kind,color,target.getX(),target.getY()*5,target.getZ(),yaw/90,yaw,0,0,id,-1);
        if(!BrickCraft.placeCommand(source.getWorld(),source.getPlayer(),piece)){
            source.sendError(Text.literal("Placement refuse : collision, terrain, protection ou trop de cellules."));
            return 0;
        }
        String name=ldraw?id:kind.name().toLowerCase(Locale.ROOT);
        source.sendFeedback(()->Text.literal("BrickCraft : "+name+" place a "+target.toShortString()),false);
        return 1;
    }

    private static int give(CommandContext<ServerCommandSource> c,int count){
        ServerCommandSource source=c.getSource();
        String id=StringArgumentType.getString(c,"part").toLowerCase(Locale.ROOT);
        if(!id.matches("[a-z0-9_-]{1,32}") || !LDrawLibrary.contains(id) || LDrawLibrary.mesh(id)==null){
            source.sendError(Text.literal("Reference LDraw non installee : "+id));return 0;
        }
        ServerPlayerEntity player=source.getPlayer();
        if(player==null){source.sendError(Text.literal("La commande give doit etre lancee par un joueur."));return 0;}
        ItemStack item=BrickPartStacks.ldraw(id,count);
        player.giveItemStack(item);
        source.sendFeedback(()->Text.literal("BrickCraft : "+count+" piece(s) LDraw "+id+" ajoutee(s) a ton inventaire"),false);
        return count;
    }
}
