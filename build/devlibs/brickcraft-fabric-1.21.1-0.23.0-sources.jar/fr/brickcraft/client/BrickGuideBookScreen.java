package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.List;

/** Short visual guide, not a wall of instructions. All text is a translation key. */
public final class BrickGuideBookScreen extends Screen {
    private static final int PAGE_COUNT = 6;
    private int page;
    public BrickGuideBookScreen() {super(Text.translatable("guide.brickcraft.title"));}
    public static void open() {
        MinecraftClient mc=MinecraftClient.getInstance();
        if (mc!=null && mc.currentScreen==null) mc.setScreen(new BrickGuideBookScreen());
    }
    private Text txt(String key){return Text.translatable("guide.brickcraft."+key);}
    @Override protected void init(){
        int w=Math.min(384,width-28),left=(width-w)/2,foot=Math.min(height-31,Math.max(134,height/2+95));
        addDrawableChild(ButtonWidget.builder(txt("previous"),b->change(-1))
                .dimensions(left+12,foot,Math.max(60,(w-36)/3),20).build()).active=page>0;
        addDrawableChild(ButtonWidget.builder(txt("close"),b->close())
                .dimensions(left+12+(w-36)/3+6,foot,Math.max(55,(w-36)/3),20).build());
        addDrawableChild(ButtonWidget.builder(txt("next"),b->change(1))
                .dimensions(left+12+((w-36)/3+6)*2,foot,Math.max(60,(w-36)/3),20).build()).active=page<PAGE_COUNT-1;
    }
    private void change(int d){page=Math.clamp(page+d,0,PAGE_COUNT-1);clearAndInit();}
    @Override public void renderBackground(DrawContext ctx,int mouseX,int mouseY,float delta){}
    @Override public void render(DrawContext ctx,int mx,int my,float delta){
        ctx.fill(0,0,width,height,0xC908101A);
        int w=Math.min(384,width-28),x=(width-w)/2,y=Math.max(15,height/2-124),h=Math.min(244,height-y-33);
        ctx.fill(x,y,x+w,y+h,0xFF152435);
        ctx.fill(x+3,y+3,x+w-3,y+h-3,0xFFE8E4D9);
        ctx.fill(x+8,y+8,x+w-8,y+35,0xFF1F3347);
        ctx.drawTextWithShadow(textRenderer,txt("title"),x+18,y+17,0xFFF7F7F7);
        ctx.drawTextWithShadow(textRenderer,txt("page"+(page+1)+".title"),x+17,y+48,0xFF23455A);
        ctx.drawTextWithShadow(textRenderer,Text.literal((page+1)+" / "+PAGE_COUNT),x+w-55,y+48,0xFF506B80);
        int iconY=y+70;
        // Item renders are native Minecraft visuals, not decorative text pretending to be screenshots.
        switch(page){
            case 0 -> {icon(ctx,BrickCraft.GUIDE_BOOK,x+22,iconY);icon(ctx,BrickCraft.TOOL,x+72,iconY);icon(ctx,BrickCraft.LDRAW_ITEM,x+122,iconY);}
            case 1 -> {icon(ctx,BrickCraft.TOOL,x+22,iconY);icon(ctx,BrickCraft.PART_ITEMS.get(fr.brickcraft.core.BrickKind.BRICK_2X4),x+72,iconY);drawArrow(ctx,x+53,iconY+8);}
            case 2 -> {icon(ctx,BrickCraft.LDRAW_ITEM,x+22,iconY);drawArrow(ctx,x+53,iconY+8);icon(ctx,BrickCraft.TOOL,x+72,iconY);}
            case 3 -> {icon(ctx,BrickCraft.LDRAW_ITEM,x+22,iconY);drawArrow(ctx,x+53,iconY+8);icon(ctx,BrickCraft.PART_ITEMS.get(fr.brickcraft.core.BrickKind.BRICK_2X4),x+72,iconY);}
            case 4 -> {icon(ctx,BrickCraft.TOOL,x+22,iconY);icon(ctx,BrickCraft.LDRAW_ITEM,x+72,iconY);}
            case 5 -> {icon(ctx,BrickCraft.PART_ITEMS.get(fr.brickcraft.core.BrickKind.SLOPE_1X2),x+22,iconY);icon(ctx,BrickCraft.GUIDE_BOOK,x+72,iconY);}
        }
        int txtY=iconY+35;
        List<OrderedText> lines=textRenderer.wrapLines(txt("page"+(page+1)+".body"),w-38);
        int maxLines=Math.max(1,(Math.min(y+h-40,height-44)-txtY)/13);
        for(int i=0;i<Math.min(lines.size(),maxLines);i++)
            ctx.drawTextWithShadow(textRenderer,lines.get(i),x+19,txtY+i*13,0xFF344B5D);
        super.render(ctx,mx,my,delta);
    }
    private void icon(DrawContext ctx,net.minecraft.item.Item item,int x,int y){
        if(item!=null){ctx.fill(x-3,y-3,x+20,y+20,0xFFCADBE2);ctx.drawItem(new ItemStack(item),x,y);}
    }
    private void drawArrow(DrawContext ctx,int x,int y){
        ctx.fill(x,y,x+11,y+2,0xFF5B9CB2);ctx.fill(x+8,y-3,x+11,y+5,0xFF5B9CB2);
    }
    @Override public boolean keyPressed(int key,int scan,int modifiers){
        if(key==GLFW.GLFW_KEY_LEFT){change(-1);return true;}
        if(key==GLFW.GLFW_KEY_RIGHT){change(1);return true;}
        return super.keyPressed(key,scan,modifiers);
    }
    @Override public void close(){client.setScreen(null);}
    @Override public boolean shouldPause(){return false;}
}
