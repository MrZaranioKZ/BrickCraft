package fr.brickcraft.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** A separate, modal confirmation: no parent widgets are drawn behind it. */
public final class BrickConfirmScreen extends Screen {
    private final Screen previous;
    private final String detail;
    private final Runnable confirm;
    public BrickConfirmScreen(Screen previous,String title,String detail,Runnable confirm){
        super(Text.literal(BrickI18n.tr(title)));this.previous=previous;this.detail=detail;this.confirm=confirm;
    }
    @Override protected void init(){
        int center=width/2,y=height/2+28;
        addDrawableChild(ButtonWidget.builder(Text.literal(BrickI18n.tr("Confirmer")),b->{client.setScreen(previous);confirm.run();})
                .dimensions(center-154,y,148,22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(BrickI18n.tr("Annuler")),b->client.setScreen(previous))
                .dimensions(center+6,y,148,22).build());
    }
    @Override public void renderBackground(DrawContext ctx,int mouseX,int mouseY,float delta){}
    @Override public void render(DrawContext ctx,int mouseX,int mouseY,float delta){
        ctx.fill(0,0,width,height,0xFF0B1420);
        int x=Math.max(12,width/2-220),r=Math.min(width-12,width/2+220);
        ctx.fill(x,height/2-66,r,height/2+71,0xFF182A3B);
        ctx.fill(x,height/2-66,r,height/2-62,0xFFE3AB66);
        ctx.drawTextWithShadow(textRenderer,BrickI18n.tr(title),(width-textRenderer.getWidth(title))/2,
                height/2-45,0xFFF5E9D8);
        String s=detail;
        while(textRenderer.getWidth(s)>r-x-24 && s.length()>8)s=s.substring(0,s.length()-4)+"...";
        ctx.drawTextWithShadow(textRenderer,BrickI18n.tr(s),(width-textRenderer.getWidth(s))/2,
                height/2-15,0xFFD9E3EF);
        super.render(ctx,mouseX,mouseY,delta);
    }
    @Override public void close(){client.setScreen(previous);}
}
