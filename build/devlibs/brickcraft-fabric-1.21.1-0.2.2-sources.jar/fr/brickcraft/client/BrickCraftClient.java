package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class BrickCraftClient implements ClientModInitializer {
    private static KeyBinding studioKey, nextKey, turnKey, colorKey;

    @Override public void onInitializeClient() {
        BlockEntityRendererRegistry.register(BrickCraft.CELL_ENTITY, BrickCellRenderer::new);
        studioKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.studio",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_B,"category.brickcraft"));
        nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.next",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_V,"category.brickcraft"));
        turnKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.turn",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_R,"category.brickcraft"));

        colorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.color",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_C,"category.brickcraft"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (studioKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null)
                    client.setScreen(new BrickStudioScreen(resolveTarget(client)));
            }
            while (nextKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.nextKind();
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : "+BrickSelection.kind.title),true);
            }
            while (colorKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.nextColor();
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : " + BrickSelection.colorName()),true);
            }
            while (turnKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.turn=(BrickSelection.turn+1)&3;
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : rotation "+(BrickSelection.turn*90)+"°"),true);
            }
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != Hand.MAIN_HAND || !player.getStackInHand(hand).isOf(BrickCraft.TOOL))
                return ActionResult.PASS;
            if (world.isClient) {
                ClientPlayNetworking.send(new BrickActionPayload(
                    hit.getBlockPos(),hit.getSide(),
                    (float)(hit.getPos().x-hit.getBlockPos().getX()),
                    (float)(hit.getPos().y-hit.getBlockPos().getY()),
                    (float)(hit.getPos().z-hit.getBlockPos().getZ()),
                    player.isSneaking(),false,BrickSelection.piece(0,0)));
            }
            return ActionResult.SUCCESS;
        });
    }

    public static BlockPos resolveTarget(MinecraftClient client) {
        if (client.world == null || !(client.crosshairTarget instanceof BlockHitResult hit)) return null;
        // Studio origin is placed NEXT TO a targeted normal block, vanilla-style.
        // A new model can also start from the top of an existing LEGO cell.
        if (client.world.getBlockState(hit.getBlockPos()).isOf(BrickCraft.CELL))
            return hit.getSide().getAxis().isVertical()
                    ? hit.getBlockPos().up() : hit.getBlockPos().offset(hit.getSide());
        return hit.getBlockPos().offset(hit.getSide());
    }
}
