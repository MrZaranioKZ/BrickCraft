package fr.brickcraft.core;

import net.minecraft.util.math.BlockPos;
import java.util.ArrayList;
import java.util.List;

/**
 * World coordinates for one piece. Each LEGO stud occupies 1 horizontal Minecraft block.
 * Y is expressed in fifths of a Minecraft block: plate = 2 units, brick = 6 units.
 * Thus a 2x4 brick is 2x4x1.2 Minecraft blocks, not a 2x4x1 cube.
 */
public record BrickPiece(BrickKind kind, int rgb, int x, int y, int z, int turn) {
    public int width() { return kind.width(turn); }
    public int length() { return kind.length(turn); }
    public int height() { return kind.plates * 2; }
    public int top() { return y + height(); }

    public boolean valid() {
        return kind != null && turn >= 0 && turn < 4 &&
                x >= -29_999_980 && x <= 29_999_980 &&
                z >= -29_999_980 && z <= 29_999_980 &&
                y >= -2000 && y <= 10000 && (rgb & 0xFF000000) == 0;
    }

    /** Only plastic body intersects; studs enter the underside of the next brick. */
    public boolean intersects(BrickPiece other) {
        return x < other.x + other.width() && x + width() > other.x &&
                z < other.z + other.length() && z + length() > other.z &&
                y < other.top() && top() > other.y;
    }

    /** Render/collision also covers the small top stud above the body. */
    public List<BlockPos> occupiedCells() {
        List<BlockPos> result = new ArrayList<>();
        int yStart = Math.floorDiv(y, 5);
        int yEnd = Math.floorDiv(top() + (kind.studs ? 1 : 0) - 1, 5);
        for (int yy=yStart; yy<=yEnd; yy++) {
            for (int xx=x; xx<x+width(); xx++) {
                for (int zz=z; zz<z+length(); zz++) result.add(new BlockPos(xx, yy, zz));
            }
        }
        return result;
    }
}
