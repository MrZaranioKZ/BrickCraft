package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.s2c.play.BlockEntityUpdateS2CPacket;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;

/** A 'fragment' cell: stores references to all complete world-space pieces crossing it. */
public final class BrickCellEntity extends BlockEntity {
    public static final int MAX_PIECES = 48;
    private final ArrayList<BrickPiece> pieces = new ArrayList<>();
    // If the LDraw zip is temporarily missing, retain unknown pieces in NBT intact.
    private final NbtList unresolvedPieces = new NbtList();

    public BrickCellEntity(BlockPos pos, BlockState state) { super(BrickCraft.CELL_ENTITY, pos, state); }
    public List<BrickPiece> pieces() { return List.copyOf(pieces); }

    public boolean canAdd(BrickPiece candidate) {
        if (pieces.size() >= MAX_PIECES || !unresolvedPieces.isEmpty()) return false;
        for (BrickPiece old : pieces) if (old.intersects(candidate)) return false;
        return true;
    }

    public boolean add(BrickPiece piece) {
        if (!piece.occupiedCells().contains(pos) || !canAdd(piece)) return false;
        pieces.add(piece); sync(); return true;
    }

    /** A fast insertion only for the server's prevalidated, cell-by-cell large export. */
    public boolean addFromExport(BrickPiece piece) {
        if(!canAdd(piece))return false;
        pieces.add(piece);sync();return true;
    }

    public boolean remove(BrickPiece piece) {
        if (!pieces.remove(piece)) return false;
        sync(); return true;
    }

    /** For the top of the visible LEGO under the cursor; allows exact LEGO layer stacking. */
    public BrickPiece topmost() {
        BrickPiece chosen = null;
        for (BrickPiece p : pieces) {
            if (chosen == null || p.top() > chosen.top()) chosen = p;
        }
        return chosen;
    }

    /** Distinguishes multiple plates in one cell by the precise clicked height. */
    public BrickPiece pickAt(double worldY, boolean topFace) {
        BrickPiece chosen=null;
        double best=Double.POSITIVE_INFINITY;
        for(BrickPiece p:pieces){
            double low=p.y()/5.0,high=p.top()/5.0;
            // A click at the joint belongs to the upper brick (its bottom), not to both.
            double distance;
            if(topFace)distance=Math.abs(worldY-high);
            else if(worldY>=low-.005 && worldY<=high+.005)distance=0;
            else distance=Math.min(Math.abs(worldY-low),Math.abs(worldY-high));
            if(distance<best-1e-6 || (Math.abs(distance-best)<1e-6 &&
                    chosen!=null && (topFace?p.top()>chosen.top():p.y()>chosen.y()))) {
                best=distance;chosen=p;
            }
        }
        return chosen;
    }

    private void sync() {
        markDirty();
        if (world instanceof ServerWorld serverWorld) serverWorld.getChunkManager().markForUpdate(pos);
    }

    @Override protected void writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.writeNbt(nbt, registries);
        NbtList items = new NbtList();
        for (BrickPiece p : pieces) {
            NbtCompound v = new NbtCompound();
            v.putString("Kind", p.kind().name());
            v.putInt("RGB", p.rgb()); v.putInt("X", p.x()); v.putInt("Y", p.y());
            v.putInt("Z", p.z()); v.putInt("Turn", p.turn()); v.putInt("Angle",p.angle());
            v.putInt("Pitch",p.pitch()); v.putInt("Roll",p.roll());
            if(p.kind()==BrickKind.LDRAW_PART)v.putString("LDrawId",p.partId());
            items.add(v);
        }
        for(int i=0;i<unresolvedPieces.size();i++)items.add(unresolvedPieces.getCompound(i).copy());
        nbt.put("PiecesV2", items);
    }

    @Override public void readNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registries) {
        super.readNbt(nbt, registries);
        pieces.clear();unresolvedPieces.clear();
        NbtList items = nbt.getList("PiecesV2", NbtElement.COMPOUND_TYPE);
        // Previous V0.1 format intentionally not migrated: its geometry uses a different scale.
        for (int i=0; i<items.size() && pieces.size()<MAX_PIECES; i++) {
            NbtCompound v = items.getCompound(i);
            try {
                BrickPiece p = new BrickPiece(BrickKind.valueOf(v.getString("Kind")),
                    v.getInt("RGB") & 0xFFFFFF, v.getInt("X"), v.getInt("Y"),
                    v.getInt("Z"), v.getInt("Turn"),
                    v.contains("Angle", NbtElement.NUMBER_TYPE) ? v.getInt("Angle") : v.getInt("Turn")*90,
                    v.getInt("Pitch"),v.getInt("Roll"),v.getString("LDrawId"));
                if(p.kind()==BrickKind.LDRAW_PART && !p.valid()) {
                    unresolvedPieces.add(v.copy()); // Preserve worlds when users forget complete.zip.
                } else if (p.valid() && p.occupiedCells().contains(pos) && canAdd(p))pieces.add(p);
                else if(!unresolvedPieces.isEmpty())unresolvedPieces.add(v.copy());
            } catch (IllegalArgumentException ignored) {
                if("LDRAW_PART".equals(v.getString("Kind")))unresolvedPieces.add(v.copy());
            }
        }
    }

    @Override public @Nullable Packet<ClientPlayPacketListener> toUpdatePacket() {
        return BlockEntityUpdateS2CPacket.create(this);
    }
    @Override public NbtCompound toInitialChunkDataNbt(RegistryWrapper.WrapperLookup registries) {
        return createNbt(registries);
    }
}
