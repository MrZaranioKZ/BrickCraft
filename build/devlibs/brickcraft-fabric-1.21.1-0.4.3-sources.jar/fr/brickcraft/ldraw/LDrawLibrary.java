package fr.brickcraft.ldraw;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Lazy, self-contained LDraw parts reader. Source: user's official complete.zip.
 * Root part .dat files are indexed at startup, meshes are expanded only on demand.
 * LDraw primitives (type 1 references, 3 triangles and 4 quadrilaterals) are supported.
 * TEXMAP decals/UV, conditional lines, BFC winding, photometric material effects are NOT.
 * No server-side download, and no third-party assets shipped with BrickCraft.
 */
public final class LDrawLibrary {
    private LDrawLibrary() {}
    public record PartInfo(String id, String name) {}
    public record Colour(int code, String name, int rgb, int alpha) {}
    /** XYZ vertex coordinates in Minecraft units, normalized to the minimum bounds; each 9 floats = triangle. */
    public record Mesh(float[] xyz, int[] colors, float width, float height, float depth, int triangles) {
        public boolean isEmpty(){return triangles==0;}
    }
    private static volatile ZipFile archive;
    private static Map<String, String> lookup=Map.of();
    private static List<PartInfo> parts=List.of();
    private static Map<String, PartInfo> byId=Map.of();
    private static Map<Integer, Colour> colours=Map.of();
    private static String message="Bibliotheque absente : place complete.zip dans config/brickcraft/";
    private static final LinkedHashMap<String, Mesh> cached=new LinkedHashMap<>(96,.75f,true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String,Mesh> e){return size()>48;}
    };
    public static synchronized void init(Path configDir) {
        close();
        Path file=configDir.resolve("brickcraft").resolve("complete.zip");
        if(!Files.isRegularFile(file)) {message="LDraw non installe : "+file.toAbsolutePath();return;}
        try {
            ZipFile zip=new ZipFile(file.toFile());
            Map<String,String> index=new HashMap<>();
            Enumeration<? extends ZipEntry> entries=zip.entries();
            while(entries.hasMoreElements()) {
                ZipEntry ent=entries.nextElement();
                if(ent.isDirectory())continue;
                String name=ent.getName().replace('\\','/').toLowerCase(Locale.ROOT);
                if(name.startsWith("ldraw/"))name=name.substring(6);
                if(!name.endsWith(".dat")&&!name.endsWith(".ldr")) continue;
                if(name.contains("../") || name.startsWith("/"))continue;
                index.putIfAbsent(name,ent.getName());
            }
            Map<String,PartInfo> all=new LinkedHashMap<>();
            for(var e:index.entrySet()){
                String key=e.getKey();
                if(!key.startsWith("parts/") || key.substring(6).contains("/"))continue;
                String id=key.substring(6,key.length()-4);
                String title="";
                try(BufferedReader reader=new BufferedReader(new InputStreamReader(zip.getInputStream(zip.getEntry(e.getValue())),StandardCharsets.UTF_8))){
                    for(int i=0;i<5;i++){
                        String line=reader.readLine();if(line==null)break;
                        String s=line.trim();
                        if(s.startsWith("0 ") && !s.startsWith("0 !") && !s.startsWith("0 BFC") && !s.startsWith("0 Name:") && !s.startsWith("0 Author:")){
                            title=s.substring(2).trim();break;
                        }
                    }
                }catch(Exception ignored){}
                all.put(id,new PartInfo(id,title.isEmpty()?id:title));
            }
            List<PartInfo> sorted=new ArrayList<>(all.values());
            sorted.sort(Comparator.comparing(PartInfo::id,String.CASE_INSENSITIVE_ORDER));
            Map<Integer,Colour> loadedColors=new LinkedHashMap<>();
            String config=index.get("ldconfig.ldr");
            if(config!=null) {
                try(BufferedReader reader=new BufferedReader(new InputStreamReader(zip.getInputStream(zip.getEntry(config)),StandardCharsets.UTF_8))){
                    for(String line;(line=reader.readLine())!=null;){
                        String[] tokens=line.trim().split("\\s+");
                        if(tokens.length<8 || !"!COLOUR".equals(tokens[1])) continue;
                        try {
                            int iCode=-1,iValue=-1,iAlpha=-1;
                            for(int i=2;i<tokens.length;i++){
                                if(tokens[i].equals("CODE"))iCode=i;
                                if(tokens[i].equals("VALUE"))iValue=i;
                                if(tokens[i].equals("ALPHA"))iAlpha=i;
                            }
                            if(iCode<0||iValue<0)continue;
                            int code=Integer.parseInt(tokens[iCode+1]);
                            int rgb=Integer.parseInt(tokens[iValue+1].replace("#",""),16);
                            int alpha=iAlpha>0?Integer.parseInt(tokens[iAlpha+1]):255;
                            String title=String.join(" ",Arrays.asList(tokens).subList(2,iCode)).replace('_',' ');
                            loadedColors.put(code,new Colour(code,title,rgb,alpha));
                        }catch(RuntimeException ignored){}
                    }
                }
            }
            archive=zip;
            lookup=Map.copyOf(index);parts=List.copyOf(sorted);byId=Map.copyOf(all);colours=Map.copyOf(loadedColors);
            message="LDraw : "+parts.size()+" fichiers de pieces indexés ("+file.getFileName()+")";
        } catch(Exception ex){close();message="Erreur LDraw : "+ex.getMessage();}
    }
    public static synchronized void close(){
        try {if(archive!=null)archive.close();}catch(IOException ignored){}
        archive=null;lookup=Map.of();parts=List.of();byId=Map.of();colours=Map.of();cached.clear();
    }
    public static String status(){return message;}
    public static int size(){return parts.size();}
    public static boolean available(){return archive!=null;}
    public static boolean contains(String id){return id!=null && byId.containsKey(id.toLowerCase(Locale.ROOT));}
    public static PartInfo info(String id){return byId.get(id.toLowerCase(Locale.ROOT));}
    public static List<Colour> colors(){return colours.values().stream().sorted(Comparator.comparingInt(Colour::code)).toList();}
    public static int resolveColor(int ldrawCode,int main){
        if(ldrawCode==16||ldrawCode==24)return main;
        Colour c=colours.get(ldrawCode);
        return c!=null?c.rgb():main;
    }
    public static String normalize(String id){return id==null?"":id.trim().toLowerCase(Locale.ROOT).replace(".dat","");}
    public static List<PartInfo> search(String query,int max){
        String q=normalize(query).replaceAll("[ _-]+","").replace('×','x');
        // Explicit verified LEGO element -> LDraw design alias (not a general element-ID database).
        if(q.equals("6258572"))q="3004";
        List<PartInfo> result=new ArrayList<>();
        for(PartInfo p:parts){
            String name=p.name().toLowerCase(Locale.ROOT).replaceAll("[ _-]+","").replace('×','x');
            if(q.isEmpty()||p.id().contains(q)||name.contains(q)){
                result.add(p);if(result.size()>=max)break;
            }
        }
        return result;
    }
    public static synchronized Mesh mesh(String id){
        String key=normalize(id);
        if(!contains(key))return null;
        Mesh cachedMesh=cached.get(key);if(cachedMesh!=null)return cachedMesh;
        if(archive==null)return null;
        try {
            ArrayList<Tri> result=new ArrayList<>();
            expand("parts/"+key+".dat",16,new double[]{0,0,0},
                    new double[]{1,0,0,0,1,0,0,0,1},result,new HashSet<>(),0);
            if(result.isEmpty())return null;
            double[] lo={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY};
            double[] hi={Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
            for(Tri t:result)for(int j=0;j<9;j+=3)for(int d=0;d<3;d++){
                double c=t.xyz[j+d];lo[d]=Math.min(lo[d],c);hi[d]=Math.max(hi[d],c);
            }
            if(hi[0]-lo[0]>.001 && hi[1]-lo[1]>.001 && hi[2]-lo[2]>.001 &&
               hi[0]-lo[0]<=1600 && hi[1]-lo[1]<=1600 && hi[2]-lo[2]<=1600) {
                float[] xyz=new float[result.size()*9];int[] codes=new int[result.size()];
                for(int i=0;i<result.size();i++){
                    Tri tri=result.get(i);codes[i]=tri.code;
                    for(int j=0;j<9;j+=3){
                        xyz[i*9+j]=(float)((tri.xyz[j]-lo[0])/20.);
                        xyz[i*9+j+1]=(float)((hi[1]-tri.xyz[j+1])/20.); // LDraw Y down; MC Y up
                        xyz[i*9+j+2]=(float)((tri.xyz[j+2]-lo[2])/20.);
                    }
                }
                Mesh mesh=new Mesh(xyz,codes,(float)((hi[0]-lo[0])/20.),
                        (float)((hi[1]-lo[1])/20.),(float)((hi[2]-lo[2])/20.),result.size());
                cached.put(key,mesh);return mesh;
            }
        }catch(Exception ignored){}
        return null;
    }
    private record Tri(double[] xyz,int code){}
    private static void expand(String file,int current,double[] offset,double[] rot,
                               List<Tri> dst,Set<String> stack,int depth) throws IOException {
        if(depth>=24||dst.size()>60000)return;
        String name=normalizeFile(file);
        if(!stack.add(name))return;
        String mapped=lookup.get(name);
        if(mapped==null){stack.remove(name);return;}
        ZipEntry zipEntry=archive.getEntry(mapped);
        if(zipEntry==null){stack.remove(name);return;}
        try(BufferedReader reader=new BufferedReader(new InputStreamReader(archive.getInputStream(zipEntry),StandardCharsets.UTF_8))){
            for(String line;(line=reader.readLine())!=null;) {
                String[] t=line.trim().split("\\s+");
                if(t.length==0)continue;
                try {
                    int type=Integer.parseInt(t[0]);
                    if(type==1&&t.length>=15) {
                        int col=parseColor(t[1],current);
                        double[] pos={Double.parseDouble(t[2]),Double.parseDouble(t[3]),Double.parseDouble(t[4])};
                        double[] local=new double[9];for(int i=0;i<9;i++)local[i]=Double.parseDouble(t[5+i]);
                        StringBuilder child=new StringBuilder(t[14]);for(int j=15;j<t.length;j++)child.append(' ').append(t[j]);
                        double[] composed=mul(rot,local);
                        double[] translated=transform(pos,offset,rot);
                        String resolved=resolveRef(child.toString());
                        if(resolved!=null)expand(resolved,col,translated,composed,dst,stack,depth+1);
                    }else if(type==3&&t.length>=11) {
                        double[] xyz=new double[9];for(int i=0;i<9;i++)xyz[i]=Double.parseDouble(t[2+i]);
                        for(int i=0;i<9;i+=3){double[] p=transform(Arrays.copyOfRange(xyz,i,i+3),offset,rot);
                            System.arraycopy(p,0,xyz,i,3);}
                        dst.add(new Tri(xyz,parseColor(t[1],current)));
                    }else if(type==4&&t.length>=14) {
                        double[] quad=new double[12];for(int i=0;i<12;i++)quad[i]=Double.parseDouble(t[2+i]);
                        double[] a=new double[12];for(int i=0;i<12;i+=3){double[] p=transform(Arrays.copyOfRange(quad,i,i+3),offset,rot);System.arraycopy(p,0,a,i,3);}
                        dst.add(new Tri(new double[]{a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8]},parseColor(t[1],current)));
                        dst.add(new Tri(new double[]{a[0],a[1],a[2],a[6],a[7],a[8],a[9],a[10],a[11]},parseColor(t[1],current)));
                    }
                }catch(NumberFormatException|ArrayIndexOutOfBoundsException ignored){}
                if(dst.size()>60000)throw new IOException("Too many triangles");
            }
        }finally{stack.remove(name);}
    }
    private static String resolveRef(String filename){
        String normalized=normalizeFile(filename);
        if(lookup.containsKey(normalized))return normalized;
        for(String candidate:List.of("parts/"+normalized,"p/"+normalized,"parts/s/"+normalized))
            if(lookup.containsKey(candidate))return candidate;
        return null;
    }
    private static String normalizeFile(String s){return s.replace('\\','/').toLowerCase(Locale.ROOT).replaceFirst("^ldraw/","");}
    private static int parseColor(String token,int current){
        if(token.equals("16")||token.equals("24"))return current;
        if(token.startsWith("0x2")&&token.length()==9)return Integer.parseInt(token.substring(3),16)|0x1000000;
        return Integer.parseInt(token);
    }
    private static double[] transform(double[] p,double[] translation,double[] m){
        return new double[]{translation[0]+m[0]*p[0]+m[1]*p[1]+m[2]*p[2],
                translation[1]+m[3]*p[0]+m[4]*p[1]+m[5]*p[2],
                translation[2]+m[6]*p[0]+m[7]*p[1]+m[8]*p[2]};
    }
    private static double[] mul(double[] a,double[] b){
        double[] c=new double[9];
        for(int r=0;r<3;r++)for(int col=0;col<3;col++)for(int k=0;k<3;k++)c[r*3+col]+=a[r*3+k]*b[k*3+col];
        return c;
    }
}
