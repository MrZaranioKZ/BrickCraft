package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.world.BrickPartItem;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import fr.brickcraft.net.BrickEditPayload;
import fr.brickcraft.world.BrickCellEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class BrickCraftClient implements ClientModInitializer {
    private static KeyBinding studioKey,nextKey,turnKey,colorKey,quickKey,stepKey,pitchKey,rollKey,resetKey;
    private static boolean prevCopy=false,prevPaste=false,prevUndo=false,prevRedo=false;
    private static Item previousHand=null;
    private static int previousSlot=-1;
    private static BrickPiece clipboard=null;

    private static BrickKind activeKind(MinecraftClient client){
        if(BrickSelection.sampled)return BrickSelection.kind;
        if(client.player!=null && client.player.getMainHandStack().getItem() instanceof BrickPartItem item)
            return item.kind();
        return BrickSelection.kind;
    }

    /** Called before vanilla Pick Block, so Minecraft won't replace our sampled color and part. */
    public static boolean pickBrick(MinecraftClient client){
        if(client.player==null || client.world==null ||
                !(client.crosshairTarget instanceof BlockHitResult hit) ||
                !(client.world.getBlockEntity(hit.getBlockPos()) instanceof BrickCellEntity cell))return false;
        BrickPiece piece=cell.pickAt(hit.getPos().y,hit.getSide()==net.minecraft.util.math.Direction.UP);
        if(piece==null)return false;
        BrickSelection.sample(piece); clipboard=piece;
        if(client.interactionManager!=null && client.interactionManager.hasCreativeInventory()){
            // Give the matching item in the active hotbar slot. Keep the sampled RGB in selection.
            ItemStack stack=new ItemStack(piece.kind()==BrickKind.LDRAW_PART?
                    BrickCraft.LDRAW_ITEM:BrickCraft.PART_ITEMS.get(piece.kind()));
            int slot=client.player.getInventory().selectedSlot;
            client.player.getInventory().setStack(slot,stack);
            client.interactionManager.clickCreativeStack(stack,36+slot);
            previousHand=stack.getItem();previousSlot=slot;
        }
        client.player.sendMessage(Text.literal("BrickCraft : pipette "+piece.name()+
                " / "+BrickSelection.colorName()+" / Y="+piece.angle()+"°"),true);
        return true;
    }

    private static void pasteAtCrosshair(MinecraftClient client){
        if(client.player==null || client.world==null || clipboard==null ||
                !(client.crosshairTarget instanceof BlockHitResult hit))return;
        Item held=client.player.getMainHandStack().getItem();
        if(held!=BrickCraft.TOOL && !(held instanceof BrickPartItem) && held!=BrickCraft.LDRAW_ITEM)return;
        BrickSelection.sample(clipboard);
        ClientPlayNetworking.send(new BrickActionPayload(hit.getBlockPos(),hit.getSide(),
                (float)(hit.getPos().x-hit.getBlockPos().getX()),
                (float)(hit.getPos().y-hit.getBlockPos().getY()),
                (float)(hit.getPos().z-hit.getBlockPos().getZ()),false,false,
                BrickSelection.oriented(clipboard.kind(),0,0,0)));
    }

    private static boolean keyDown(MinecraftClient client,int key){
        return InputUtil.isKeyPressed(client.getWindow().getHandle(),key);
    }


    @Override public void onInitializeClient() {
        BlockEntityRendererRegistry.register(BrickCraft.CELL_ENTITY, BrickCellRenderer::new);
        studioKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.studio",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_B,"category.brickcraft"));
        nextKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.next",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_V,"category.brickcraft"));
        turnKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.turn",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_R,"category.brickcraft"));

        quickKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.quick",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_N,"category.brickcraft"));
        stepKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.step",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_G,"category.brickcraft"));
        pitchKey=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.pitch",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_X,"category.brickcraft"));
        rollKey=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.roll",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_Z,"category.brickcraft"));
        resetKey=KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.reset",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_H,"category.brickcraft"));
        colorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.brickcraft.color",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_C,"category.brickcraft"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if(client.player!=null){
                Item held=client.player.getMainHandStack().getItem();
                int slot=client.player.getInventory().selectedSlot;
                if(previousHand!=null && (previousHand!=held || (previousSlot>=0&&previousSlot!=slot)))
                    BrickSelection.sampled=false;
                previousHand=held;previousSlot=slot;
            }
            boolean ctrl=keyDown(client,GLFW.GLFW_KEY_LEFT_CONTROL)||keyDown(client,GLFW.GLFW_KEY_RIGHT_CONTROL);
            boolean copy=ctrl&&keyDown(client,GLFW.GLFW_KEY_C);
            boolean paste=ctrl&&keyDown(client,GLFW.GLFW_KEY_V);
            boolean shift=keyDown(client,GLFW.GLFW_KEY_LEFT_SHIFT)||keyDown(client,GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean undo=ctrl&&keyDown(client,GLFW.GLFW_KEY_Z)&&!shift;
            boolean redo=ctrl&&(keyDown(client,GLFW.GLFW_KEY_Y)||
                   (keyDown(client,GLFW.GLFW_KEY_Z)&&shift));
            if(client.currentScreen==null && client.player!=null){
                if(copy&&!prevCopy)pickBrick(client);
                if(paste&&!prevPaste)pasteAtCrosshair(client);
                if(undo&&!prevUndo)ClientPlayNetworking.send(new BrickEditPayload(false));
                if(redo&&!prevRedo)ClientPlayNetworking.send(new BrickEditPayload(true));
            }
            prevCopy=copy;prevPaste=paste;prevUndo=undo;prevRedo=redo;
            while (studioKey.wasPressed()) {
                if (client.player != null && client.currentScreen == null)
                    client.setScreen(new BrickStudioScreen(resolveTarget(client)));
            }
            while (quickKey.wasPressed()) if (client.currentScreen==null && client.player!=null)
                client.setScreen(new BrickQuickScreen());
            while (stepKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.cycleStep();
                if(client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : pas de rotation " + BrickSelection.step() + "°"),true);
            }
            while (pitchKey.wasPressed()) if(client.currentScreen==null){
                BrickSelection.rotatePitch(1);
                if(client.player!=null)client.player.sendMessage(Text.literal("BrickCraft : axe X "+BrickSelection.pitch+"°"),true);
            }
            while (rollKey.wasPressed()) if(client.currentScreen==null && !ctrl){
                BrickSelection.rotateRoll(1);
                if(client.player!=null)client.player.sendMessage(Text.literal("BrickCraft : axe Z "+BrickSelection.roll+"°"),true);
            }
            while (resetKey.wasPressed()) if(client.currentScreen==null){
                BrickSelection.resetRotation();
                if(client.player!=null)client.player.sendMessage(Text.literal("BrickCraft : rotation reinitialisee"),true);
            }
            while (nextKey.wasPressed()) if (client.currentScreen==null && !ctrl) {
                BrickSelection.nextKind();
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : "+BrickSelection.selectedName()),true);
            }
            while (colorKey.wasPressed()) if (client.currentScreen==null && !ctrl) {
                BrickSelection.nextColor();
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : " + BrickSelection.colorName()),true);
            }
            while (turnKey.wasPressed()) if (client.currentScreen==null) {
                BrickSelection.rotate(client.player!=null && client.player.isSneaking() ? -1 : 1);
                if (client.player!=null) client.player.sendMessage(Text.literal(
                    "BrickCraft : rotation "+BrickSelection.angle+"° (pas "+BrickSelection.step()+"°)"),true);
            }
        });
        HudRenderCallback.EVENT.register((draw,tick) -> {
            MinecraftClient client=MinecraftClient.getInstance();
            if(client.player==null || client.currentScreen!=null || client.options.hudHidden) return;
            boolean active=client.player.getMainHandStack().isOf(BrickCraft.TOOL)
                    || client.player.getMainHandStack().getItem() instanceof BrickPartItem
                    || client.player.getMainHandStack().isOf(BrickCraft.LDRAW_ITEM);
            if(!active)return;
            BrickKind kind=activeKind(client);
            int x=6,y=draw.getScaledWindowHeight()-76;
            int w=Math.max(170,client.textRenderer.getWidth(BrickSelection.selectedName())+22);
            draw.fill(x-3,y-3,x+w+3,y+48,0xB5102230);
            draw.fill(x,y+3,x+8,y+15,0xFF000000|BrickSelection.rgb);
            draw.drawTextWithShadow(client.textRenderer,BrickSelection.selectedName(),x+13,y+4,0xFFEAF6FF);
            draw.drawTextWithShadow(client.textRenderer,
                    BrickSelection.colorName()+" | Y="+BrickSelection.angle+" X="+BrickSelection.pitch+" Z="+BrickSelection.roll,
                    x+3,y+20,0xFFF2DDA1);
            draw.drawTextWithShadow(client.textRenderer,"N: chercher | G: pas | H: reset | clic molette: copier",x+3,y+34,0xFF99C0D1);
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand!=Hand.MAIN_HAND || !(player.getStackInHand(hand).isOf(BrickCraft.TOOL) ||
                    player.getStackInHand(hand).getItem() instanceof BrickPartItem ||
                    player.getStackInHand(hand).isOf(BrickCraft.LDRAW_ITEM)))
                return ActionResult.PASS;
            if (world.isClient) {
                BrickKind kind=activeKind(MinecraftClient.getInstance());
                BrickPiece selection=BrickSelection.oriented(kind,0,0,0);
                ClientPlayNetworking.send(new BrickActionPayload(
                    hit.getBlockPos(),hit.getSide(),
                    (float)(hit.getPos().x-hit.getBlockPos().getX()),
                    (float)(hit.getPos().y-hit.getBlockPos().getY()),
                    (float)(hit.getPos().z-hit.getBlockPos().getZ()),
                    player.isSneaking(),false,selection));
            }
            return ActionResult.SUCCESS;
        });
    }

    public static BlockPos resolveTarget(MinecraftClient client) {
        if (client.world == null || !(client.crosshairTarget instanceof BlockHitResult hit)) return null;
        // Studio origin is placed NEXT TO a targeted normal block, vanilla-style.
        // A new model can also start from the top of an existing LEGO cell.
        if (client.world.getBlockState(hit.getBlockPos()).isOf(BrickCraft.CELL))
            return hit.getSide().getAxis().isVertical()
                    ? hit.getBlockPos().up() : hit.getBlockPos().offset(hit.getSide());
        return hit.getBlockPos().offset(hit.getSide());
    }
}
