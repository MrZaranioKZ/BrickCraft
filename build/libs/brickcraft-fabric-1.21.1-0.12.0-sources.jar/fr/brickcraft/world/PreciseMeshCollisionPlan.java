package fr.brickcraft.world;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import java.util.*;
import java.util.function.Function;

/**
 * Server-side, deterministic collision voxelizer of original (not LOD) LDraw triangles.
 * A surface rasterization and an exterior flood-fill retain open holes and internal cavities.
 * Sub-block voxels are 1/8 of a Minecraft block; input matrices remain lossless.
 * This class has no Minecraft runtime dependency and can be tested with plain javac.
 */
public final class PreciseMeshCollisionPlan {
    private PreciseMeshCollisionPlan(){}
    public static final int RESOLUTION=8, MAX_CELLS=16000, MAX_TRIANGLES=2_000_000;
    private static final int MAX_PART_VOXELS=2_500_000;
    public record Geometry(float[] xyz,double[] bounds){
        public Geometry {
            if(xyz==null||xyz.length%9!=0||bounds==null||bounds.length!=6)
                throw new IllegalArgumentException("Maillage LDraw incomplet");
        }
    }
    public record Cell(int x,int y,int z){}
    public record Result(Map<Cell,long[]> masks,int pieces,int triangles){
        public Result {masks=Collections.unmodifiableMap(new LinkedHashMap<>(masks));}
    }
    /** Bits: index = (localY * 64 + localZ * 8 + localX), with local coordinates 0..7. */
    public static boolean occupied(long[] bits,int x,int y,int z){
        int bit=y*64+z*8+x;
        return bits!=null&&bits.length==8&&(bits[bit>>>6]&(1L<<(bit&63)))!=0;
    }
    public static int occupiedCount(long[] bits){int n=0;for(long b:bits)n+=Long.bitCount(b);return n;}

    public static Result build(List<LDrawProjectReader.Instance> parts,double originX,double originY,double originZ,
                               int anchorX,int anchorY,int anchorZ,Function<String,Geometry> geometry){
        Map<Cell,long[]> all=new LinkedHashMap<>();int tris=0;
        for(var part:parts){
            Geometry g=geometry.apply(part.partId());
            if(g==null||g.xyz.length==0)throw new IllegalArgumentException("Maillage LDraw absent : "+part.partId());
            tris+=g.xyz.length/9;
            if(tris>MAX_TRIANGLES)throw new IllegalArgumentException("Physique precise : trop de triangles (limite "+MAX_TRIANGLES+")");
            addPart(part,g,originX,originY,originZ,anchorX,anchorY,anchorZ,all);
            if(all.size()>MAX_CELLS)throw new IllegalArgumentException("Trop de blocs physiques (limite "+MAX_CELLS+")");
        }
        all.entrySet().removeIf(e->occupiedCount(e.getValue())==0);
        return new Result(all,parts.size(),tris);
    }
    private static void addPart(LDrawProjectReader.Instance part,Geometry g,
                                double ox,double oy,double oz,int ax,int ay,int az,Map<Cell,long[]> destination){
        float[] mesh=g.xyz();double[] b=g.bounds(),m=part.matrix();
        int count=mesh.length/9;
        // World-space coordinates: the same transform as PreciseGpuRenderer (LDraw Y is down).
        double[] t=new double[mesh.length];
        double[] lo={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY};
        double[] hi={Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
        for(int k=0;k<mesh.length;k+=3){
            double x=b[0]+mesh[k]*20,y=b[4]-mesh[k+1]*20,z=b[2]+mesh[k+2]*20;
            double wx=ax+(part.x()+m[0]*x+m[1]*y+m[2]*z)/20-ox;
            double wy=ay-(part.y()+m[3]*x+m[4]*y+m[5]*z)/20-oy;
            double wz=az+(part.z()+m[6]*x+m[7]*y+m[8]*z)/20-oz;
            t[k]=wx;t[k+1]=wy;t[k+2]=wz;
            lo[0]=Math.min(lo[0],wx);lo[1]=Math.min(lo[1],wy);lo[2]=Math.min(lo[2],wz);
            hi[0]=Math.max(hi[0],wx);hi[1]=Math.max(hi[1],wy);hi[2]=Math.max(hi[2],wz);
        }
        // One empty sub-voxel layer lets the flood fill distinguish outside from inside.
        int sx=(int)Math.floor(lo[0]*8)-1,sy=(int)Math.floor(lo[1]*8)-1,sz=(int)Math.floor(lo[2]*8)-1;
        int ex=(int)Math.ceil(hi[0]*8)+1,ey=(int)Math.ceil(hi[1]*8)+1,ez=(int)Math.ceil(hi[2]*8)+1;
        int nx=ex-sx,ny=ey-sy,nz=ez-sz;
        long total=(long)nx*ny*nz;
        if(nx<=0||ny<=0||nz<=0||total>MAX_PART_VOXELS)
            throw new IllegalArgumentException("Piece trop grande pour la physique fine : "+part.partId());
        // Rasterize all triangle surfaces, including sloped faces, rings, curved studs and hollow tubes.
        BitSet solid=new BitSet((int)total);
        for(int i=0;i<count;i++){
            int k=i*9;
            double[] a={t[k],t[k+1],t[k+2]},c={t[k+3],t[k+4],t[k+5]},d={t[k+6],t[k+7],t[k+8]};
            int x0=Math.max(0,(int)Math.floor(Math.min(a[0],Math.min(c[0],d[0]))*8)-sx-1);
            int y0=Math.max(0,(int)Math.floor(Math.min(a[1],Math.min(c[1],d[1]))*8)-sy-1);
            int z0=Math.max(0,(int)Math.floor(Math.min(a[2],Math.min(c[2],d[2]))*8)-sz-1);
            int x1=Math.min(nx-1,(int)Math.ceil(Math.max(a[0],Math.max(c[0],d[0]))*8)-sx);
            int y1=Math.min(ny-1,(int)Math.ceil(Math.max(a[1],Math.max(c[1],d[1]))*8)-sy);
            int z1=Math.min(nz-1,(int)Math.ceil(Math.max(a[2],Math.max(c[2],d[2]))*8)-sz);
            for(int y=y0;y<=y1;y++)for(int z=z0;z<=z1;z++)for(int x=x0;x<=x1;x++){
                if(intersects(a,c,d,(sx+x+.5)/8.0,(sy+y+.5)/8.0,(sz+z+.5)/8.0))
                    solid.set(index(x,y,z,nx,nz));
            }
        }
        // Fill enclosed interiors without closing real openings that connect to outside air.
        BitSet outside=new BitSet((int)total);
        int[] queue=new int[(int)total];int head=0,tail=0;
        // Entire outer shell (instead of just one corner) handles disjoint / open surfaces.
        for(int y=0;y<ny;y++)for(int z=0;z<nz;z++){
            tail=enqueue(0,y,z,nx,ny,nz,solid,outside,queue,tail);
            tail=enqueue(nx-1,y,z,nx,ny,nz,solid,outside,queue,tail);
        }
        for(int x=0;x<nx;x++)for(int z=0;z<nz;z++){
            tail=enqueue(x,0,z,nx,ny,nz,solid,outside,queue,tail);
            tail=enqueue(x,ny-1,z,nx,ny,nz,solid,outside,queue,tail);
        }
        for(int x=0;x<nx;x++)for(int y=0;y<ny;y++){
            tail=enqueue(x,y,0,nx,ny,nz,solid,outside,queue,tail);
            tail=enqueue(x,y,nz-1,nx,ny,nz,solid,outside,queue,tail);
        }
        while(head<tail){
            int pos=queue[head++],x=pos%nx,z=pos/nx%nz,y=pos/(nx*nz);
            if(x>0)tail=enqueue(x-1,y,z,nx,ny,nz,solid,outside,queue,tail);
            if(x+1<nx)tail=enqueue(x+1,y,z,nx,ny,nz,solid,outside,queue,tail);
            if(z>0)tail=enqueue(x,y,z-1,nx,ny,nz,solid,outside,queue,tail);
            if(z+1<nz)tail=enqueue(x,y,z+1,nx,ny,nz,solid,outside,queue,tail);
            if(y>0)tail=enqueue(x,y-1,z,nx,ny,nz,solid,outside,queue,tail);
            if(y+1<ny)tail=enqueue(x,y+1,z,nx,ny,nz,solid,outside,queue,tail);
        }
        // Do not collide with the reference anchor; do not store the exterior padding.
        int minX=(int)Math.floor(lo[0]*8),minY=(int)Math.floor(lo[1]*8),minZ=(int)Math.floor(lo[2]*8);
        int maxX=(int)Math.ceil(hi[0]*8),maxY=(int)Math.ceil(hi[1]*8),maxZ=(int)Math.ceil(hi[2]*8);
        for(int gy=minY;gy<maxY;gy++)for(int gz=minZ;gz<maxZ;gz++)for(int gx=minX;gx<maxX;gx++){
            int idx=index(gx-sx,gy-sy,gz-sz,nx,nz);
            if(!solid.get(idx)&&outside.get(idx))continue;
            int bx=Math.floorDiv(gx,8),by=Math.floorDiv(gy,8),bz=Math.floorDiv(gz,8);
            if(bx==ax&&by==ay&&bz==az)continue;
            Cell cell=new Cell(bx,by,bz);
            long[] bits=destination.computeIfAbsent(cell,k->new long[8]);
            int bit=Math.floorMod(gy,8)*64+Math.floorMod(gz,8)*8+Math.floorMod(gx,8);
            bits[bit>>>6]|=1L<<(bit&63);
        }
    }
    private static int index(int x,int y,int z,int nx,int nz){return (y*nz+z)*nx+x;}
    private static int enqueue(int x,int y,int z,int nx,int ny,int nz,BitSet solid,BitSet visited,int[] queue,int tail){
        int i=index(x,y,z,nx,nz);
        if(!solid.get(i)&&!visited.get(i)){visited.set(i);queue[tail++]=i;}
        return tail;
    }
    private static boolean intersects(double[] a,double[] b,double[] c,double px,double py,double pz){
        final double h=1.0/16.0+1e-7;
        double[][] v={{a[0]-px,a[1]-py,a[2]-pz},{b[0]-px,b[1]-py,b[2]-pz},
                      {c[0]-px,c[1]-py,c[2]-pz}};
        for(int axis=0;axis<3;axis++){
            double min=Math.min(v[0][axis],Math.min(v[1][axis],v[2][axis]));
            double max=Math.max(v[0][axis],Math.max(v[1][axis],v[2][axis]));
            if(min>h||max< -h)return false;
        }
        for(int i=0;i<3;i++){
            double[] p=v[i],q=v[(i+1)%3];
            double ex=q[0]-p[0],ey=q[1]-p[1],ez=q[2]-p[2];
            // Separating axes edge x X, edge x Y and edge x Z.
            if(separate(v,0,ez,-ey,h)||separate(v,-ez,0,ex,h)||separate(v,ey,-ex,0,h))return false;
        }
        double ux=v[1][0]-v[0][0],uy=v[1][1]-v[0][1],uz=v[1][2]-v[0][2];
        double vx=v[2][0]-v[0][0],vy=v[2][1]-v[0][1],vz=v[2][2]-v[0][2];
        return !separate(v,uy*vz-uz*vy,uz*vx-ux*vz,ux*vy-uy*vx,h);
    }
    private static boolean separate(double[][] v,double x,double y,double z,double h){
        double r=h*(Math.abs(x)+Math.abs(y)+Math.abs(z));
        double a=v[0][0]*x+v[0][1]*y+v[0][2]*z;
        double b=v[1][0]*x+v[1][1]*y+v[1][2]*z;
        double c=v[2][0]*x+v[2][1]*y+v[2][2]*z;
        return Math.min(a,Math.min(b,c))>r||Math.max(a,Math.max(b,c))< -r;
    }
}
