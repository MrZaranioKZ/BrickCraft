package fr.brickcraft.world;

import fr.brickcraft.net.PlayerScalePayload;
import java.util.Locale;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

/** Uses vanilla GENERIC_SCALE: model, camera eye height AND server/client collision box stay in sync. */
public final class PlayerScaleManager {
    private PlayerScaleManager(){}
    public static final double MIN=0.125,MAX=4.0;
    private static final class_2960 MODIFIER_ID=class_2960.method_60655("brickcraft","player_exploration_scale");
    public static boolean allowed(double value){return Double.isFinite(value)&&value>=MIN&&value<=MAX;}
    public static void receive(class_3222 player,PlayerScalePayload packet){
        double requested=packet.scale();
        if(!allowed(requested)||player.method_7325()||
           !(player.method_7337() || player.method_5682().method_3724())){
            player.method_7353(class_2561.method_43470("BrickCraft : taille refusee (partie solo ou mode creatif requis)"),false);return;
        }
        var attribute=player.method_5996(class_5134.field_47760);
        if(attribute==null)return;
        double oldEffectiveScale=attribute.method_6194();
        class_1322 previous=attribute.method_6199(MODIFIER_ID);
        attribute.method_6200(MODIFIER_ID);
        if(Math.abs(requested-1.0)>0.00001)
            attribute.method_26837(new class_1322(MODIFIER_ID,requested-1.0,
                    class_1322.class_1323.field_6330));
        player.method_18382();
        // Avoid growing inside walls. A failed change restores the former attribute and bounding box.
        if(attribute.method_6194()>oldEffectiveScale+1e-5 &&
           !player.method_37908().method_8587(player,player.method_5829())){
            attribute.method_6200(MODIFIER_ID);
            if(previous!=null)attribute.method_26837(previous);
            player.method_18382();
            player.method_7353(class_2561.method_43470("BrickCraft : agrandissement impossible ici (obstacle). Deplace-toi."),false);
            return;
        }
        player.method_7353(class_2561.method_43470(String.format(Locale.ROOT,
                "BrickCraft : taille x%.3f | hitbox et yeux adaptes (U pour regler)",requested)),true);
    }
    /** Retain the setting across respawns, if vanilla recreates the attribute container. */
    public static void respawn(class_3222 oldPlayer,class_3222 newPlayer,boolean alive){
        var oldAttr=oldPlayer.method_5996(class_5134.field_47760);
        var nextAttr=newPlayer.method_5996(class_5134.field_47760);
        if(oldAttr==null||nextAttr==null)return;
        class_1322 old=oldAttr.method_6199(MODIFIER_ID);
        if(old!=null){nextAttr.method_61163(old);newPlayer.method_18382();}
    }
}
