package fr.brickcraft.net;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Bounded stream of original LDU coordinates + full 3x3 matrices, never rounded to the Minecraft grid. */
public record PreciseExportPayload(byte operation, class_2338 origin,int total,int offset,
                                   List<LDrawProjectReader.Instance> parts) implements class_8710 {
    public static final byte BEGIN=0,PARTS=1,COMMIT=2,CANCEL=3;
    public static final int BATCH_SIZE=16;
    public static final class_8710.class_9154<PreciseExportPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","precise_export"));
    public static final class_9139<class_9129,PreciseExportPayload> CODEC =
            class_9139.method_56438(PreciseExportPayload::write,PreciseExportPayload::read);
    public static PreciseExportPayload begin(class_2338 origin,int total){return new PreciseExportPayload(BEGIN,origin,total,0,List.of());}
    public static PreciseExportPayload batch(int offset,List<LDrawProjectReader.Instance> parts){
        return new PreciseExportPayload(PARTS,class_2338.field_10980,0,offset,List.copyOf(parts));
    }
    public static PreciseExportPayload commit(){return new PreciseExportPayload(COMMIT,class_2338.field_10980,0,0,List.of());}
    public static PreciseExportPayload cancel(){return new PreciseExportPayload(CANCEL,class_2338.field_10980,0,0,List.of());}
    private void write(class_9129 buf){
        buf.method_52997(operation);
        if(operation==BEGIN){buf.method_10807(origin);buf.method_10804(total);}
        if(operation==PARTS){
            buf.method_10804(offset);buf.method_10804(parts.size());
            for(var p:parts){
                buf.method_10788(p.partId(),96);buf.method_10804(p.color());
                buf.method_52940(p.x());buf.method_52940(p.y());buf.method_52940(p.z());
                for(double d:p.matrix())buf.method_52940(d);
            }
        }
    }
    private static PreciseExportPayload read(class_9129 buf){
        byte op=buf.readByte();
        if(op==BEGIN)return begin(buf.method_10811(),buf.method_10816());
        if(op==PARTS){
            int offset=buf.method_10816(),count=buf.method_10816();
            if(offset<0||count<1||count>BATCH_SIZE)throw new IllegalArgumentException("Lot precis invalide");
            List<LDrawProjectReader.Instance> parts=new ArrayList<>(count);
            for(int i=0;i<count;i++){
                String name=buf.method_10800(96);int color=buf.method_10816();
                double x=buf.readDouble(),y=buf.readDouble(),z=buf.readDouble();
                double[] m=new double[9];for(int j=0;j<9;j++)m[j]=buf.readDouble();
                parts.add(new LDrawProjectReader.Instance(name,color,x,y,z,m));
            }
            return batch(offset,parts);
        }
        if(op==COMMIT)return commit();
        if(op==CANCEL)return cancel();
        throw new IllegalArgumentException("Operation precise inconnue");
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
