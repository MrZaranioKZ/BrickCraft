package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseWorldModel;
import org.jetbrains.annotations.Nullable;
import java.io.IOException;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/** Single-NBT-anchor storage; keep compressed original bytes even if complete.zip is missing. */
public final class PreciseDisplayEntity extends class_2586 {
    private PreciseWorldModel model;
    private byte[] packed=new byte[0];
    private boolean decodeAttempted=false;
    public PreciseDisplayEntity(class_2338 pos,class_2680 state){super(BrickCraft.PRECISE_ENTITY,pos,state);}
    public PreciseWorldModel model(){
        if(model==null && packed.length>0 && !decodeAttempted){
            decodeAttempted=true;
            try{model=PreciseWorldModel.readBytes(packed);}catch(IOException ignored){}
        }
        return model;
    }
    public void setModel(PreciseWorldModel value)throws IOException{
        byte[] bytes=value.writeBytes();
        this.model=value;this.packed=bytes;this.decodeAttempted=true;method_5431();
        if(field_11863 instanceof net.minecraft.class_3218 server)server.method_14178().method_14128(field_11867);
    }
    @Override protected void method_11007(class_2487 nbt,class_7225.class_7874 registry){
        super.method_11007(nbt,registry);
        nbt.method_10570("BrickCraftPreciseV1",packed);
    }
    @Override public void method_11014(class_2487 nbt,class_7225.class_7874 registry){
        super.method_11014(nbt,registry);
        packed=nbt.method_10547("BrickCraftPreciseV1");model=null;decodeAttempted=false;
        // Preserve corrupted/missing-library data in NBT instead of silently deleting it.
        if(packed.length>0)model();
    }
    @Override public @Nullable class_2596<class_2602> method_38235(){
        return class_2622.method_38585(this);
    }
    @Override public class_2487 method_16887(class_7225.class_7874 registry){
        return method_38244(registry);
    }
}
