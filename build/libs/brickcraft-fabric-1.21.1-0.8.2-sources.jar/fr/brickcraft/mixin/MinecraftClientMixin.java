package fr.brickcraft.mixin;

import fr.brickcraft.client.BrickCraftClient;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Intercept vanilla middle-click ONLY on BrickCraft cells; leave normal blocks unchanged. */
@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Inject(method="doItemPick",at=@At("HEAD"),cancellable=true)
    private void brickcraft$pickBrick(CallbackInfo ci){
        if(BrickCraftClient.pickBrick((class_310)(Object)this))ci.cancel();
    }
}
