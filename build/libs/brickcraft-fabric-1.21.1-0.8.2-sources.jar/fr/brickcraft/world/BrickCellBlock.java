package fr.brickcraft.world;

import com.mojang.serialization.MapCodec;
import fr.brickcraft.core.BrickPiece;
import java.util.ArrayList;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

/** One Minecraft block per stud and vertical slice, with precise LEGO-height shapes. */
public final class BrickCellBlock extends class_2237 {
    public static final MapCodec<BrickCellBlock> CODEC = method_54094(BrickCellBlock::new);
    public BrickCellBlock(class_2251 settings) { super(settings); }
    @Override public MapCodec<? extends class_2237> method_53969() { return field_46280; }

    @Override public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new BrickCellEntity(pos, state);
    }

    @Override protected class_265 method_9530(class_2680 state, class_1922 world,
                                                     class_2338 pos, class_3726 context) {
        if (!(world.method_8321(pos) instanceof BrickCellEntity cell)) return class_259.method_1077();
        class_265 shape = class_259.method_1073();
        for (BrickPiece part : cell.pieces()) {
            double bottom = Math.max(0.0, part.y()/5.0-pos.method_10264());
            double top = Math.min(1.0, part.top()/5.0-pos.method_10264());
            if (top > bottom) shape = class_259.method_1084(shape, class_259.method_1081(0,bottom,0,1,top,1));
            if (part.kind().studs) {
                double studLow = Math.max(0.0, part.top()/5.0-pos.method_10264());
                double studHigh = Math.min(1.0, (part.top()+1)/5.0-pos.method_10264());
                if (studHigh > studLow) shape = class_259.method_1084(shape,
                        class_259.method_1081(.2,studLow,.2,.8,studHigh,.8));
            }
        }
        return shape.method_1110() ? class_259.method_1077() : shape;
    }

    /** Mining any fragment dismantles complete affected pieces, preventing orphan visuals. */
    @Override protected void method_9536(class_2680 state, class_1937 world, class_2338 pos,
                                             class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204()) && !world.field_9236
                && world.method_8321(pos) instanceof BrickCellEntity cell) {
            for (BrickPiece part : new ArrayList<>(cell.pieces())) {
                for (class_2338 other : part.occupiedCells()) {
                    if (other.equals(pos) || !world.method_22340(other)) continue;
                    if (world.method_8321(other) instanceof BrickCellEntity neighbor && neighbor.remove(part)
                            && neighbor.pieces().isEmpty()) {
                        world.method_8652(other, class_2246.field_10124.method_9564(), 3);
                    }
                }
            }
        }
        super.method_9536(state,world,pos,newState,moved);
    }

    @Override protected class_265 method_9549(class_2680 state, class_1922 world,
                                                       class_2338 pos, class_3726 context) {
        return method_9530(state,world,pos,context);
    }
}
