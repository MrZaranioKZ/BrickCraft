package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.world.PreciseDisplayEntity;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;

/** Renders an anchored BCPX assembly. All transformations remain full LDraw matrices. */
public final class PreciseDisplayRenderer implements class_827<PreciseDisplayEntity> {
    private static final class_2960 WHITE=class_2960.method_60655("minecraft","textures/block/white_concrete.png");
    private static final int MAX_MESH_TRIANGLES=4000;
    // Only decode a handful of new meshes per frame. This avoids a multi-second frame hitch.
    private static final int NEW_MESHES_PER_FRAME=3;
    private static final int MAX_CACHED_TRIANGLES=240_000;
    private final Map<String,LDrawLibrary.Mesh> cachedMeshes=new HashMap<>();
    private final Set<String> noMesh=new HashSet<>();
    private int totalCachedTriangles=0;
    private final int renderDistance;
    private final int maxRealTriangles;
    private final double meshRadius;
    public PreciseDisplayRenderer(class_5614.class_5615 unused){
        java.nio.file.Path config=FabricLoader.getInstance().getConfigDir();
        renderDistance=BrickRenderDistanceConfig.load(config);
        java.util.Properties properties=new java.util.Properties();
        java.nio.file.Path file=config.resolve("brickcraft").resolve("precise-render.properties");
        try{
            java.nio.file.Files.createDirectories(file.getParent());
            if(java.nio.file.Files.isRegularFile(file))try(var input=java.nio.file.Files.newInputStream(file)){
                properties.load(input);
            }
            else{
                properties.setProperty("max_real_triangles","28000");
                properties.setProperty("mesh_radius_blocks","42");
                try(var out=java.nio.file.Files.newOutputStream(file)){
                    properties.store(out,"BrickCraft: 0.9.1 precise world projection (restart Minecraft to apply)");
                }
            }
        }catch(java.io.IOException ignored){}
        maxRealTriangles=clampInt(properties.getProperty("max_real_triangles"),28000,4000,100000);
        meshRadius=clampInt(properties.getProperty("mesh_radius_blocks"),42,8,96);
    }
    private static int clampInt(String input,int fallback,int min,int max){
        try{return Math.max(min,Math.min(max,Integer.parseInt(input)));}
        catch(NumberFormatException ignored){return fallback;}
    }
    @Override public int method_33893(){return renderDistance;}
    @Override public boolean rendersOutsideBoundingBox(PreciseDisplayEntity be){return true;}

    private LDrawLibrary.Mesh getMesh(String id,int[] slots){
        if(cachedMeshes.containsKey(id))return cachedMeshes.get(id);
        if(noMesh.contains(id)||slots[0]<=0)return null;
        slots[0]--;
        LDrawLibrary.Mesh mesh=LDrawLibrary.mesh(id);
        if(mesh==null || mesh.isEmpty() || mesh.triangles()>MAX_MESH_TRIANGLES ||
                totalCachedTriangles+mesh.triangles()>MAX_CACHED_TRIANGLES){
            noMesh.add(id);return null;
        }
        cachedMeshes.put(id,mesh);totalCachedTriangles+=mesh.triangles();return mesh;
    }
    @Override public void render(PreciseDisplayEntity be,float tickDelta,class_4587 matrices,
                                 class_4597 provider,int light,int overlay){
        PreciseWorldModel model=be.model();if(model==null)return;
        // Single layer/consumer prevents the previous V0.6.1 "Not building!" buffer crash.
        class_4588 out=provider.getBuffer(class_1921.method_23580(WHITE));
        class_243 camera=class_310.method_1551().field_1773.method_19418().method_19326();
        double ox=be.method_11016().method_10263(),oy=be.method_11016().method_10264(),oz=be.method_11016().method_10260();
        int triangles=0;int[] slots={NEW_MESHES_PER_FRAME};
        for(LDrawProjectReader.Instance p:model.parts()){
            String id=PreciseReferenceMapper.geometryId(p.partId());
            if(id==null)continue;
            // Source origins are not exact geometric centres, but adequate for LOD.
            double px=ox+p.x()/20-model.minX(),
                   py=oy-p.y()/20-model.minY(),
                   pz=oz+p.z()/20-model.minZ();
            double distSq=camera.method_1028(px,py,pz);
            if(distSq<meshRadius*meshRadius && triangles<maxRealTriangles){
                LDrawLibrary.Mesh mesh=getMesh(id,slots);
                double[] bounds=LDrawLibrary.originalBounds(id);
                if(mesh!=null && bounds!=null && triangles+mesh.triangles()<=maxRealTriangles){
                    triangles+=drawMesh(out,matrices,p,mesh,bounds,model,light);
                    continue;
                }
            }
            drawBox(out,matrices,p,id,model,light);
        }
    }
    /** One LDraw vertex, converted from original units through the source 3x3 matrix. */
    private static float[] transform(LDrawProjectReader.Instance p,PreciseWorldModel model,
                                     double[] m,double lx,double ly,double lz){
        return new float[]{
            (float)((p.x()+m[0]*lx+m[1]*ly+m[2]*lz)/20-model.minX()),
            (float)(-(p.y()+m[3]*lx+m[4]*ly+m[5]*lz)/20-model.minY()),
            (float)((p.z()+m[6]*lx+m[7]*ly+m[8]*lz)/20-model.minZ())
        };
    }
    private static int drawMesh(class_4588 out,class_4587 mat,LDrawProjectReader.Instance p,
                                LDrawLibrary.Mesh mesh,double[] bounds,PreciseWorldModel model,int light){
        float[] xyz=mesh.xyz();int[] faceColors=mesh.colors();double[] matrix=p.matrix();
        for(int i=0;i<mesh.triangles();i++){
            float[][] v=new float[3][3];
            for(int j=0;j<3;j++){
                int a=i*9+j*3;
                double x=bounds[0]+xyz[a]*20,y=bounds[4]-xyz[a+1]*20,z=bounds[2]+xyz[a+2]*20;
                v[j]=transform(p,model,matrix,x,y,z);
            }
            int color=LDrawLibrary.meshColor(faceColors[i],p.color(),LDrawLibrary.resolveColor(p.color(),0xD0D0D0));
            emitTriangle(out,mat,v[0],v[1],v[2],color,light);
            emitTriangle(out,mat,v[2],v[1],v[0],color,light);
        }
        return mesh.triangles();
    }
    private static void drawBox(class_4588 out,class_4587 mat,LDrawProjectReader.Instance p,
                                String id,PreciseWorldModel model,int light){
        double[] b=LDrawLibrary.originalBounds(id);
        if(b==null)return;
        double[] matrix=p.matrix();float[][] corners=new float[8][];
        for(int i=0;i<8;i++){
            double x=b[(i&1)==0?0:3],y=b[(i&2)==0?1:4],z=b[(i&4)==0?2:5];
            corners[i]=transform(p,model,matrix,x,y,z);
        }
        int color=LDrawLibrary.argb(p.color(),LDrawLibrary.resolveColor(p.color(),0xCCCCCC));
        int[][] sides={{0,1,3,2},{4,6,7,5},{0,4,5,1},{2,3,7,6},{0,2,6,4},{1,5,7,3}};
        for(int[] face:sides){
            emitTriangle(out,mat,corners[face[0]],corners[face[1]],corners[face[2]],color,light);
            emitTriangle(out,mat,corners[face[0]],corners[face[2]],corners[face[3]],color,light);
        }
    }
    private static void emitTriangle(class_4588 out,class_4587 mat,float[] a,float[] b,float[] c,
                                     int argb,int light){
        float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2];
        float vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
        float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(len<1e-7f)return;
        nx/=len;ny/=len;nz/=len;
        float[][] v={a,b,c,c};
        for(int i=0;i<4;i++)out.method_56824(mat.method_23760(),v[i][0],v[i][1],v[i][2])
                .method_39415(argb).method_22913(i%2,i/2).method_22922(class_4608.field_21444).method_60803(light)
                .method_60831(mat.method_23760(),nx,ny,nz);
    }
}
