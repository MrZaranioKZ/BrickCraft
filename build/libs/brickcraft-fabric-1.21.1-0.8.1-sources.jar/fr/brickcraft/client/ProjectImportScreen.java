package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.StudioProjectAnalysis;
import fr.brickcraft.importer.BrickCraftProjectConverter;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.ldraw.LDrawLibrary.Colour;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

/** Direct .io/.mpd/.ldr loader, with lossless diagnostics and a source-coordinate preview. */
public final class ProjectImportScreen extends class_437 {
    private final BrickStudioScreen parent;
    private final Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
    private List<Path> sources=List.of();
    private int index=0;
    private LDrawProjectReader.Result current;
    private StudioProjectAnalysis.Summary summary;
    private String status="Depose un fichier .io, .mpd ou .ldr dans le dossier imports.";
    private double orbit=.72, zoom=1.0, panX=0, panY=0;
    private boolean orbiting=false,panning=false;
    private int lastX,lastY;
    private record Dot(int x,int y,double depth,int color){}
    public ProjectImportScreen(BrickStudioScreen parent){
        super(class_2561.method_43470("BrickCraft - Importer un projet BrickLink"));
        this.parent=parent;
        reloadFiles();
    }
    private void reloadFiles(){
        try{
            Files.createDirectories(folder);
            try(var stream=Files.list(folder)){
                sources=stream.filter(Files::isRegularFile).filter(p->{
                    String n=p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".io")||n.endsWith(".mpd")||n.endsWith(".ldr");
                }).sorted(Comparator.comparing(p->p.getFileName().toString(),String.CASE_INSENSITIVE_ORDER)).limit(200).toList();
            }
            index=Math.min(Math.max(0,index),Math.max(0,sources.size()-1));
        }catch(IOException e){status="Lecture du dossier impossible : "+e.getMessage();sources=List.of();}
    }
    private Path selectedFile(){return sources.isEmpty()?null:sources.get(index);}
    private void select(int offset){
        if(sources.isEmpty())return;
        index=Math.floorMod(index+offset,sources.size());
        current=null;summary=null;status="Selection : "+selectedFile().getFileName();
    }
    private void analyze(){
        Path source=selectedFile();
        if(source==null){status="Aucun fichier. Copie ton .io dans config/brickcraft/imports/";return;}
        try{
            current=LDrawProjectReader.inspect(source);
            summary=StudioProjectAnalysis.analyze(current);
            status="Charge : "+summary.quickStatus()+" (aperçu des origines)";
            panX=panY=0;zoom=1;
            saveReport();
        }catch(Exception e){current=null;summary=null;status="Erreur d'analyse : "+e.getMessage();}
    }
    private void saveReport()throws IOException {
        if(summary==null || selectedFile()==null)return;
        String name=selectedFile().getFileName().toString().replaceAll("[^a-zA-Z0-9._-]","_");
        Path report=folder.resolve("reports").resolve(name+".diagnostic.txt");
        Files.createDirectories(report.getParent());
        Files.writeString(report,StudioProjectAnalysis.report(summary,selectedFile().getFileName().toString()));
    }
    private void convert(){
        if(current==null){status="Analyse d'abord le projet";return;}
        if(summary.missingInstances()>0 || summary.angled()>0){
            status="Import sans perte impossible : references manquantes ou rotations libres (voir rapport)";return;
        }
        try{
            BrickCraftProjectConverter.Conversion c=BrickCraftProjectConverter.convert(current);
            if(!c.success()){
                status="Conversion refusee : "+c.errors().get(0);
                return;
            }
            if(parent.acceptImportedProject(c.grid(),c.pieces())){
                field_22787.method_1507(parent);
            }else status="Le Studio refuse ce projet (limites ou collisions)";
        }catch(Exception e){status="Conversion echouee : "+e.getMessage();}
    }
    private void addButton(int x,int y,int w,int h,String label,Runnable click){
        if(w<16)return;
        method_37063(class_4185.method_46430(class_2561.method_43470(label),b->click.run()).method_46434(x,y,w,h).method_46431());
    }
    @Override protected void method_25426(){
        int pWidth=Math.max(228,Math.min(315,field_22789/3));
        addButton(10,40,(pWidth-25)/2,20,"< Projet",()->select(-1));
        addButton((pWidth+5)/2,40,(pWidth-25)/2,20,"Projet >",()->select(1));
        addButton(10,67,pWidth-20,20,"Actualiser les fichiers",()->{reloadFiles();status="Dossier actualise";});
        addButton(10,93,pWidth-20,20,"1. Analyser / previsualiser",this::analyze);
        addButton(10,120,pWidth-20,20,"2. Importer dans le Studio (strict)",this::convert);
        addButton(10,field_22790-47,pWidth-20,20,"Retour au Studio",()->field_22787.method_1507(parent));
    }
    @Override public void method_25420(class_332 context,int mx,int my,float delta){}
    private void drawText(class_332 ctx,String s,int x,int y,int max,int color){
        if(max<10)return;
        if(field_22793.method_1727(s)>max){
            String suffix="...";
            int n=s.length();
            while(n>0 && field_22793.method_1727(s.substring(0,n)+suffix)>max)n--;
            s=s.substring(0,n)+suffix;
        }
        ctx.method_25303(field_22793,s,x,y,color);
    }
    @Override public void method_25394(class_332 ctx,int mx,int my,float dt){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B111A);
        int side=Math.max(228,Math.min(315,field_22789/3));
        int left=side+6, top=36, right=field_22789-8,bottom=field_22790-34;
        ctx.method_25294(4,30,side,bottom,0xFF162330);
        ctx.method_25294(left,top,right,bottom,0xFF0A1C29);
        drawText(ctx,"BRICKCRAFT  /  IMPORT IO-LDRAW 0.8.1",10,10,field_22789-20,0xFFE2F4FF);
        drawText(ctx,"Fichiers : "+sources.size(),12,165,side-22,0xFF9BC4D7);
        drawText(ctx,selectedFile()==null?"Aucun fichier detecte":selectedFile().getFileName().toString(),12,181,side-22,0xFFFFFFFF);
        if(summary!=null){
            int y=210;
            String[] lines={
                "Pieces : "+summary.pieces(),
                "Formes : "+summary.designs()+" | Couleurs : "+summary.colors(),
                "Sous-modeles : "+summary.project().submodels(),
                "References manquantes : "+summary.missingInstances(),
                "X hors grille : "+summary.fractionalX(),
                "Z hors grille : "+summary.fractionalZ(),
                "Hauteurs fines : "+summary.fractionalY(),
                "Rotations libres : "+summary.angled(),
                "Apercu = points de pose (sans maillages)",
                "Rapport : imports/reports/*.txt"
            };
            for(String line:lines){drawText(ctx,line,12,y,side-22,y==210?0xFF71E2D5:0xFFA7C6D8);y+=15;}
            if(summary.missingInstances()>0||summary.angled()>0){
                drawText(ctx,"Import complet non supporte",12,y+6,side-20,0xFFFFBB79);
            }
        }else{
            drawText(ctx,"Place tes projets dans :",12,210,side-20,0xFF9FC4D9);
            drawText(ctx,"config/brickcraft/imports/",12,227,side-20,0xFF8EDBE1);
            drawText(ctx,"Formats : .io, .ldr, .mpd",12,250,side-20,0xFF9FC4D9);
        }
        drawText(ctx,"Source originale | orbite : clic droit | zoom : molette",left+7,top+8,right-left-14,0xFFB0D9E8);
        drawText(ctx,"Le projet n'est jamais arrondi ou construit automatiquement",left+7,top+22,right-left-14,0xFF9BB9C8);
        if(summary!=null)renderDots(ctx,left+5,top+38,right-5,bottom-5);
        drawText(ctx,status,10,field_22790-18,field_22789-20,0xFFEED29A);
        super.method_25394(ctx,mx,my,dt);
    }
    private void renderDots(class_332 ctx,int x1,int y1,int x2,int y2){
        if(summary==null||x2<=x1||y2<=y1)return;
        int count=summary.project().parts().size();
        if(count==0)return;
        double spanX=Math.max(20,summary.maxX()-summary.minX());
        double spanZ=Math.max(20,summary.maxZ()-summary.minZ());
        double spanY=Math.max(8,summary.maxY()-summary.minY());
        double c=Math.cos(orbit),s=Math.sin(orbit);
        double[][] sample={{0,0,0},{spanX,0,0},{0,0,spanZ},{spanX,0,spanZ},
                           {0,spanY,0},{spanX,spanY,0},{0,spanY,spanZ},{spanX,spanY,spanZ}};
        double boundX=1,boundY=1;
        for(double[] v:sample){
            double px=(v[0]-spanX/2)*c-(v[2]-spanZ/2)*s;
            double py=((v[0]-spanX/2)*s+(v[2]-spanZ/2)*c)*.40-(v[1]-spanY/2)*.86;
            boundX=Math.max(boundX,Math.abs(px));boundY=Math.max(boundY,Math.abs(py));
        }
        double unit=Math.min((x2-x1-32)/2.0/boundX,(y2-y1-32)/2.0/boundY)*zoom;
        double centerX=(x1+x2)/2.+panX,centerY=(y1+y2)/2.+panY;
        ArrayList<Dot> dots=new ArrayList<>(count);
        for(var p:summary.project().parts()){
            double xx=p.x()-summary.minX()-spanX/2;
            double zz=p.z()-summary.minZ()-spanZ/2;
            double yy=summary.maxY()-p.y()-spanY/2;
            double screenX=centerX+(xx*c-zz*s)*unit;
            double depth=xx*s+zz*c;
            double screenY=centerY+(depth*.40-yy*.86)*unit;
            if(screenX<x1+1||screenX>x2-1||screenY<y1+1||screenY>y2-1)continue;
            var color=LDrawLibrary.color(p.color());
            dots.add(new Dot((int)screenX,(int)screenY,depth,color==null?0xFFCED4DE:0xFF000000|color.rgb()));
        }
        dots.sort(Comparator.comparingDouble(Dot::depth));
        ctx.method_44379(x1,y1,x2,y2);
        for(Dot d:dots){
            int size=Math.max(2,Math.min(5,(int)(unit*8)));
            ctx.method_25294(d.x-size/2,d.y-size/2,d.x+size/2+1,d.y+size/2+1,d.color);
        }
        ctx.method_44380();
        drawText(ctx,count+" points de pose (LDU, sans geometries exactes)",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    @Override public boolean method_25402(double x,double y,int btn){
        if(x>=Math.max(228,Math.min(315,field_22789/3))+6 && y>36 && y<field_22790-34){
            if(btn==1){orbiting=true;lastX=(int)x;lastY=(int)y;return true;}
            if(btn==2){panning=true;lastX=(int)x;lastY=(int)y;return true;}
        }
        return super.method_25402(x,y,btn);
    }
    @Override public boolean method_25403(double x,double y,int button,double dx,double dy){
        if(orbiting && button==1){orbit+=dx*.01;return true;}
        if(panning && button==2){panX+=dx;panY+=dy;return true;}
        return super.method_25403(x,y,button,dx,dy);
    }
    @Override public boolean method_25406(double x,double y,int btn){
        if(btn==1)orbiting=false;
        if(btn==2)panning=false;
        return super.method_25406(x,y,btn);
    }
    @Override public boolean method_25401(double x,double y,double horiz,double vert){
        if(x>Math.max(228,Math.min(315,field_22789/3))){zoom=Math.max(.1,Math.min(15,zoom*Math.pow(1.15,vert)));return true;}
        return super.method_25401(x,y,horiz,vert);
    }
    @Override public boolean method_25404(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE){field_22787.method_1507(parent);return true;}
        if(key==GLFW.GLFW_KEY_R){reloadFiles();return true;}
        if(key==GLFW.GLFW_KEY_ENTER){analyze();return true;}
        return super.method_25404(key,scan,mods);
    }
}
