package fr.brickcraft.client;

import fr.brickcraft.net.PreciseManagePayload;
import fr.brickcraft.net.PrecisePhysicsPayload;
import fr.brickcraft.net.PreciseManageStatusPayload;
import fr.brickcraft.net.PreciseManageStatusPayload.Entry;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.List;

/** Dedicated world-projection manager: it never deletes a file on disk. */
public final class PreciseWorldProjectsScreen extends class_437 {
    private final class_437 previous;
    private List<PreciseManageStatusPayload.Entry> entries=List.of();
    private int selected=-1,page=0;
    private String status="Recherche des projections chargees...";
    private static final int MAX_PAGE_ROWS=6;
    /** Keep the projection list above the action panel at larger GUI scales. */
    private int pageRows(){return Math.clamp((field_22790-198)/29,1,MAX_PAGE_ROWS);}
    private boolean requested=false;
    public PreciseWorldProjectsScreen(class_437 previous){
        super(class_2561.method_43470(BrickI18n.tr("BrickCraft - Projections du monde")));this.previous=previous;
    }
    private void button(int x,int y,int w,int h,String text,Runnable callback){
        button(x,y,w,h,text,true,callback);
    }
    private void button(int x,int y,int w,int h,String text,boolean enabled,Runnable callback){
        class_4185 widget=class_4185.method_46430(class_2561.method_43470(BrickI18n.tr(text)),b->callback.run())
                .method_46434(x,y,w,h).method_46431();
        widget.field_22763=enabled;
        method_37063(widget);
    }
    @Override protected void method_25426(){
        rebuild();
        if(!requested){requested=true;refresh();}
    }
    private void rebuild(){
        method_37067();
        int x=Math.max(10,field_22789/2-235),w=Math.min(470,field_22789-20);
        int listY=68,rows=pageRows();
        page=Math.clamp(page,0,Math.max(0,(entries.size()-1)/rows));
        for(int row=0;row<rows;row++){
            final int which=page*rows+row;
            if(which>=entries.size())break;
            var p=entries.get(which);
            button(x,listY+row*29,w,23,BrickI18n.fmt("brickcraft.v252.projections.item",(which==selected?"✓ ":""),which+1,p.pieces(),p.anchor().method_23854()),
                    ()->{selected=which;rebuild();});
        }
        int navY=Math.min(Math.max(listY+rows*29+6,field_22790-140),field_22790-116);
        boolean hasSelection=selected>=0 && selected<entries.size();
        int lastPage=Math.max(0,(entries.size()-1)/rows);
        button(x,navY,(w-8)/2,20,"< Page",page>0,()->{page=Math.max(0,page-1);rebuild();});
        button(x+(w+8)/2,navY,(w-8)/2,20,"Page >",page<lastPage,()->{
            page=Math.min(lastPage,page+1);rebuild();});
        button(x,navY+26,(w-8)/2,22,"Physique ON",hasSelection,()->askPhysics(true));
        button(x+(w+8)/2,navY+26,(w-8)/2,22,"Physique OFF",hasSelection,()->askPhysics(false));
        button(x,navY+54,w,20,"Retirer la projection selectionnee",hasSelection,this::askRemove);
        int third=(w-16)/3;
        button(x,navY+80,third,20,"Taille/hitbox (U)",
                ()->field_22787.method_1507(new BrickPlayerScaleScreen(this)));
        button(x+third+8,navY+80,third,20,"Actualiser",this::refresh);
        button(x+2*(third+8),navY+80,third,20,"Retour import",()->field_22787.method_1507(previous));
    }
    private void refresh(){
        if(field_22787.field_1724==null||field_22787.field_1687==null){status="Ouvre un monde pour gerer ses projections.";return;}
        status="Recherche des ancres dans les chunks charges (192 blocs)...";
        ClientPlayNetworking.send(PreciseManagePayload.list());
    }
    private void askPhysics(boolean enable){
        if(selected<0||selected>=entries.size()){status="Selectionne une projection d'abord.";return;}
        var p=entries.get(selected);
        field_22787.method_1507(new BrickConfirmScreen(this,BrickI18n.fmt(enable?"brickcraft.v252.projections.physics_on.title":"brickcraft.v252.projections.physics_off.title"),
                BrickI18n.fmt(enable?"brickcraft.v252.projections.physics_on.detail":"brickcraft.v252.projections.physics_off.detail"),()->{status=BrickI18n.fmt("brickcraft.v252.projections.requested");
                    ClientPlayNetworking.send(new PrecisePhysicsPayload(p.anchor(),enable));}));
    }
    private void askRemove(){
        if(selected<0||selected>=entries.size()){status="Selectionne une projection dans la liste.";return;}
        var p=entries.get(selected);
        field_22787.method_1507(new BrickConfirmScreen(this,BrickI18n.fmt("brickcraft.v252.projections.remove.title"),
                BrickI18n.fmt("brickcraft.v252.projections.remove.detail",p.pieces(),p.anchor().method_23854()),
                ()->{status=BrickI18n.fmt("brickcraft.v252.projections.removal_requested");ClientPlayNetworking.send(PreciseManagePayload.remove(p.anchor()));}));
    }
    public void receive(PreciseManageStatusPayload response){
        status=response.message();
        if(response.event()==PreciseManageStatusPayload.LIST){
            entries=response.projects();selected=-1;page=0;rebuild();
        }else if(response.event()==PreciseManageStatusPayload.REMOVED){
            entries=List.of();selected=-1;page=0;rebuild();refresh();
        }
    }
    @Override public void method_25420(class_332 ctx,int mouseX,int mouseY,float delta){}
    @Override public void method_25394(class_332 ctx,int mouseX,int mouseY,float delta){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0A1420);
        int x=Math.max(10,field_22789/2-235),w=Math.min(470,field_22789-20);
        ctx.method_25294(x-5,34,x+w+5,field_22790-19,0xFF142535);
        ctx.method_25294(x-5,34,x+w+5,38,0xFF55CFD8);
        String heading=BrickI18n.tr("BRICKCRAFT / PROJECTIONS");
        ctx.method_25303(field_22793,heading,(field_22789-field_22793.method_1727(heading))/2,14,0xFFE7F8FF);
        String count=BrickI18n.fmt("brickcraft.v252.projections.count",entries.size(),page+1);
        ctx.method_25303(field_22793,field_22793.method_27523(count,w-8),x+4,45,0xFFA5CBD9);
        if(entries.isEmpty()){
            String empty=BrickI18n.tr("Aucune projection chargee dans les 192 blocs autour de toi.");
            ctx.method_25303(field_22793,field_22793.method_27523(empty,w-15),
                    x+8,115,0xFFE7C992);
        }
        // Translate before measuring. Truncating first used to break the translation key.
        String message=BrickI18n.tr(status);
        message=field_22793.method_27523(message,Math.max(0,field_22789-24));
        ctx.method_25294(0,field_22790-18,field_22789,field_22790,0xFF102132);
        ctx.method_25303(field_22793,message,10,field_22790-14,0xFFE5CE94);
        super.method_25394(ctx,mouseX,mouseY,delta);
    }
    @Override public void method_25419(){field_22787.method_1507(previous);}
}
