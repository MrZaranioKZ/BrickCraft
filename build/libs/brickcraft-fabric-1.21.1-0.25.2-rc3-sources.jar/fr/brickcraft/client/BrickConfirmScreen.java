package fr.brickcraft.client;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/** Accessible confirmation. Never clip warning details after localization. */
public final class BrickConfirmScreen extends class_437 {
    private final class_437 previous;
    private final String detail;
    private final Runnable confirm;
    public BrickConfirmScreen(class_437 previous,String title,String detail,Runnable confirm){
        super(class_2561.method_43470(BrickI18n.tr(title)));
        this.previous=previous;this.detail=detail;this.confirm=confirm;
    }
    private int panelWidth(){return Math.min(500,Math.max(160,field_22789-22));}
    private int textWidth(){return Math.max(100,panelWidth()-28);}
    private List<class_5481> titleLines(){
        return field_22793.method_1728(class_2561.method_43470(BrickI18n.tr(field_22785.getString())),textWidth());
    }
    private List<class_5481> descriptionLines(){
        return field_22793.method_1728(class_2561.method_43470(BrickI18n.tr(detail)),textWidth());
    }
    private int dialogHeight(){
        int lines=Math.max(1,titleLines().size())+Math.max(1,descriptionLines().size());
        return Math.min(field_22790-8,55+lines*12);
    }
    private int dialogTop(){return Math.max(4,(field_22790-dialogHeight())/2);}
    @Override protected void method_25426(){
        int w=panelWidth(),left=(field_22789-w)/2,buttonW=Math.max(65,(w-36)/2),y=dialogTop()+dialogHeight()-32;
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.fmt("brickcraft.v252.confirm.ok")),
                b->{field_22787.method_1507(previous);confirm.run();})
                .method_46434(left+12,y,buttonW,22).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.fmt("brickcraft.v252.confirm.cancel")),
                b->field_22787.method_1507(previous))
                .method_46434(left+w-buttonW-12,y,buttonW,22).method_46431());
    }
    @Override public void method_25420(class_332 ctx,int mouseX,int mouseY,float delta){}
    @Override public void method_25394(class_332 ctx,int mouseX,int mouseY,float delta){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B1420);
        int w=panelWidth(),left=(field_22789-w)/2,top=dialogTop(),bottom=top+dialogHeight();
        ctx.method_25294(left,top,left+w,bottom,0xFF182A3B);
        ctx.method_25294(left,top,left+w,top+4,0xFFE3AB66);
        int y=top+12;
        for(class_5481 line:titleLines()){
            if(y>=bottom-50)break;
            ctx.method_35719(field_22793,line,field_22789/2,y,0xFFF5E9D8);y+=12;
        }
        y+=8;
        for(class_5481 line:descriptionLines()){
            if(y>=bottom-34)break;
            ctx.method_35719(field_22793,line,field_22789/2,y,0xFFD9E3EF);y+=12;
        }
        super.method_25394(ctx,mouseX,mouseY,delta);
    }
    @Override public void method_25419(){field_22787.method_1507(previous);}
}
