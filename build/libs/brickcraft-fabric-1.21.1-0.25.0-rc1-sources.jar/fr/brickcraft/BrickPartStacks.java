package fr.brickcraft;

import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.ldraw.LDrawLibrary.PartInfo;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/** Stable LDraw item identity independent of the client-only colour/part palette. */
public final class BrickPartStacks {
    private static final String KEY="BrickCraftPartId";
    private BrickPartStacks() {}

    public static class_1799 ldraw(String id,int amount) {
        if(id==null || !id.matches("[a-zA-Z0-9_-]{1,32}") || !LDrawLibrary.contains(id))
            throw new IllegalArgumentException("Reference LDraw inconnue : "+id);
        class_1799 stack=new class_1799(BrickCraft.LDRAW_ITEM,amount);
        class_2487 tag=new class_2487();tag.method_10582(KEY,id);
        class_9279.method_57453(class_9334.field_49628,stack,tag);
        var info=LDrawLibrary.info(id);
        stack.method_57379(class_9334.field_49631,class_2561.method_43470(info==null?"LDraw "+id:info.name()+" ["+id+"]"));
        return stack;
    }

    /** Null means a generic LDraw palette item (N key), not a broken item. */
    public static String boundLdrawId(class_1799 stack) {
        if(!stack.method_31574(BrickCraft.LDRAW_ITEM))return null;
        class_9279 data=stack.method_57824(class_9334.field_49628);
        if(data==null || !data.method_57450(KEY))return null;
        String id=data.method_57461().method_10558(KEY);
        return id.matches("[a-zA-Z0-9_-]{1,32}") && LDrawLibrary.contains(id)?id:null;
    }
}
