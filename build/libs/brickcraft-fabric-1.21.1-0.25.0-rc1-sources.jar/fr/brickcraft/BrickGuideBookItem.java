package fr.brickcraft;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

/** A real, registry-backed item. The reader is opened only on the client. */
public final class BrickGuideBookItem extends class_1792 {
    public BrickGuideBookItem(class_1793 settings) { super(settings); }

    @Override public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (world.field_9236) fr.brickcraft.client.BrickGuideBookScreen.open();
        return class_1271.method_29237(stack, world.method_8608());
    }
}
