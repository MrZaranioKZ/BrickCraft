package fr.brickcraft.client;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** A separate, modal confirmation: no parent widgets are drawn behind it. */
public final class BrickConfirmScreen extends class_437 {
    private final class_437 previous;
    private final String detail;
    private final Runnable confirm;
    public BrickConfirmScreen(class_437 previous,String title,String detail,Runnable confirm){
        super(class_2561.method_43470(BrickI18n.tr(title)));this.previous=previous;this.detail=detail;this.confirm=confirm;
    }
    @Override protected void method_25426(){
        int center=field_22789/2,y=field_22790/2+28;
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Confirmer")),b->{field_22787.method_1507(previous);confirm.run();})
                .method_46434(center-154,y,148,22).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Annuler")),b->field_22787.method_1507(previous))
                .method_46434(center+6,y,148,22).method_46431());
    }
    @Override public void method_25420(class_332 ctx,int mouseX,int mouseY,float delta){}
    @Override public void method_25394(class_332 ctx,int mouseX,int mouseY,float delta){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B1420);
        int x=Math.max(12,field_22789/2-220),r=Math.min(field_22789-12,field_22789/2+220);
        ctx.method_25294(x,field_22790/2-66,r,field_22790/2+71,0xFF182A3B);
        ctx.method_25294(x,field_22790/2-66,r,field_22790/2-62,0xFFE3AB66);
        ctx.method_27535(field_22793,BrickI18n.tr(field_22785),(field_22789-field_22793.method_27525(field_22785))/2,
                field_22790/2-45,0xFFF5E9D8);
        String s=detail;
        while(field_22793.method_1727(s)>r-x-24 && s.length()>8)s=s.substring(0,s.length()-4)+"...";
        ctx.method_25303(field_22793,BrickI18n.tr(s),(field_22789-field_22793.method_1727(s))/2,
                field_22790/2-15,0xFFD9E3EF);
        super.method_25394(ctx,mouseX,mouseY,delta);
    }
    @Override public void method_25419(){field_22787.method_1507(previous);}
}
