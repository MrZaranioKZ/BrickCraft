package fr.brickcraft.client;

import fr.brickcraft.net.PlayerScalePayload;
import fr.brickcraft.world.PlayerScaleManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5134;
import java.util.Locale;

/** Accessible with U or from the world-project menu. Uses a logarithmic scale for small LEGO explorers. */
public final class BrickPlayerScaleScreen extends class_437 {
    private final class_437 previous;
    private double selected;
    private class_357 slider;
    private static final double MIN=PlayerScaleManager.MIN,MAX=PlayerScaleManager.MAX;
    public BrickPlayerScaleScreen(class_437 previous){
        super(class_2561.method_43470(BrickI18n.tr("BrickCraft - Taille et hitbox du joueur")));this.previous=previous;
    }
    private static double fromSlider(double v){return MIN*Math.pow(MAX/MIN,v);}
    private static double toSlider(double value){return Math.clamp(Math.log(value/MIN)/Math.log(MAX/MIN),0,1);}
    private static String format(double d){return String.format(Locale.FRANCE,"%.2f",d);}
    @Override protected void method_25426(){
        if(slider==null){
            double actual=field_22787!=null&&field_22787.field_1724!=null?
                field_22787.field_1724.method_45325(class_5134.field_47760):1.0;
            selected=Math.clamp(actual,MIN,MAX);
        }
        int w=Math.min(370,field_22789-30),x=(field_22789-w)/2,y=Math.max(55,field_22790/2-67);
        slider=method_37063(new class_357(x,y,w,20,class_2561.method_43473(),toSlider(selected)){
            @Override protected void method_25346(){selected=fromSlider(field_22753);method_25355(class_2561.method_43470(BrickI18n.tr("Taille x"+format(selected)+" | hitbox " + format(.6*selected)+" x "+format(1.8*selected)+" blocs")));}
            @Override protected void method_25344(){selected=fromSlider(field_22753);}
        });
        final double[] presets={.125,.25,.5,1,2,4};
        int gap=4,presetWidth=(w-gap*(presets.length-1))/presets.length;
        for(int i=0;i<presets.length;i++){
            double scale=presets[i],labelScale=scale;
            method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("x"+format(labelScale))),b->{
                selected=scale;method_41843();
            }).method_46434(x+i*(presetWidth+gap),y+28,presetWidth,20).method_46431());
        }
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Appliquer : taille + hitbox")),b->{
            if(field_22787!=null&&field_22787.field_1724!=null){
                ClientPlayNetworking.send(new PlayerScalePayload((float)selected));
                method_25419();
            }
        }).method_46434(x,y+60,w,21).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Retour")),b->method_25419())
                .method_46434(x,y+87,w,20).method_46431());
    }
    @Override public void method_25420(class_332 d,int mx,int my,float delta){}
    @Override public void method_25394(class_332 d,int mx,int my,float delta){
        d.method_25294(0,0,field_22789,field_22790,0xF00C1724);
        int middle=field_22789/2,top=Math.max(16,field_22790/2-121);
        d.method_25300(field_22793,BrickI18n.tr("BRICKCRAFT / EXPLORATION LEGO"),middle,top,0xFF79DFE9);
        d.method_25300(field_22793,BrickI18n.tr("Rejoins la taille d'une figurine ou domine les constructions"),middle,top+18,0xFFDEE9F4);
        d.method_25300(field_22793,BrickI18n.tr("x1 = joueur normal | x0,125 = minuscule | x4 = geant"),middle,top+33,0xFFBDCFDC);
        d.method_25300(field_22793,BrickI18n.tr("La hauteur de la camera, la hitbox et les collisions sont synchronisees."),
                middle,Math.min(field_22790-26,field_22790/2+63),0xFFB1C6D3);
        super.method_25394(d,mx,my,delta);
    }
    @Override public void method_25419(){if(field_22787!=null)field_22787.method_1507(previous);}
}
