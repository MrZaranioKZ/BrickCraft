package fr.brickcraft.client;

import fr.brickcraft.client.WorldPiecePicker.Hit;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PreciseWorldEditPayload;
import fr.brickcraft.world.PreciseDisplayEntity;
import fr.brickcraft.world.PreciseWorldEditMath;
import fr.brickcraft.world.PreciseStudSnapper;
import fr.brickcraft.world.PreciseStudSnapper.ConnectorPoint;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;
import java.util.*;

/**
 * Direct-in-world manipulation. F4 toggles editor. The mouse ray selects ORIGINAL
 * oriented LEGO volumes rather than Minecraft blocks. Axis + wheel commits a small,
 * server-authorized LDU / matrix delta, persisted in the projection block entity.
 */
public final class PreciseWorldEditor {
    private PreciseWorldEditor(){}
    private static boolean enabled,rotation,snapEnabled,showConnectors;
    private static boolean dragging,dragRotation,haveCursor;
    private static int dragAxis;
    private static double dragRaw,dragAmount,lastX,lastY,dragDistance;
    private static double[] dragFacing;
    private static int axis=0,index=-1;
    private static class_2338 anchor;
    private static String status="";
    public static boolean enabled(){return enabled;}
    public static void tick(class_310 client){
        if(dragging&&(client.field_1724==null||client.field_1687==null||client.field_1755!=null))clearDrag();
    }
    private static void clearDrag(){dragging=false;haveCursor=false;dragRaw=dragAmount=0;dragFacing=null;}
    public static void reset(){clearDrag();enabled=false;index=-1;anchor=null;rotation=false;snapEnabled=false;showConnectors=false;status="";}
    public static boolean toggle(class_310 client){
        clearDrag();enabled=!enabled;index=-1;anchor=null;rotation=false;axis=0;
        status=enabled?BrickI18n.tr("Clic gauche : choisir une piece LEGO. F4 : quitter."):"";
        if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr(enabled?"BrickCraft : edition en monde ACTIVE":"BrickCraft : edition en monde DESACTIVEE")),true);
        return enabled;
    }
    private static PreciseDisplayEntity selected(class_310 client){
        if(anchor==null||index<0||client.field_1687==null)return null;
        if(!(client.field_1687.method_8321(anchor) instanceof PreciseDisplayEntity be))return null;
        return be.model()!=null&&index<be.model().parts().size()?be:null;
    }
    private static double[] bounds(String part){
        String mapped=PreciseReferenceMapper.geometryId(part);
        return mapped==null?null:LDrawLibrary.originalBounds(mapped);
    }
    private record Selection(class_2338 anchor,WorldPiecePicker.Hit hit){}
    public static boolean attack(class_310 client){
        if(dragging)return true;
        if(!enabled||client.field_1755!=null||client.field_1724==null||client.field_1687==null)return false;
        class_243 from=client.field_1724.method_33571(),dir=client.field_1724.method_5828(1.0f);
        ArrayList<Selection> hits=new ArrayList<>();
        for(PreciseDisplayEntity be:PreciseDisplayRenderer.activeProjections(client.field_1687)){
            var model=be.model();if(model==null)continue;
            class_2338 a=be.method_11016();
            for(var hit:WorldPiecePicker.hits(model.parts(),model.minX(),model.minY(),model.minZ(),
                    a.method_10263(),a.method_10264(),a.method_10260(),from.field_1352,from.field_1351,from.field_1350,dir.field_1352,dir.field_1351,dir.field_1350,12.0,
                    PreciseWorldEditor::bounds))hits.add(new Selection(a,hit));
        }
        hits.sort(Comparator.comparingDouble(s->s.hit().distance()));
        if(hits.isEmpty()){
            index=-1;anchor=null;status="Aucune piece sous le viseur (portee : 12 blocs).";
        }else{
            int found=0;
            if(client.field_1724.method_5715()&&anchor!=null){
                for(int i=0;i<hits.size();i++)if(anchor.equals(hits.get(i).anchor()) && index==hits.get(i).hit().index()){
                    found=(i+1)%hits.size();break;
                }
            }
            Selection chosen=hits.get(found);
            index=chosen.hit().index();anchor=chosen.anchor();
            PreciseDisplayEntity be=selected(client);
            status=BrickI18n.fmt("brickcraft.v241.world.part",index+1,be==null?"?":be.model().parts().get(index).partId());
        }
        return true; // Cancel vanilla punching / breaking while editing a virtual assembly.
    }
    /** N toggles intelligent mating only while F4 world editing is enabled. */
    public static boolean toggleSnap(){
        if(!enabled)return false;
        if(dragging)return true;
        snapEnabled=!snapEnabled;
        status=snapEnabled?"Aimant ON : les deplacements essaient un tenon compatible.":
                           "Aimant OFF : placement totalement libre.";
        return true;
    }
    /** B requests a server-authoritative snap of the currently selected brick. */
    public static boolean snapNow(){
        if(!enabled)return false;
        if(dragging)return true;
        send(PreciseWorldEditMath.SNAP_NOW,0);
        return true;
    }
    public static boolean modeKey(boolean rotate){
        if(!enabled)return false;if(dragging)return true;rotation=rotate;
        status=rotate?"Rotation : choisis X/Y/Z, puis molette.":"Deplacement : choisis X/Y/Z, puis molette.";
        return true;
    }
    public static boolean chooseAxis(int next){
        if(!enabled)return false;if(dragging)return true;axis=next;
        status=BrickI18n.fmt("brickcraft.v241.world.axis","XYZ".charAt(axis),BrickI18n.tr(rotation?"rotation":"deplacement"));return true;
    }
    public static boolean resetRotation(){
        if(!enabled)return false;if(dragging)return true;
        send(PreciseWorldEditMath.RESET,0);return true;
    }
    public static boolean undo(){if(!enabled)return false;if(dragging)return true;send(PreciseWorldEditMath.UNDO,0);return true;}
    private static void send(byte operation,double amount){
        class_310 client=class_310.method_1551();
        if(client.field_1724==null||client.field_1755!=null)return;
        PreciseDisplayEntity be=selected(client);
        if(be==null){status="Selectionne d'abord une piece (clic gauche).";return;}
        if(!client.field_1724.method_7337()){status="Mode Creatif requis pour modifier le monde.";return;}
        ClientPlayNetworking.send(new PreciseWorldEditPayload(anchor,index,operation,(byte)axis,amount));
        status=BrickI18n.fmt("brickcraft.v241.world.operation",index+1,
                BrickI18n.tr(operation==PreciseWorldEditMath.SNAP_NOW?"recherche d'attache...":
                operation==PreciseWorldEditMath.MOVE_WITH_SNAP?"deplacement + aimant":
                operation==PreciseWorldEditMath.MOVE?"deplacement":"rotation"),
                "XYZ".charAt(axis),operation==PreciseWorldEditMath.RESET?BrickI18n.tr("reset"):amount);
    }
    public static boolean scroll(double vertical){
        if(!enabled)return false;
        class_310 client=class_310.method_1551();
        if(client.field_1755!=null||client.field_1724==null)return false;
        if(vertical==0||dragging)return true;
        boolean fine=client.field_1724.method_5715();
        double step=rotation?(fine?1:15):(fine?1:20);
        send(rotation?PreciseWorldEditMath.ROTATE:
                (snapEnabled?PreciseWorldEditMath.MOVE_WITH_SNAP:PreciseWorldEditMath.MOVE),
                Math.signum(vertical)*step);
        return true; // Prevent hotbar scrolling while the world editor is active.
    }
    /** K: connector markers are OFF by default. Only the selected known part is inspected. */
    public static boolean toggleConnectors(){
        if(!enabled)return false;
        showConnectors=!showConnectors;
        status=BrickI18n.fmt("brickcraft.v241.world.connectors",BrickI18n.tr(showConnectors?"VISIBLES":"MASQUES"));
        return true;
    }
    private static double[] originWorld(PreciseDisplayEntity be,
              fr.brickcraft.importer.LDrawProjectReader.Instance p){
        PreciseWorldModel model=be.model();class_2338 a=be.method_11016();
        return new double[]{a.method_10263()+p.x()/20-model.minX(),
                a.method_10264()-p.y()/20-model.minY(),a.method_10260()+p.z()/20-model.minZ()};
    }
    /** Handle hit-testing is independent of the 3,245 meshes of an imported castle.
     * Return true ONLY when the handle is actually hit, leaving ordinary block selection intact.
     */
    public static boolean mouseButton(int button,int action){
        if(!enabled||button!=0)return false;
        class_310 client=class_310.method_1551();
        if(action==0&&dragging){
            double finalAmount=dragAmount;
            boolean rotate=dragRotation;
            int targetAxis=dragAxis;
            clearDrag();
            axis=targetAxis;rotation=rotate;
            if(finalAmount!=0)send(rotate?PreciseWorldEditMath.ROTATE:
                    (snapEnabled?PreciseWorldEditMath.MOVE_WITH_SNAP:PreciseWorldEditMath.MOVE),finalAmount);
            else status="Glissement annule (aucune modification).";
            return true;
        }
        if(action!=1||dragging||client.field_1755!=null||client.field_1724==null||
                client.field_1687==null||!client.field_1724.method_7337()||client.field_1724.method_5715())return false;
        PreciseDisplayEntity be=selected(client);if(be==null)return false;
        var p=be.model().parts().get(index);
        class_243 eye=client.field_1724.method_33571(),facing=client.field_1724.method_5828(1.0f);
        double[] center=originWorld(be,p);
        var hit=WorldGizmoMath.pick(new double[]{eye.field_1352,eye.field_1351,eye.field_1350},
                 new double[]{facing.field_1352,facing.field_1351,facing.field_1350},center,12.0,0.16);
        if(hit==null)return false;
        dragAxis=hit.axis();axis=dragAxis;dragRotation=rotation;
        dragDistance=Math.sqrt(Math.pow(center[0]-eye.field_1352,2)+Math.pow(center[1]-eye.field_1351,2)+Math.pow(center[2]-eye.field_1350,2));
        dragFacing=new double[]{facing.field_1352,facing.field_1351,facing.field_1350};
        dragRaw=dragAmount=0;haveCursor=false;dragging=true;
        status="Poignee "+"XYZ".charAt(axis)+" : maintiens et glisse, relache pour enregistrer.";
        return true;
    }
    /** Called before vanilla mouse-look, preventing camera rotation while dragging. */
    public static boolean mouseMove(double x,double y){
        if(!dragging)return false;
        if(!haveCursor){lastX=x;lastY=y;haveCursor=true;return true;}
        double dx=x-lastX,dy=y-lastY;lastX=x;lastY=y;
        if(Math.abs(dx)+Math.abs(dy)>500)return true; // Unexpected capture / focus jump.
        class_310 client=class_310.method_1551();
        boolean fine=client.field_1724!=null&&client.field_1724.method_5715();
        dragRaw+=dragRotation?(dx-dy)*0.65:
                WorldGizmoMath.dragLdu(dx,dy,dragFacing,dragAxis,dragDistance);
        dragAmount=WorldGizmoMath.step(dragRaw,dragRotation?(fine?1:5):(fine?1:5),dragRotation?180:80);
        return true;
    }
    private static fr.brickcraft.importer.LDrawProjectReader.Instance dragPreview(
            fr.brickcraft.importer.LDrawProjectReader.Instance p){
        if(!dragging||dragAmount==0)return p;
        try{return PreciseWorldEditMath.apply(p,dragRotation?PreciseWorldEditMath.ROTATE:
                PreciseWorldEditMath.MOVE,dragAxis,dragAmount);}
        catch(IllegalArgumentException ex){return p;}
    }
    public static void renderHud(class_332 d,class_310 client){
        if(!enabled||client.field_1724==null||client.field_1755!=null)return;
        int height=d.method_51443(),width=d.method_51421();
        int py=Math.max(8,height-70),px=8;
        String one=BrickI18n.fmt("brickcraft.v241.hud.title",
                BrickI18n.tr(rotation?"ROTATION":"DEPLACEMENT"),"XYZ".charAt(axis),
                snapEnabled?"ON":"OFF");
        String two=BrickI18n.tr("Clic : selection | Poignees : glisser | G/R : mode | X/Y/Z : axe");
        String three=dragging?BrickI18n.fmt("brickcraft.v241.hud.drag", "XYZ".charAt(dragAxis),
                dragAmount,dragRotation?"°":"LDU"):
                BrickI18n.tr("Molette : avancer | K : tenons | N : aimant | B : connecter");
        String selected=anchor==null?status:"#"+(index+1)+" @ "+anchor.method_23854()+" | "+status;
        String[] lines={one,two,three,BrickI18n.tr(selected)};
        int maxWidth=Math.max(80,width-22),textWidth=0;
        for(int i=0;i<lines.length;i++){
            lines[i]=client.field_1772.method_27523(lines[i],maxWidth);
            textWidth=Math.max(textWidth,client.field_1772.method_1727(lines[i]));
        }
        int w=Math.min(maxWidth,textWidth+10);
        d.method_25294(px-4,py-4,px+w,py+49,0xDD0A2534);
        for(int i=0;i<lines.length;i++)
            d.method_25303(client.field_1772,lines[i],px,py+i*12,
                    i==0?0xFF5CE3DF:i==2?0xFFEDC98E:0xFFDBF4FA);
    }
    /** Selection outline in world coordinates, including rotations. No 3D mesh allocations. */
    public static void initOverlay(){
        WorldRenderEvents.AFTER_ENTITIES.register(context->{
            if(!enabled)return;
            class_310 client=class_310.method_1551();
            PreciseDisplayEntity be=selected(client);
            if(be==null||context.consumers()==null||context.matrixStack()==null)return;
            PreciseWorldModel model=be.model();
            var initial=model.parts().get(index);
            var p=dragPreview(initial);double[] b=bounds(p.partId());if(b==null)return;
            class_2338 a=be.method_11016();
            double[][] corners=WorldPiecePicker.corners(p,b,model.minX(),model.minY(),model.minZ(),
                    a.method_10263(),a.method_10264(),a.method_10260());
            class_4587 matrices=context.matrixStack();class_243 cam=context.camera().method_19326();
            matrices.method_22903();matrices.method_22904(-cam.field_1352,-cam.field_1351,-cam.field_1350);
            class_4588 lines=context.consumers().getBuffer(class_1921.method_23594());
            for(int i=0;i<8;i++)for(int bit:new int[]{1,2,4})if((i&bit)==0)
                line(lines,matrices,corners[i],corners[i|bit],0xFFF7D67B);
            // LDraw X/Z positive world axes, LDraw Y positive points down in Minecraft.
            double[] center=originWorld(be,p);
            double ox=center[0],oy=center[1],oz=center[2];
            line(lines,matrices,center,new double[]{ox+1.2,oy,oz},0xFFFF6666);
            line(lines,matrices,center,new double[]{ox,oy+1.2,oz},0xFF77FFAA);
            line(lines,matrices,center,new double[]{ox,oy,oz+1.2},0xFF66BFFF);
            if(showConnectors){
                // Minimal GPU cost: at most 96 crosshair markers, no solid meshes or allocations per part.
                for(var pt:PreciseStudSnapper.connectorPoints(p,96)){
                    double x=a.method_10263()+pt.x()/20-model.minX();
                    double y=a.method_10264()-pt.y()/20-model.minY();
                    double z=a.method_10260()+pt.z()/20-model.minZ();
                    int color=pt.top()?0xFF63F4A9:0xFF74B6FF;
                    double size=0.09;
                    line(lines,matrices,new double[]{x-size,y,z},new double[]{x+size,y,z},color);
                    line(lines,matrices,new double[]{x,y-size,z},new double[]{x,y+size,z},color);
                    line(lines,matrices,new double[]{x,y,z-size},new double[]{x,y,z+size},color);
                }
            }
            matrices.method_22909();
        });
    }
    private static void line(class_4588 lines,class_4587 stack,double[] a,double[] b,int c){
        var m=stack.method_23760().method_23761();
        lines.method_22918(m,(float)a[0],(float)a[1],(float)a[2]).method_39415(c).method_22914(0,1,0);
        lines.method_22918(m,(float)b[0],(float)b[1],(float)b[2]).method_39415(c).method_22914(0,1,0);
    }
}
