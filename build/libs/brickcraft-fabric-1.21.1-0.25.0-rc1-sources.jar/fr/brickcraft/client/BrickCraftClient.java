package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.BrickPartStacks;
import fr.brickcraft.world.BrickPartItem;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import fr.brickcraft.net.BrickEditPayload;
import fr.brickcraft.net.StudioExportStatusPayload;
import fr.brickcraft.net.PreciseManageStatusPayload;
import fr.brickcraft.world.BrickCellEntity;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public final class BrickCraftClient implements ClientModInitializer {
    private static class_304 studioKey,nextKey,turnKey,colorKey,quickKey,stepKey,pitchKey,rollKey,resetKey,inspectKey,gpuHideKey,gpuInfoKey,gpuLegacyKey,gpuCullingKey,gpuViewKey,worldModeKey,qualityKey,yAxisKey,connectorsKey,guideKey,guidePreviousKey,guideNextKey,playerScaleKey;
    private static boolean inspectVisible=false;
    private static boolean prevCopy=false,prevPaste=false,prevUndo=false,prevRedo=false;
    private static class_1792 previousHand=null;
    private static int previousSlot=-1;
    private static BrickPiece clipboard=null;

    private static BrickKind activeKind(class_310 client){
        if(BrickSelection.sampled)return BrickSelection.kind;
        if(client.field_1724!=null && client.field_1724.method_6047().method_7909() instanceof BrickPartItem item)
            return item.kind();
        return BrickSelection.kind;
    }

    /** Called before vanilla Pick Block, so Minecraft won't replace our sampled color and part. */
    public static boolean pickBrick(class_310 client){
        if(client.field_1724==null || client.field_1687==null ||
                !(client.field_1765 instanceof class_3965 hit) ||
                !(client.field_1687.method_8321(hit.method_17777()) instanceof BrickCellEntity cell))return false;
        BrickPiece piece=cell.pickAt(hit.method_17784().field_1351,hit.method_17780()==net.minecraft.class_2350.field_11036);
        if(piece==null)return false;
        BrickSelection.sample(piece); clipboard=piece;
        if(client.field_1761!=null && client.field_1761.method_2914()){
            // Give the matching item in the active hotbar slot. Keep the sampled RGB in selection.
            // Missing-library parts may still be present in old saves. Never crash Pick Block.
            class_1799 stack=piece.kind()==BrickKind.LDRAW_PART
                    ?(LDrawLibrary.contains(piece.partId())
                        ?BrickPartStacks.ldraw(piece.partId(),1)
                        :new class_1799(BrickCraft.TOOL))
                    :new class_1799(BrickCraft.PART_ITEMS.get(piece.kind()));
            int slot=client.field_1724.method_31548().field_7545;
            client.field_1724.method_31548().method_5447(slot,stack);
            client.field_1761.method_2909(stack,36+slot);
            previousHand=stack.method_7909();previousSlot=slot;
        }
        client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.pick",BrickI18n.tr(piece.name()),
                BrickI18n.tr(BrickSelection.colorName()),piece.angle())),true);
        return true;
    }

    private static void pasteAtCrosshair(class_310 client){
        if(client.field_1724==null || client.field_1687==null || clipboard==null ||
                !(client.field_1765 instanceof class_3965 hit))return;
        class_1792 held=client.field_1724.method_6047().method_7909();
        if(held!=BrickCraft.TOOL && !(held instanceof BrickPartItem) && held!=BrickCraft.LDRAW_ITEM)return;
        BrickSelection.sample(clipboard);
        ClientPlayNetworking.send(new BrickActionPayload(hit.method_17777(),hit.method_17780(),
                (float)(hit.method_17784().field_1352-hit.method_17777().method_10263()),
                (float)(hit.method_17784().field_1351-hit.method_17777().method_10264()),
                (float)(hit.method_17784().field_1350-hit.method_17777().method_10260()),false,false,
                BrickSelection.oriented(clipboard.kind(),0,0,0)));
    }

    private static boolean keyDown(class_310 client,int key){
        return class_3675.method_15987(client.method_22683().method_4490(),key);
    }


    @Override public void onInitializeClient() {
        ClientPlayNetworking.registerGlobalReceiver(StudioExportStatusPayload.ID,
                (packet,context)->context.client().execute(()->BrickStudioScreen.receiveExportStatus(packet)));
        ClientPlayNetworking.registerGlobalReceiver(PreciseManageStatusPayload.ID,
                (packet,context)->context.client().execute(()->{
                    if(packet.event()==PreciseManageStatusPayload.REMOVED && !packet.projects().isEmpty())
                        PreciseDisplayRenderer.releaseProjection(packet.projects().get(0).anchor());
                    if(context.client().field_1755 instanceof PreciseWorldProjectsScreen screen)
                        screen.receive(packet);
                }));

        BlockEntityRendererRegistry.register(BrickCraft.CELL_ENTITY, BrickCellRenderer::new);
        BlockEntityRendererRegistry.register(BrickCraft.PRECISE_ENTITY, PreciseDisplayRenderer::new);
        net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents.DISCONNECT.register(
                (handler,client)->{
                    PreciseDisplayRenderer.clearGpuOnDisconnect();PreciseWorldEditor.reset();BrickGuideController.reset();
                });
        PreciseWorldEditor.initOverlay();
        worldModeKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.world_edit",class_3675.class_307.field_1668,GLFW.GLFW_KEY_F4,"category.brickcraft"));
        guideKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.guide",class_3675.class_307.field_1668,GLFW.GLFW_KEY_J,"category.brickcraft"));
        guidePreviousKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.guide_previous",class_3675.class_307.field_1668,GLFW.GLFW_KEY_PAGE_UP,"category.brickcraft"));
        guideNextKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.guide_next",class_3675.class_307.field_1668,GLFW.GLFW_KEY_PAGE_DOWN,"category.brickcraft"));
        connectorsKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.world_connectors",class_3675.class_307.field_1668,GLFW.GLFW_KEY_K,"category.brickcraft"));
        playerScaleKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.player_scale",class_3675.class_307.field_1668,GLFW.GLFW_KEY_U,"category.brickcraft"));
        qualityKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.mesh_quality",class_3675.class_307.field_1668,GLFW.GLFW_KEY_P,"category.brickcraft"));
        yAxisKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.world_y_axis",class_3675.class_307.field_1668,GLFW.GLFW_KEY_Y,"category.brickcraft"));
        gpuHideKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.gpu_hide",class_3675.class_307.field_1668,GLFW.GLFW_KEY_F8,"category.brickcraft"));
        gpuInfoKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.gpu_info",class_3675.class_307.field_1668,GLFW.GLFW_KEY_F9,"category.brickcraft"));
        gpuLegacyKey=KeyBindingHelper.registerKeyBinding(new class_304(
                "key.brickcraft.gpu_legacy",class_3675.class_307.field_1668,GLFW.GLFW_KEY_F6,"category.brickcraft"));
        // Experimental diagnostics are opt-in and should not clutter the normal Controls menu.
        // Set experimental_gpu_diagnostics=true in config/brickcraft/precise-render.properties.
        if(BrickGpuQualityConfig.experimentalDiagnostics(net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir())){
            gpuCullingKey=KeyBindingHelper.registerKeyBinding(new class_304(
                    "key.brickcraft.gpu_culling",class_3675.class_307.field_1668,GLFW.GLFW_KEY_F7,"category.brickcraft"));
            gpuViewKey=KeyBindingHelper.registerKeyBinding(new class_304(
                    "key.brickcraft.gpu_view",class_3675.class_307.field_1668,GLFW.GLFW_KEY_F10,"category.brickcraft"));
        }
        studioKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.studio",class_3675.class_307.field_1668,GLFW.GLFW_KEY_B,"category.brickcraft"));
        nextKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.next",class_3675.class_307.field_1668,GLFW.GLFW_KEY_V,"category.brickcraft"));
        turnKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.turn",class_3675.class_307.field_1668,GLFW.GLFW_KEY_R,"category.brickcraft"));

        quickKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.quick",class_3675.class_307.field_1668,GLFW.GLFW_KEY_N,"category.brickcraft"));
        stepKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.step",class_3675.class_307.field_1668,GLFW.GLFW_KEY_G,"category.brickcraft"));
        pitchKey=KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.pitch",class_3675.class_307.field_1668,GLFW.GLFW_KEY_X,"category.brickcraft"));
        rollKey=KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.roll",class_3675.class_307.field_1668,GLFW.GLFW_KEY_Z,"category.brickcraft"));
        resetKey=KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.reset",class_3675.class_307.field_1668,GLFW.GLFW_KEY_H,"category.brickcraft"));
        colorKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.color",class_3675.class_307.field_1668,GLFW.GLFW_KEY_C,"category.brickcraft"));

        inspectKey=KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.inspect",class_3675.class_307.field_1668,GLFW.GLFW_KEY_I,"category.brickcraft"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PreciseWorldEditor.tick(client);
            BrickGuideController.tick(client);
            if(client.field_1724!=null){
                class_1792 held=client.field_1724.method_6047().method_7909();
                int slot=client.field_1724.method_31548().field_7545;
                if(previousHand!=null && (previousHand!=held || (previousSlot>=0&&previousSlot!=slot)))
                    BrickSelection.sampled=false;
                previousHand=held;previousSlot=slot;
                // A /brickcraft give LDraw item carries its reference in custom data.
                // Selecting it updates the existing world builder without opening a menu.
                String bound=BrickPartStacks.boundLdrawId(client.field_1724.method_6047());
                if(bound!=null && (!bound.equalsIgnoreCase(BrickSelection.partId) ||
                        BrickSelection.kind!=BrickKind.LDRAW_PART)) {
                    BrickSelection.kind=BrickKind.LDRAW_PART;
                    BrickSelection.partId=bound;
                    BrickSelection.sampled=true;
                }
            }
            boolean ctrl=keyDown(client,GLFW.GLFW_KEY_LEFT_CONTROL)||keyDown(client,GLFW.GLFW_KEY_RIGHT_CONTROL);
            boolean copy=ctrl&&keyDown(client,GLFW.GLFW_KEY_C);
            boolean paste=ctrl&&keyDown(client,GLFW.GLFW_KEY_V);
            boolean shift=keyDown(client,GLFW.GLFW_KEY_LEFT_SHIFT)||keyDown(client,GLFW.GLFW_KEY_RIGHT_SHIFT);
            boolean undo=ctrl&&keyDown(client,GLFW.GLFW_KEY_Z)&&!shift;
            boolean redo=ctrl&&(keyDown(client,GLFW.GLFW_KEY_Y)||
                   (keyDown(client,GLFW.GLFW_KEY_Z)&&shift));
            if(client.field_1755==null && client.field_1724!=null){
                if(copy&&!prevCopy)pickBrick(client);
                if(paste&&!prevPaste)pasteAtCrosshair(client);
                if(undo&&!prevUndo && !PreciseWorldEditor.undo())ClientPlayNetworking.send(new BrickEditPayload(false));
                if(redo&&!prevRedo && !PreciseWorldEditor.enabled())ClientPlayNetworking.send(new BrickEditPayload(true));
            }
            prevCopy=copy;prevPaste=paste;prevUndo=undo;prevRedo=redo;
            while(guideKey.method_1436())if(client.field_1755==null && client.field_1724!=null)
                client.method_1507(new BrickGuideScreen());
            while(guidePreviousKey.method_1436())if(client.field_1755==null)
                BrickGuideController.advance(-1);
            while(guideNextKey.method_1436())if(client.field_1755==null)
                BrickGuideController.advance(1);
            while(worldModeKey.method_1436())if(client.field_1755==null&&client.field_1724!=null)
                PreciseWorldEditor.toggle(client);
            while(playerScaleKey.method_1436())if(client.field_1755==null&&client.field_1724!=null)
                client.method_1507(new BrickPlayerScaleScreen(null));
            while(qualityKey.method_1436())if(client.field_1755==null&&client.field_1724!=null)
                client.method_1507(new BrickGpuQualityScreen(null));
            while(connectorsKey.method_1436())if(client.field_1755==null)
                PreciseWorldEditor.toggleConnectors();
            while(yAxisKey.method_1436())if(client.field_1755==null && !ctrl)
                PreciseWorldEditor.chooseAxis(1);
            while(gpuHideKey.method_1436())if(client.field_1755==null){
                PreciseDisplayRenderer.toggleVisibility();
                if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr(PreciseDisplayRenderer.projectionVisible()?"BrickCraft : projection VISIBLE":
                        "BrickCraft : projection MASQUEE (test FPS)")),true);
            }
            while(gpuInfoKey.method_1436())if(client.field_1755==null)PreciseDisplayRenderer.toggleStatistics();
            while(gpuLegacyKey.method_1436())if(client.field_1755==null){
                boolean legacy=PreciseDisplayRenderer.toggleLegacyMode();
                if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr(legacy?"BrickCraft : LEGACY, lent mais reference":"BrickCraft : GPU, lots persistants")),true);
            }
            while(gpuCullingKey!=null && gpuCullingKey.method_1436())if(client.field_1755==null && client.field_1724!=null)
                client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr("BrickCraft : "+PreciseDisplayRenderer.toggleGpuCulling())),true);
            while(gpuViewKey!=null && gpuViewKey.method_1436())if(client.field_1755==null && client.field_1724!=null)
                client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr("BrickCraft : "+PreciseDisplayRenderer.toggleGpuCameraMatrix())),true);
            while(inspectKey.method_1436()) if(client.field_1755==null && client.field_1724!=null){
                inspectVisible=!inspectVisible;
                client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr(inspectVisible?"BrickCraft : inspecteur active (I pour masquer)":
                    "BrickCraft : inspecteur masque")),true);
            }
            while (studioKey.method_1436()) {
                if (client.field_1724 != null && client.field_1755 == null){
                    if(PreciseWorldEditor.snapNow())continue;
                    client.method_1507(new BrickStudioScreen(resolveTarget(client)));
                }
            }
            while (quickKey.method_1436()) if (client.field_1755==null && client.field_1724!=null){
                if(PreciseWorldEditor.toggleSnap())continue;
                client.method_1507(new BrickQuickScreen());
            }
            while (stepKey.method_1436()) if (client.field_1755==null) {
                if(PreciseWorldEditor.modeKey(false))continue;
                BrickSelection.cycleStep();
                if(client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.rotation_step",BrickSelection.step())),true);
            }
            while (pitchKey.method_1436()) if(client.field_1755==null){
                if(PreciseWorldEditor.chooseAxis(0))continue;
                BrickSelection.rotatePitch(1);
                if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.axis_x",BrickSelection.pitch)),true);
            }
            while (rollKey.method_1436()) if(client.field_1755==null && !ctrl){
                if(PreciseWorldEditor.chooseAxis(2))continue;
                BrickSelection.rotateRoll(1);
                if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.axis_z",BrickSelection.roll)),true);
            }
            while (resetKey.method_1436()) if(client.field_1755==null){
                if(PreciseWorldEditor.resetRotation())continue;
                BrickSelection.resetRotation();
                if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(BrickI18n.tr("BrickCraft : rotation reinitialisee")),true);
            }
            while (nextKey.method_1436()) if (client.field_1755==null && !ctrl) {
                BrickSelection.nextKind();
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.selection",BrickI18n.tr(BrickSelection.selectedName()))),true);
            }
            while (colorKey.method_1436()) if (client.field_1755==null && !ctrl) {
                BrickSelection.nextColor();
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.color",BrickI18n.tr(BrickSelection.colorName()))),true);
            }
            while (turnKey.method_1436()) if (client.field_1755==null) {
                if(PreciseWorldEditor.modeKey(true))continue;
                BrickSelection.rotate(client.field_1724!=null && client.field_1724.method_5715() ? -1 : 1);
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(BrickI18n.fmt("brickcraft.v241.notice.rotation",BrickSelection.angle,BrickSelection.step())),true);
            }
        });
        HudRenderCallback.EVENT.register((draw,tick) -> {
            class_310 client=class_310.method_1551();
            if(client.field_1724==null || client.field_1755!=null || client.field_1690.field_1842) return;
            boolean active=client.field_1724.method_6047().method_31574(BrickCraft.TOOL)
                    || client.field_1724.method_6047().method_7909() instanceof BrickPartItem
                    || client.field_1724.method_6047().method_31574(BrickCraft.LDRAW_ITEM);
            if(inspectVisible && !PreciseWorldEditor.enabled()) renderInspector(client,draw);
            BrickGuideController.hud(client,draw);
            PreciseWorldEditor.renderHud(draw,client);
            String gpuStats=PreciseDisplayRenderer.statistics();
            if(gpuStats!=null){
                int px=5,py=5;
                String[] lines=gpuStats.split("\n");
                int width=0;
                for(int i=0;i<lines.length;i++){
                    lines[i]=client.field_1772.method_27523(BrickI18n.tr(lines[i]),Math.max(20,draw.method_51421()-20));
                    width=Math.max(width,client.field_1772.method_1727(lines[i]));
                }
                draw.method_25294(px-2,py-2,Math.min(draw.method_51421()-5,
                        px+width+8),py+lines.length*11+3,0xCB081C2D);
                for(int line=0;line<lines.length;line++)
                    draw.method_25303(client.field_1772,lines[line],px,py+line*11,0xFF7ED9E0);
            }
            if(!active || PreciseWorldEditor.enabled())return;
            BrickKind kind=activeKind(client);
            int x=6,y=draw.method_51443()-76;
            int w=Math.max(170,client.field_1772.method_1727(BrickSelection.selectedName())+22);
            draw.method_25294(x-3,y-3,x+w+3,y+48,0xB5102230);
            draw.method_25294(x,y+3,x+8,y+15,0xFF000000|BrickSelection.rgb);
            draw.method_25303(client.field_1772,BrickI18n.tr(BrickSelection.selectedName()),x+13,y+4,0xFFEAF6FF);
            draw.method_25303(client.field_1772,BrickI18n.fmt("brickcraft.v241.hud.color",BrickI18n.tr(BrickSelection.colorName()),
                            BrickSelection.angle,BrickSelection.pitch,BrickSelection.roll),
                    x+3,y+20,0xFFF2DDA1);
            draw.method_25303(client.field_1772,BrickI18n.tr("N: catalogue | I: inspecteur | G: pas | H: reset"),x+3,y+34,0xFF99C0D1);
        });
        BrickGuideTargetOverlay.init();
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if(world.field_9236 && PreciseWorldEditor.enabled())return class_1269.field_5812;
            if (hand!=class_1268.field_5808 || !(player.method_5998(hand).method_31574(BrickCraft.TOOL) ||
                    player.method_5998(hand).method_7909() instanceof BrickPartItem ||
                    player.method_5998(hand).method_31574(BrickCraft.LDRAW_ITEM)))
                return class_1269.field_5811;
            if (world.field_9236) {
                BrickKind kind=activeKind(class_310.method_1551());
                String bound=BrickPartStacks.boundLdrawId(player.method_5998(hand));
                // The wand follows the palette. A /brickcraft give item uses its bound ID.
                if(player.method_5998(hand).method_31574(BrickCraft.LDRAW_ITEM) && bound==null)
                    return class_1269.field_5811;
                if(bound!=null){BrickSelection.kind=BrickKind.LDRAW_PART;BrickSelection.partId=bound;
                    BrickSelection.sampled=false;kind=BrickKind.LDRAW_PART;}
                BrickPiece selection=BrickSelection.oriented(kind,0,0,0);
                ClientPlayNetworking.send(new BrickActionPayload(
                    hit.method_17777(),hit.method_17780(),
                    (float)(hit.method_17784().field_1352-hit.method_17777().method_10263()),
                    (float)(hit.method_17784().field_1351-hit.method_17777().method_10264()),
                    (float)(hit.method_17784().field_1350-hit.method_17777().method_10260()),
                    player.method_5715(),false,selection));
            }
            return class_1269.field_5812;
        });
    }

    /** Inspector is completely absent until the player presses I. */
    private static void renderInspector(class_310 client,net.minecraft.class_332 draw){
        int right=draw.method_51421()-8;
        int top=9;
        int panelWidth=Math.min(245,Math.max(155,draw.method_51421()/3));
        int left=right-panelWidth;
        BrickPiece part=null;
        if(client.field_1765 instanceof class_3965 hit && client.field_1687!=null &&
                client.field_1687.method_8321(hit.method_17777()) instanceof BrickCellEntity cell){
            part=cell.pickAt(hit.method_17784().field_1351,hit.method_17780()==net.minecraft.class_2350.field_11036);
        }
        int rows=part==null?3:8;
        draw.method_25294(left-5,top-5,right+4,top+rows*13+13,0xDA0C1825);
        draw.method_25294(left-5,top-5,right+4,top-3,0xFF58D1D7);
        draw.method_25303(client.field_1772,BrickI18n.tr("BRICKCRAFT  /  INSPECTEUR"),left,top,0xFFBDF7FF);
        if(part==null){
            draw.method_25303(client.field_1772,BrickI18n.tr("Vise une piece BrickCraft"),left,top+16,0xFFE3E9F2);
            draw.method_25303(client.field_1772,BrickI18n.tr("I : masquer"),left,top+29,0xFF93B5C9);
            return;
        }
        int i=1;
        draw.method_25303(client.field_1772,trim(client,BrickI18n.tr(part.name()),panelWidth),left,top+13*i++,0xFFFFFFFF);
        LDrawLibrary.Colour colour=LDrawLibrary.color(part.colorCode());
        String name=colour==null?"Couleur libre (RGB)":colour.displayName();
        draw.method_25303(client.field_1772,trim(client,BrickI18n.tr(name),panelWidth),left,top+13*i++,0xFFF6D49C);
        draw.method_25303(client.field_1772,BrickI18n.fmt("brickcraft.v241.inspector.ldraw",colour==null?BrickI18n.tr("aucun"):colour.code(),
                String.format("%06X",part.rgb())),left,top+13*i++,0xFFCBDCE6);
        String finish=colour==null?"OPAQUE":colour.finish();
        int alpha=colour==null?255:colour.alpha();
        draw.method_25303(client.field_1772,BrickI18n.fmt("brickcraft.v241.inspector.finish",BrickI18n.tr(finish)),left,top+13*i++,0xFFCBDCE6);
        draw.method_25303(client.field_1772,BrickI18n.fmt("brickcraft.v241.inspector.opacity",Math.round(alpha/255f*100)),left,top+13*i++,0xFFCBDCE6);
        draw.method_25303(client.field_1772,BrickI18n.tr("Y="+part.angle()+" X="+part.pitch()+" Z="+part.roll()),left,top+13*i++,0xFFCBDCE6);
        draw.method_25303(client.field_1772,BrickI18n.fmt("brickcraft.v241.inspector.size",part.width(),part.length(),
                String.format(java.util.Locale.ROOT,"%.1f",part.height()/5f)),left,top+13*i++,0xFFCBDCE6);
        draw.method_25303(client.field_1772,BrickI18n.tr("I : masquer"),left,top+13*i,0xFF93B5C9);
    }
    private static String trim(class_310 client,String value,int limit){
        if(client.field_1772.method_1727(value)<=limit)return value;
        while(value.length()>1 && client.field_1772.method_1727(value+"...")>limit)
            value=value.substring(0,value.length()-1);
        return value+"...";
    }

    public static class_2338 resolveTarget(class_310 client) {
        if (client.field_1687 == null || !(client.field_1765 instanceof class_3965 hit)) return null;
        // Studio origin is placed NEXT TO a targeted normal block, vanilla-style.
        // A new model can also start from the top of an existing LEGO cell.
        if (client.field_1687.method_8320(hit.method_17777()).method_27852(BrickCraft.CELL))
            return hit.method_17780().method_10166().method_10178()
                    ? hit.method_17777().method_10084() : hit.method_17777().method_10093(hit.method_17780());
        return hit.method_17777().method_10093(hit.method_17780());
    }
}
