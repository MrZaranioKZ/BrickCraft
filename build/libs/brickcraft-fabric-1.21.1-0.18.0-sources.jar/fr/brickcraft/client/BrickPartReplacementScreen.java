package fr.brickcraft.client;

import fr.brickcraft.importer.PartReplacementMatcher;
import fr.brickcraft.importer.PartReplacementMatcher.Candidate;
import fr.brickcraft.ldraw.LDrawLibrary;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Manual, confirmed replacement of ONE missing reference in the loaded LDraw project. */
public final class BrickPartReplacementScreen extends class_437 {
    private final BrickMissingPartsScreen previous;
    private final String sourceId;
    private final String sourceName;
    private final int occurrences;
    private final List<PartReplacementMatcher.Candidate> suggestions;
    private class_342 targetField;
    private int page;
    private String chosen="";
    private String status="Selectionne un equivalent, puis confirme. Les variantes peuvent etre differentes.";

    public BrickPartReplacementScreen(BrickMissingPartsScreen previous,String sourceId,String sourceName,int occurrences){
        super(class_2561.method_43470("BrickCraft - Remplacer une piece"));
        this.previous=previous;
        this.sourceId=PartReplacementMatcher.normalize(sourceId);
        this.sourceName=sourceName;
        this.occurrences=occurrences;
        // Installed library only; never propose a reference downloaded on speculation.
        var all=LDrawLibrary.search("",150_000).stream()
                .map(p->new PartReplacementMatcher.Available(p.id(),p.name())).toList();
        this.suggestions=PartReplacementMatcher.suggest(this.sourceId,all,24).stream()
                .filter(p->LDrawLibrary.originalBounds(p.id())!=null).toList();
    }
    private int rows(){return Math.max(1,Math.min(7,(field_22790-184)/26));}
    private void choose(String id){
        chosen=id;
        if(targetField!=null)targetField.method_1852(id);
        status="Cible : "+id+" | Verifie la geometrie avant de confirmer.";
    }
    private void apply(){
        String target=PartReplacementMatcher.normalize(targetField==null?chosen:targetField.method_1882());
        if(target.equals(sourceId)){status="La reference source et la cible sont identiques.";return;}
        if(!target.matches("[a-z0-9_-]{2,60}") || !LDrawLibrary.contains(target)){
            status="Reference non installee : "+target+". Recharge LDraw ou saisis un ID existant.";return;
        }
        if(LDrawLibrary.originalBounds(target)==null){
            status="Cette reference n'a aucune geometrie LDraw utilisable : "+target;return;
        }
        // Confirmation deliberately mandatory: close IDs are NOT evidence of equivalent geometry.
        field_22787.method_1507(new BrickConfirmScreen(this,"Remplacer "+sourceId+" par "+target+" ?",
                occurrences+" pieces modifiees. Positions/couleurs conservees. Le .io original restera intact.",()->{
                    int count=previous.replaceMissing(sourceId,target);
                    if(count>0){field_22787.method_1507(previous);}
                    else status="Aucune occurrence remplacee : retourne a la liste et actualise.";
                }));
    }
    private void add(int x,int y,int w,int h,String label,Runnable action){
        if(w<24||y<0||y+h>field_22790-23)return;
        method_37063(class_4185.method_46430(class_2561.method_43470(label),btn->action.run()).method_46434(x,y,w,h).method_46431());
    }
    @Override protected void method_25426(){
        int w=Math.min(610,field_22789-20),x=(field_22789-w)/2;
        int availableRows=rows();
        int maxPage=Math.max(0,(suggestions.size()-1)/availableRows);
        page=Math.min(page,maxPage);
        targetField=new class_342(field_22793,x+92,49,Math.max(60,w-224),20,class_2561.method_43470("Reference cible (.dat)"));
        targetField.method_1880(60);
        targetField.method_1852(chosen);
        targetField.method_1863(v->chosen=v);
        method_37063(targetField);
        add(x+w-122,49,122,20,"Remplacer",this::apply);
        for(int k=0;k<availableRows;k++){
            int i=page*availableRows+k;if(i>=suggestions.size())break;
            var item=suggestions.get(i);
            int y=87+k*26;
            add(x+w-95,y,95,20,"Choisir",()->choose(item.id()));
        }
        int y=field_22790-87;
        add(x,y,90,20,"< Page",()->{if(page>0){page--;method_41843();}});
        add(x+94,y,90,20,"Page >",()->{if((page+1)*rows()<suggestions.size()){page++;method_41843();}});
        add(x,y+28,w,22,"Retour aux pieces manquantes",this::method_25419);
    }
    private String cut(String s,int max){
        if(max<8)return "";
        while(field_22793.method_1727(s)>max&&s.length()>5)s=s.substring(0,s.length()-4)+"...";
        return s;
    }
    @Override public void method_25420(class_332 ctx,int mx,int my,float dt){}
    @Override public void method_25394(class_332 ctx,int mx,int my,float dt){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0A1420);
        int w=Math.min(610,field_22789-20),x=(field_22789-w)/2;
        ctx.method_25300(field_22793,"BRICKCRAFT / EQUIVALENTS LDRAW 0.18",field_22789/2,10,0xFF9DE5E5);
        ctx.method_25303(field_22793,cut(sourceId+"  x"+occurrences+" | "+sourceName,w-6),x,29,0xFFFFD19D);
        ctx.method_25303(field_22793,"Cible :",x,55,0xFFD5E7F2);
        for(int k=0;k<rows();k++){
            int i=page*rows()+k;if(i>=suggestions.size())break;
            var item=suggestions.get(i);int yy=90+k*26;
            ctx.method_25294(x,yy-5,x+w,yy+20,i%2==0?0xFF162737:0xFF101E2C);
            ctx.method_25303(field_22793,cut(item.id()+" | "+item.name()+" ("+item.reason()+")",w-106),x+5,yy,0xFFD4E9EF);
        }
        if(suggestions.isEmpty())ctx.method_25303(field_22793,"Aucune variante proche trouvee : saisis un ID installe manuellement.",x,98,0xFFE3BD88);
        ctx.method_25303(field_22793,cut("Suggestions : "+suggestions.size()+" - variantes non garanties interchangeables",w),x,72,0xFF93B1C7);
        ctx.method_25303(field_22793,cut(status,field_22789-18),10,field_22790-15,0xFFFFD19D);
        super.method_25394(ctx,mx,my,dt);
    }
    @Override public boolean method_25404(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ENTER){apply();return true;}
        return super.method_25404(key,scan,mods);
    }
    @Override public void method_25419(){field_22787.method_1507(previous);}
}
