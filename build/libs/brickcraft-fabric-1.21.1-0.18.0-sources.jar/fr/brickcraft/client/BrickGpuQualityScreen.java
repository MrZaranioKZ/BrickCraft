package fr.brickcraft.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Adjustable LDraw mesh-detail budget; rebuild GPU buffers once when confirmed. */
public final class BrickGpuQualityScreen extends class_437 {
    private final class_437 previous;
    private int chosen;
    public BrickGpuQualityScreen(class_437 previous){
        super(class_2561.method_43470("BrickCraft - Qualite geometrie"));
        this.previous=previous;chosen=PreciseDisplayRenderer.gpuQualityPercent();
    }
    @Override protected void method_25426(){
        int w=Math.min(350,field_22789-30),x=(field_22789-w)/2,y=Math.max(55,field_22790/2-75);
        method_37063(new class_357(x,y,w,20,class_2561.method_43473(),chosen/100.0){
            @Override protected void method_25346(){
                chosen=(int)Math.round(field_22753*100);
                method_25355(class_2561.method_43470("Triangles / detail : "+chosen+" %"));
            }
            @Override protected void method_25344(){chosen=(int)Math.round(field_22753*100);}
        });
        method_37063(class_4185.method_46430(class_2561.method_43470("Appliquer et reconstruire les lots GPU"),b->{
            try{
                BrickGpuQualityConfig.save(FabricLoader.getInstance().getConfigDir(),chosen);
                PreciseDisplayRenderer.changeGpuQuality(chosen);
                method_25419();
            }catch(java.io.IOException ex){
                if(field_22787!=null&&field_22787.field_1724!=null)field_22787.field_1724.method_7353(
                        class_2561.method_43470("BrickCraft : sauvegarde qualite impossible : "+ex.getMessage()),false);
            }
        }).method_46434(x,y+32,w,20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Recalculer l'eclairage des LEGO"),b->{
            PreciseDisplayRenderer.refreshWorldLighting();
            if(field_22787!=null && field_22787.field_1724!=null)field_22787.field_1724.method_7353(
                    class_2561.method_43470("BrickCraft : eclairage actualise progressivement."),true);
            method_25419();
        }).method_46434(x,y+58,w,20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Capacites / grands sets"),b->field_22787.method_1507(new BrickCapacityScreen(this)))
                .method_46434(x,y+85,w,20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Annuler"),b->method_25419())
                .method_46434(x,y+111,w,20).method_46431());
    }
    @Override public void method_25420(class_332 context,int mouseX,int mouseY,float delta){}
    @Override public void method_25394(class_332 d,int mx,int my,float delta){
        d.method_25294(0,0,field_22789,field_22790,0xF00B111A);
        d.method_25300(field_22793,"BRICKCRAFT / DETAIL 3D 0.18.0",field_22789/2,
                Math.max(15,field_22790/2-115),0xFF8CE5E6);
        d.method_25300(field_22793,"0% = maillage tres simplifie | 100% = triangles LDraw originaux",
                field_22789/2,Math.max(35,field_22790/2-95),0xFFE7CF9E);
        d.method_25300(field_22793,"Les tenons retrouvent leurs courbes a 100% (cout GPU plus eleve).",
                field_22789/2,Math.max(48,field_22790/2-80),0xFFBDD4E5);
        super.method_25394(d,mx,my,delta);
    }
    @Override public void method_25419(){if(field_22787!=null)field_22787.method_1507(previous);}
}
