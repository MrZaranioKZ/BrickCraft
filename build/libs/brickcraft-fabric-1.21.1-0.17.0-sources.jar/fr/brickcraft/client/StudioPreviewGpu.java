package fr.brickcraft.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_757;
import net.minecraft.class_9799;
import net.minecraft.class_9801;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import java.util.ArrayList;
import java.util.List;

/** Persistent 2D GPU mesh built only when the editor camera/model changes.
 * Vertex positions are projected GUI pixels, preserving exact legacy shading/painter ordering. */
final class StudioPreviewGpu implements AutoCloseable {
    record Triangle(float ax,float ay,float bx,float by,float cx,float cy,int rgba){}
    private final List<Triangle> collected=new ArrayList<>();
    private class_291 buffer;
    private int triangleCount;
    void begin(){collected.clear();}
    void face(int[] x,int[] y,int color){
        if(x.length<3)return;
        collected.add(new Triangle(x[0],y[0],x[1],y[1],x[2],y[2],color));
        if(x.length==4)collected.add(new Triangle(x[0],y[0],x[2],y[2],x[3],y[3],color));
    }
    void rectangle(int x1,int y1,int x2,int y2,int color){
        if(x2<=x1||y2<=y1)return;
        face(new int[]{x1,x2,x2,x1},new int[]{y1,y1,y2,y2},color);
    }
    int triangles(){return triangleCount;}
    void upload(){
        release();triangleCount=collected.size();
        if(collected.isEmpty())return;
        try(class_9799 allocator=new class_9799(Math.max(4096,collected.size()*3*16))){
            class_287 builder=new class_287(allocator,class_293.class_5596.field_27379,class_290.field_1576);
            for(Triangle t:collected){
                builder.method_22912(t.ax(),t.ay(),0).method_39415(t.rgba());
                builder.method_22912(t.bx(),t.by(),0).method_39415(t.rgba());
                builder.method_22912(t.cx(),t.cy(),0).method_39415(t.rgba());
            }
            try(class_9801 built=builder.method_60800()){
                class_291 gpu=new class_291(class_291.class_8555.field_44793);
                try{gpu.method_1353();gpu.method_1352(built);buffer=gpu;}
                catch(RuntimeException e){gpu.close();throw e;}
                finally{class_291.method_1354();}
            }
        }finally{collected.clear();}
    }
    void draw(class_332 ctx,int x1,int y1,int x2,int y2){
        if(buffer==null)return;
        ctx.method_51452(); // Flush queued GUI geometry before a direct VertexBuffer draw.
        ctx.method_44379(x1,y1,x2,y2);
        RenderSystem.disableDepthTest();RenderSystem.disableCull();
        RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
        try{
            // The world projection is NOT guaranteed to be the GUI orthographic matrix.
            // The VBO already contains projected GUI pixel coordinates, so use an
            // explicit top-left-origin projection in scaled GUI units (not framebuffer px).
            float guiW=ctx.method_51421(),guiH=ctx.method_51443();
            Matrix4f model=new Matrix4f().identity();
            Matrix4f projection=new Matrix4f().setOrtho(0f,guiW,guiH,0f,-1000f,1000f);
            buffer.method_1353();buffer.method_34427(model,projection,class_757.method_34540());
        }finally{
            class_291.method_1354();RenderSystem.disableBlend();RenderSystem.enableDepthTest();RenderSystem.enableCull();
            ctx.method_44380();
        }
    }
    void release(){if(buffer!=null){buffer.close();buffer=null;}}
    @Override public void close(){release();collected.clear();}
}
