package fr.brickcraft.client;

import fr.brickcraft.client.BrickGuideController.Target;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

/** The NEXT step is a lightweight wireframe ghost, never a permanent world block. */
public final class BrickGuideTargetOverlay {
    private BrickGuideTargetOverlay(){}
    private static final int[][] EDGES={{0,1},{0,2},{0,4},{1,3},{1,5},{2,3},{2,6},
            {3,7},{4,5},{4,6},{5,7},{6,7}};
    public static void init(){
        WorldRenderEvents.AFTER_ENTITIES.register(ctx->{
            if(!BrickGuideController.active()||!BrickGuideController.targetOverlay()||
                    ctx.consumers()==null||ctx.matrixStack()==null)return;
            var mc=class_310.method_1551();if(mc.field_1724==null)return;
            var targets=BrickGuideController.nextTargets(48);
            if(targets.isEmpty())return;
            var stack=ctx.matrixStack();class_243 cam=ctx.camera().method_19326();
            stack.method_22903();stack.method_22904(-cam.field_1352,-cam.field_1351,-cam.field_1350);
            var lines=ctx.consumers().getBuffer(class_1921.method_23594());
            for(var t:targets){
                for(int[] e:EDGES)line(lines,stack,t.corners()[e[0]],t.corners()[e[1]],0xFF4CEBD6);
                double x=t.x(),y=t.y(),z=t.z(),s=.16;
                line(lines,stack,new double[]{x-s,y,z},new double[]{x+s,y,z},0xFFFFFF76);
                line(lines,stack,new double[]{x,y-s,z},new double[]{x,y+s,z},0xFFFFFF76);
                line(lines,stack,new double[]{x,y,z-s},new double[]{x,y,z+s},0xFFFFFF76);
                // Vertical indicator makes small targets discoverable from above.
                line(lines,stack,new double[]{x,y+.18,z},new double[]{x,y+.9,z},0xFF4CEBD6);
            }
            stack.method_22909();
        });
    }
    private static void line(class_4588 output,class_4587 matrices,double[] a,double[] b,int rgba){
        var matrix=matrices.method_23760().method_23761();
        output.method_22918(matrix,(float)a[0],(float)a[1],(float)a[2]).method_39415(rgba).method_22914(0,1,0);
        output.method_22918(matrix,(float)b[0],(float)b[1],(float)b[2]).method_39415(rgba).method_22914(0,1,0);
    }
}
