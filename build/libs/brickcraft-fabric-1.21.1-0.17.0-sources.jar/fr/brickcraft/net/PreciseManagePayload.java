package fr.brickcraft.net;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Explicit, server-authorized projection listing and removal requests. */
public record PreciseManagePayload(byte operation,class_2338 anchor) implements class_8710 {
    public static final byte LIST=0,REMOVE=1;
    public static final class_8710.class_9154<PreciseManagePayload> ID=
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","precise_manage"));
    public static final class_9139<class_9129,PreciseManagePayload> CODEC=
            class_9139.method_56438(PreciseManagePayload::write,PreciseManagePayload::read);
    public static PreciseManagePayload list(){return new PreciseManagePayload(LIST,class_2338.field_10980);}
    public static PreciseManagePayload remove(class_2338 pos){return new PreciseManagePayload(REMOVE,pos);}
    private void write(class_9129 buf){buf.method_52997(operation);buf.method_10807(anchor);}
    private static PreciseManagePayload read(class_9129 buf){
        byte op=buf.readByte();class_2338 p=buf.method_10811();
        if(op!=LIST&&op!=REMOVE)throw new IllegalArgumentException("Operation inconnue");
        return new PreciseManagePayload(op,p);
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
