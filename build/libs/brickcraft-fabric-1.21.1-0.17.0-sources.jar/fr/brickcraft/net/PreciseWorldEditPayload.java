package fr.brickcraft.net;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Small delta packets. Server owns and persists every modified LEGO transform. */
public record PreciseWorldEditPayload(class_2338 anchor,int index,byte operation,byte axis,double amount)
        implements class_8710 {
    public static final class_8710.class_9154<PreciseWorldEditPayload> ID=
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","world_edit"));
    public static final class_9139<class_9129,PreciseWorldEditPayload> CODEC=
            class_9139.method_56438(PreciseWorldEditPayload::write,PreciseWorldEditPayload::read);
    private void write(class_9129 b){
        b.method_10807(anchor);b.method_10804(index);b.method_52997(operation);b.method_52997(axis);b.method_52940(amount);
    }
    private static PreciseWorldEditPayload read(class_9129 b){
        class_2338 anchor=b.method_10811();int index=b.method_10816();byte op=b.readByte(),axis=b.readByte();double amount=b.readDouble();
        if(index<0||index>=fr.brickcraft.importer.PreciseWorldModel.MAX_PARTS||op<0||op>5||axis<0||axis>2||!Double.isFinite(amount))
            throw new IllegalArgumentException("Paquet WorldEdit invalide");
        return new PreciseWorldEditPayload(anchor,index,op,axis,amount);
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
