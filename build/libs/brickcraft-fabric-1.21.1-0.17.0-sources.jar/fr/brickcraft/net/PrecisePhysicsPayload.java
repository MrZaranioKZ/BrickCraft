package fr.brickcraft.net;

import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record PrecisePhysicsPayload(class_2338 anchor,boolean enable) implements class_8710 {
    public static final class_8710.class_9154<PrecisePhysicsPayload> ID=
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","precise_physics"));
    public static final class_9139<class_9129,PrecisePhysicsPayload> CODEC=
            class_9139.method_56438(PrecisePhysicsPayload::write,PrecisePhysicsPayload::read);
    private void write(class_9129 buf){buf.method_10807(anchor);buf.method_52964(enable);}
    private static PrecisePhysicsPayload read(class_9129 buf){return new PrecisePhysicsPayload(buf.method_10811(),buf.readBoolean());}
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
