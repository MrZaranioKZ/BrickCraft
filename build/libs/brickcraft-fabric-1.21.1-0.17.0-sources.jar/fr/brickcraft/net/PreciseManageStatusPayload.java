package fr.brickcraft.net;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Current loaded projections only, from the server's authoritative block entities. */
public record PreciseManageStatusPayload(byte event,List<Entry> projects,String message) implements class_8710 {
    public static final byte LIST=0,REMOVED=1,ERROR=2;
    public static final int LIMIT=32;
    public record Entry(class_2338 anchor,int pieces){}
    public static final class_8710.class_9154<PreciseManageStatusPayload> ID=
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","precise_manage_status"));
    public static final class_9139<class_9129,PreciseManageStatusPayload> CODEC=
            class_9139.method_56438(PreciseManageStatusPayload::write,PreciseManageStatusPayload::read);
    public PreciseManageStatusPayload{projects=List.copyOf(projects);}
    private void write(class_9129 buf){
        buf.method_52997(event);buf.method_10788(message,240);buf.method_10804(projects.size());
        for(Entry p:projects){buf.method_10807(p.anchor());buf.method_10804(p.pieces());}
    }
    private static PreciseManageStatusPayload read(class_9129 buf){
        byte event=buf.readByte();String message=buf.method_10800(240);int n=buf.method_10816();
        if(n<0||n>LIMIT)throw new IllegalArgumentException("Liste de projections trop longue");
        List<Entry> projects=new ArrayList<>(n);
        for(int i=0;i<n;i++)projects.add(new Entry(buf.method_10811(),buf.method_10816()));
        return new PreciseManageStatusPayload(event,projects,message);
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
