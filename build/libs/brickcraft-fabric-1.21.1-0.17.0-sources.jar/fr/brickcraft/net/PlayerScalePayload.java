package fr.brickcraft.net;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** One validated, finite scale multiplier. The server owns actual hitbox and eye height. */
public record PlayerScalePayload(float scale) implements class_8710 {
    public static final class_9154<PlayerScalePayload> ID=new class_9154<>(class_2960.method_60655("brickcraft","player_scale"));
    public static final class_9139<class_9129,PlayerScalePayload> CODEC=
            class_9139.method_56438(PlayerScalePayload::write,PlayerScalePayload::read);
    private void write(class_9129 buf){buf.method_52941(scale);}
    private static PlayerScalePayload read(class_9129 buf){return new PlayerScalePayload(buf.readFloat());}
    @Override public class_9154<? extends class_8710> method_56479(){return ID;}
}
