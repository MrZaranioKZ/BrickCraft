package fr.brickcraft.net;

import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Ordered and size-bounded C2S transfer of one Studio blueprint. */
public record StudioExportPayload(byte operation, class_2338 origin, int grid, int total,
                                  int offset, List<BrickPiece> pieces) implements class_8710 {
    public static final byte BEGIN=0, PARTS=1, COMMIT=2, CANCEL=3;
    public static final int BATCH_SIZE=24;
    public static final class_8710.class_9154<StudioExportPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","studio_export"));
    public static final class_9139<class_9129,StudioExportPayload> CODEC =
            class_9139.method_56438(StudioExportPayload::write,StudioExportPayload::read);

    public static StudioExportPayload begin(class_2338 origin,int grid,int total){
        return new StudioExportPayload(BEGIN,origin,grid,total,0,List.of());
    }
    public static StudioExportPayload batch(int offset,List<BrickPiece> pieces){
        return new StudioExportPayload(PARTS,new class_2338(0,0,0),0,0,offset,List.copyOf(pieces));
    }
    public static StudioExportPayload commit(){
        return new StudioExportPayload(COMMIT,new class_2338(0,0,0),0,0,0,List.of());
    }
    public static StudioExportPayload cancel(){
        return new StudioExportPayload(CANCEL,new class_2338(0,0,0),0,0,0,List.of());
    }
    private void write(class_9129 buf){
        buf.method_52997(operation);
        if(operation==BEGIN){
            buf.method_10807(origin);buf.method_10804(grid);buf.method_10804(total);
        }else if(operation==PARTS){
            buf.method_10804(offset);buf.method_10804(pieces.size());
            for(BrickPiece p:pieces){
                buf.method_10804(p.kind().ordinal());buf.method_53002(p.rgb());
                buf.method_10804(p.x());buf.method_10804(p.y());buf.method_10804(p.z());
                buf.method_52997(p.turn());buf.method_52998(p.angle());
                buf.method_52997(p.pitch()/90);buf.method_52997(p.roll()/90);
                buf.method_10788(p.partId()==null?"":p.partId(),40);buf.method_53002(p.colorCode());
            }
        }
    }
    private static StudioExportPayload read(class_9129 buf){
        byte op=buf.readByte();
        if(op==BEGIN)return begin(buf.method_10811(),buf.method_10816(),buf.method_10816());
        if(op==PARTS){
            int offset=buf.method_10816(), count=buf.method_10816();
            if(offset<0 || count<1 || count>BATCH_SIZE)throw new IllegalArgumentException("Studio batch too large");
            List<BrickPiece> pieces=new ArrayList<>(count);
            BrickKind[] kinds=BrickKind.values();
            for(int i=0;i<count;i++){
                int kind=buf.method_10816(),rgb=buf.readInt();
                int x=buf.method_10816(),y=buf.method_10816(),z=buf.method_10816();
                int turn=buf.readByte(),angle=buf.readUnsignedShort();
                int pitch=buf.readUnsignedByte()*90,roll=buf.readUnsignedByte()*90;
                String id=buf.method_10800(40);int code=buf.readInt();
                if(kind<0 || kind>=kinds.length)throw new IllegalArgumentException("Invalid piece kind");
                pieces.add(new BrickPiece(kinds[kind],rgb,x,y,z,turn,angle,pitch,roll,id,code));
            }
            return batch(offset,pieces);
        }
        if(op==COMMIT)return commit();
        if(op==CANCEL)return cancel();
        throw new IllegalArgumentException("Unknown Studio export operation");
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
