package fr.brickcraft.net;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server -> client export progress; never interpreted as an authoritative world change. */
public record StudioExportStatusPayload(boolean finished,boolean success,String message) implements class_8710 {
    public static final class_8710.class_9154<StudioExportStatusPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft","studio_export_status"));
    public static final class_9139<class_9129,StudioExportStatusPayload> CODEC =
            class_9139.method_56438(StudioExportStatusPayload::write,StudioExportStatusPayload::read);
    private void write(class_9129 buf){
        buf.method_52964(finished);buf.method_52964(success);buf.method_10788(message,240);
    }
    private static StudioExportStatusPayload read(class_9129 buf){
        return new StudioExportStatusPayload(buf.readBoolean(),buf.readBoolean(),buf.method_10800(240));
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479(){return ID;}
}
