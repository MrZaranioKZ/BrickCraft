package fr.brickcraft.net;

import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Server-authoritative world undo/redo, per player and world. */
public record BrickEditPayload(boolean redo) implements class_8710 {
    public static final class_9154<BrickEditPayload> ID=new class_9154<>(class_2960.method_60655("brickcraft","edit_history"));
    public static final class_9139<class_9129,BrickEditPayload> CODEC=
        class_9139.method_56438((payload,buf)->buf.method_52964(payload.redo()),buf->new BrickEditPayload(buf.readBoolean()));
    @Override public class_9154<? extends class_8710> method_56479(){return ID;}
}
