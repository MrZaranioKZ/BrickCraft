package fr.brickcraft.world;

import fr.brickcraft.net.PlayerScalePayload;
import fr.brickcraft.BrickCraft;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.server.MinecraftServer;
import java.util.Locale;

/** Uses vanilla GENERIC_SCALE: model, camera eye height AND server/client collision box stay in sync. */
public final class PlayerScaleManager {
    private PlayerScaleManager(){}
    public static final double MIN=0.125,MAX=4.0;
    private static final class_2960 MODIFIER_ID=class_2960.method_60655("brickcraft","player_exploration_scale");
    private static final class_2960 STEP_MODIFIER=class_2960.method_60655("brickcraft","lego_ramp_step_height");
    /** Only applies to players next to BrickCraft physical blocks. No global climbing buff. */
    public static void tick(MinecraftServer server){
        for(class_3222 player:server.method_3760().method_14571()){
            var step=player.method_5996(class_5134.field_47761);
            if(step==null)continue;
            boolean close=!player.method_7325()&&nearLegoPhysics(player);
            var previous=step.method_6199(STEP_MODIFIER);
            if(!close){if(previous!=null)step.method_6200(STEP_MODIFIER);continue;}
            double wanted=ExplorationStepRules.stepHeight(
                    player.method_45325(class_5134.field_47760));
            // Avoid attribute change packets every tick. Respect other mods' adjustments.
            if(previous!=null&&Math.abs(step.method_6194()-wanted)<.01)continue;
            if(previous!=null)step.method_6200(STEP_MODIFIER);
            double baseline=step.method_6194();
            if(Math.abs(baseline-wanted)>.01)
                step.method_26835(new class_1322(STEP_MODIFIER,wanted-baseline,
                        class_1322.class_1323.field_6328));
        }
    }
    private static boolean nearLegoPhysics(class_3222 player){
        class_3218 world=player.method_51469();
        class_2338 center=player.method_24515();
        int radius=(int)Math.min(3,Math.ceil(.3*player.method_45325(class_5134.field_47760))+1);
        class_2338.class_2339 pos=new class_2338.class_2339();
        for(int y=-1;y<=1;y++)for(int x=-radius;x<=radius;x++)for(int z=-radius;z<=radius;z++){
            pos.method_10103(center.method_10263()+x,center.method_10264()+y,center.method_10260()+z);
            if(!world.method_22340(pos))continue;
            if(world.method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))return true;
            if(world.method_8320(pos).method_27852(BrickCraft.PRECISE_DISPLAY)&&
                    world.method_8321(pos) instanceof PreciseDisplayEntity anchor&&anchor.hasAnchorCollision())return true;
        }
        return false;
    }

    public static boolean allowed(double value){return Double.isFinite(value)&&value>=MIN&&value<=MAX;}
    public static void receive(class_3222 player,PlayerScalePayload packet){
        double requested=packet.scale();
        if(!allowed(requested)||player.method_7325()||
           !(player.method_7337() || player.method_5682().method_3724())){
            player.method_7353(class_2561.method_43470("BrickCraft : taille refusee (partie solo ou mode creatif requis)"),false);return;
        }
        var attribute=player.method_5996(class_5134.field_47760);
        if(attribute==null)return;
        double oldEffectiveScale=attribute.method_6194();
        class_1322 previous=attribute.method_6199(MODIFIER_ID);
        attribute.method_6200(MODIFIER_ID);
        if(Math.abs(requested-1.0)>0.00001)
            attribute.method_26837(new class_1322(MODIFIER_ID,requested-1.0,
                    class_1322.class_1323.field_6330));
        player.method_18382();
        // Avoid growing inside walls. A failed change restores the former attribute and bounding box.
        if(attribute.method_6194()>oldEffectiveScale+1e-5 &&
           !player.method_37908().method_8587(player,player.method_5829())){
            attribute.method_6200(MODIFIER_ID);
            if(previous!=null)attribute.method_26837(previous);
            player.method_18382();
            player.method_7353(class_2561.method_43470("BrickCraft : agrandissement impossible ici (obstacle). Deplace-toi."),false);
            return;
        }
        player.method_7353(class_2561.method_43470(String.format(Locale.ROOT,
                "BrickCraft : taille x%.3f | hitbox et yeux adaptes (U pour regler)",requested)),true);
    }
    /** Retain the setting across respawns, if vanilla recreates the attribute container. */
    public static void respawn(class_3222 oldPlayer,class_3222 newPlayer,boolean alive){
        var oldAttr=oldPlayer.method_5996(class_5134.field_47760);
        var nextAttr=newPlayer.method_5996(class_5134.field_47760);
        if(oldAttr==null||nextAttr==null)return;
        class_1322 old=oldAttr.method_6199(MODIFIER_ID);
        if(old!=null){nextAttr.method_61163(old);newPlayer.method_18382();}
    }
}
