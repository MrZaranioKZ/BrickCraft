package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.core.StudioExportLimits;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.net.StudioExportPayload;
import fr.brickcraft.net.StudioExportStatusPayload;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Server-authoritative large Studio exports. Receives a bounded blueprint, preflights its
 * entire footprint without editing the world, then commits/rolls back incrementally.
 * Work runs only on the server thread, with a fixed cell budget per tick.
 */
public final class StudioExportManager {
    private static final int MAX_ACTIVE_JOBS=2;
    private static final int CELLS_PER_TICK=320;
    private static final int RECEIVE_TIMEOUT_TICKS=600;
    private static final Map<UUID,Job> JOBS=new HashMap<>();

    private enum Phase { RECEIVING, VALIDATING, APPLYING, ROLLING_BACK }
    private record PlacedCell(class_2338 pos,BrickPiece piece){}
    private static final class Job {
        final UUID playerId;
        final class_3218 world;
        final class_2338 origin;
        final int grid,total;
        final List<BrickPiece> received=new ArrayList<>();
        final List<BrickPiece> worldPieces=new ArrayList<>();
        final List<List<class_2338>> footprints=new ArrayList<>();
        final Map<class_2338,List<BrickPiece>> planned=new HashMap<>();
        final Deque<PlacedCell> placed=new ArrayDeque<>();
        Phase phase=Phase.RECEIVING;
        int receiveTicks=0,cellCount=0,pieceIndex=0,cellIndex=0,lastProgress=-1,rollbackFailures=0;
        String failure="";
        Job(class_3222 player,class_2338 origin,int grid,int total){
            this.playerId=player.method_5667();this.world=player.method_51469();
            this.origin=origin.method_10062();this.grid=grid;this.total=total;
        }
    }
    private StudioExportManager(){}

    public static void receive(class_3222 player,StudioExportPayload packet){
        if(packet.operation()==StudioExportPayload.BEGIN){
            begin(player,packet);return;
        }
        Job job=JOBS.get(player.method_5667());
        if(job==null){
            // A refused BEGIN is followed by queued batch packets. Do not spam the player.
            if(packet.operation()==StudioExportPayload.COMMIT)
                reply(player,true,false,"Aucun export actif (debut refuse ou expire)");
            return;
        }
        if(packet.operation()==StudioExportPayload.CANCEL){
            if(job.phase==Phase.APPLYING || job.phase==Phase.ROLLING_BACK){
                job.failure="Export annule";job.phase=Phase.ROLLING_BACK;
                reply(player,false,false,"Annulation : retrait des pieces deja posees...");
            }else stop(job,false,"Export annule (monde inchange)");
            return;
        }
        // Ignore stale/duplicate network packets once validation has begun. Never cancel a
        // running build because a repeated COMMIT arrived from a laggy client.
        if(job.phase!=Phase.RECEIVING)return;
        if(player.method_51469()!=job.world){
            reject(job,"Dimension modifiee avant le transfert");return;
        }
        if(packet.operation()==StudioExportPayload.PARTS){
            if(!StudioExportLimits.validBatch(packet.offset(),packet.pieces().size(),
                    job.received.size(),job.total)){
                reject(job,"Lot invalide ou envoi incomplet");return;
            }
            for(BrickPiece p:packet.pieces()){
                if(!StudioExportLimits.validLocal(p,job.grid)){
                    reject(job,"Piece hors plateau ou invalide");return;
                }
            }
            job.received.addAll(packet.pieces());job.receiveTicks=0;
        }else if(packet.operation()==StudioExportPayload.COMMIT){
            if(job.received.size()!=job.total){
                reject(job,"Projet incomplet : "+job.received.size()+"/"+job.total);return;
            }
            job.phase=Phase.VALIDATING;
            reply(player,false,true,"Plan recu : "+job.total+" pieces. Verification du terrain...");
        }else reject(job,"Operation inconnue");
    }
    private static void begin(class_3222 player,StudioExportPayload packet){
        if(JOBS.containsKey(player.method_5667())){
            reply(player,false,false,"Un export est deja en cours. Termine-le avant de recommencer.");return;
        }
        if(JOBS.size()>=MAX_ACTIVE_JOBS){
            reply(player,true,false,"Le serveur traite deja trop d'exports simultanes");return;
        }
        class_3218 world=player.method_51469();class_2338 pos=packet.origin();
        if(!player.method_7337() || !StudioExportLimits.validGrid(packet.grid()) ||
                packet.total()<1 || packet.total()>StudioExportLimits.MAX_PIECES ||
                !world.method_24794(pos) ||
                player.method_5707(class_243.method_24953(pos))>144.0 ||
                !world.method_8505(player,pos)){
            reply(player,true,false,"Export refuse : mode Creatif, origine proche et droits requis");return;
        }
        JOBS.put(player.method_5667(),new Job(player,pos,packet.grid(),packet.total()));
        reply(player,false,true,"Reception du projet : "+packet.total()+" pieces...");
    }

    public static void tick(MinecraftServer server){
        for(Job job:new ArrayList<>(JOBS.values())){
            if(JOBS.get(job.playerId)!=job)continue;
            class_3222 player=server.method_3760().method_14602(job.playerId);
            if(job.phase==Phase.RECEIVING){
                if(++job.receiveTicks>RECEIVE_TIMEOUT_TICKS || player==null)
                    stop(job,false,"Export expire avant reception complete");
                continue;
            }
            if(job.phase!=Phase.ROLLING_BACK && (player==null || player.method_51469()!=job.world || !player.method_7337())){
                if(job.phase==Phase.APPLYING){
                    job.failure="Joueur deconnecte ou dimension / mode modifie";
                    job.phase=Phase.ROLLING_BACK;
                }else stop(job,false,"Export interrompu avant construction");
                continue;
            }
            try{
                switch(job.phase){
                    case VALIDATING -> validate(job,player);
                    case APPLYING -> apply(job,player);
                    case ROLLING_BACK -> rollback(job);
                    default -> {}
                }
            }catch(RuntimeException e){
                // Never retain a partly built project after an unexpected runtime failure.
                if(job.phase==Phase.ROLLING_BACK){
                    stop(job,false,"ERREUR : rollback interrompu, verifie la zone : "+e.getClass().getSimpleName());
                }else if(job.phase==Phase.APPLYING){
                    job.failure="Erreur serveur pendant export : "+e.getClass().getSimpleName();
                    job.phase=Phase.ROLLING_BACK;
                }else stop(job,false,"Erreur de validation : "+e.getClass().getSimpleName());
            }
        }
    }

    private static void validate(Job job,class_3222 player){
        int budget=CELLS_PER_TICK;
        while(budget>0 && job.pieceIndex<job.total){
            if(job.cellIndex==0){
                BrickPiece local=job.received.get(job.pieceIndex);
                if(!StudioExportLimits.validLocal(local,job.grid) ||
                        StudioExportLimits.upperBoundCells(local)>StudioExportLimits.MAX_CELLS_PER_PIECE){
                    reject(job,"Piece trop grande / hors plateau (index "+job.pieceIndex+")");return;
                }
                BrickPiece global;
                try{global=StudioExportLimits.inWorld(local,job.origin.method_10263(),job.origin.method_10264(),job.origin.method_10260());}
                catch(IllegalArgumentException e){reject(job,"Origine hors limites");return;}
                if(!global.valid() || (global.kind()==BrickKind.LDRAW_PART &&
                        LDrawLibrary.mesh(global.partId())==null)){
                    reject(job,"Piece LDraw manquante sur le serveur : "+local.name());return;
                }
                List<class_2338> cells=global.occupiedCells();
                if(cells.isEmpty() || cells.size()>StudioExportLimits.MAX_CELLS_PER_PIECE ||
                        job.cellCount+cells.size()>StudioExportLimits.MAX_TOTAL_CELLS){
                    reject(job,"Construction trop volumineuse (limite de cellules)");return;
                }
                job.cellCount+=cells.size();
                job.worldPieces.add(global);job.footprints.add(cells);
            }
            BrickPiece piece=job.worldPieces.get(job.pieceIndex);
            List<class_2338> footprint=job.footprints.get(job.pieceIndex);
            while(budget>0 && job.cellIndex<footprint.size()){
                class_2338 pos=footprint.get(job.cellIndex++);budget--;
                if(!job.world.method_24794(pos) || !job.world.method_8505(player,pos)){
                    reject(job,"Hauteur ou zone protegee a "+pos.method_23854());return;
                }
                // Minecraft loads the target chunk here if necessary. Throttled by cell budget.
                class_2680 state=job.world.method_8320(pos);
                List<BrickPiece> reserved=job.planned.get(pos);
                if(!state.method_26215()){
                    if(!state.method_27852(BrickCraft.CELL) ||
                            !(job.world.method_8321(pos) instanceof BrickCellEntity cell) ||
                            !cell.canAdd(piece) ||
                            cell.pieces().size()+(reserved==null?0:reserved.size())>=BrickCellEntity.MAX_PIECES){
                        reject(job,"Terrain occupe / LEGO en collision a "+pos.method_23854());return;
                    }
                }else if(reserved!=null && reserved.size()>=BrickCellEntity.MAX_PIECES){
                    reject(job,"Trop de pieces dans une cellule a "+pos.method_23854());return;
                }
                if(reserved!=null){
                    for(BrickPiece other:reserved)if(other.intersects(piece)){
                        reject(job,"Pieces du projet en collision a "+pos.method_23854());return;
                    }
                }else if(job.planned.size()>=StudioExportLimits.MAX_DISTINCT_CELLS){
                    reject(job,"Trop de cellules distinctes");return;
                }
                job.planned.computeIfAbsent(pos,k->new ArrayList<>()).add(piece);
            }
            if(job.cellIndex>=footprint.size()){
                job.pieceIndex++;job.cellIndex=0;
            }
        }
        if(job.pieceIndex==job.total){
            job.phase=Phase.APPLYING;job.pieceIndex=0;job.cellIndex=0;
            job.lastProgress=-1;
            job.planned.clear(); // Release preflight collision map before building.
            progress(job,player,0,"Construction");
        }else progress(job,player,job.pieceIndex*100/job.total,"Verification");
    }

    private static void apply(Job job,class_3222 player){
        int budget=CELLS_PER_TICK;
        while(budget>0 && job.pieceIndex<job.total){
            BrickPiece piece=job.worldPieces.get(job.pieceIndex);
            List<class_2338> footprint=job.footprints.get(job.pieceIndex);
            while(budget>0 && job.cellIndex<footprint.size()){
                class_2338 pos=footprint.get(job.cellIndex);budget--;
                if(!job.world.method_24794(pos) || !job.world.method_8505(player,pos)){
                    failDuringBuild(job,"Zone devenue inaccessible : "+pos.method_23854());return;
                }
                class_2680 state=job.world.method_8320(pos);
                if(state.method_26215()){
                    if(!job.world.method_8652(pos,BrickCraft.CELL.method_9564(),3)){
                        failDuringBuild(job,"Creation de cellule impossible");return;
                    }
                }else if(!state.method_27852(BrickCraft.CELL)){
                    failDuringBuild(job,"Terrain modifie pendant l'export");return;
                }
                if(!(job.world.method_8321(pos) instanceof BrickCellEntity cell) ||
                        !cell.addFromExport(piece)){
                    // If we just made an empty container, clean it up before rollback.
                    if(job.world.method_8321(pos) instanceof BrickCellEntity empty && empty.pieces().isEmpty())
                        job.world.method_8652(pos,class_2246.field_10124.method_9564(),3);
                    failDuringBuild(job,"Collision apparue pendant l'export");return;
                }
                job.placed.push(new PlacedCell(pos,piece));job.cellIndex++;
            }
            if(job.cellIndex>=footprint.size()){
                job.pieceIndex++;job.cellIndex=0;
            }
        }
        if(job.pieceIndex==job.total){
            stop(job,true,"Export termine : "+job.total+" pieces et "+job.cellCount+" fragments places");
        }else progress(job,player,job.pieceIndex*100/job.total,"Construction");
    }

    private static void failDuringBuild(Job job,String reason){
        job.failure=reason;job.phase=Phase.ROLLING_BACK;
        class_3222 player=job.world.method_8503().method_3760().method_14602(job.playerId);
        if(player!=null)reply(player,false,false,"Export interrompu : retour en arriere...");
    }
    private static void rollback(Job job){
        int budget=CELLS_PER_TICK;
        while(budget-->0 && !job.placed.isEmpty()){
            PlacedCell applied=job.placed.pop();class_2338 pos=applied.pos();
            if(job.world.method_8321(pos) instanceof BrickCellEntity cell){
                if(cell.remove(applied.piece())){
                    if(cell.pieces().isEmpty())job.world.method_8652(pos,class_2246.field_10124.method_9564(),3);
                }else job.rollbackFailures++;
            }else job.rollbackFailures++;
        }
        if(job.placed.isEmpty()){
            if(job.rollbackFailures==0)stop(job,false,job.failure+" — retour en arriere effectue");
            else stop(job,false,job.failure+" — rollback INCOMPLET ("+job.rollbackFailures+
                    " cellules). Restaure une sauvegarde si necessaire.");
        }
    }
    private static void progress(Job job,class_3222 player,int percent,String stage){
        int quarter=percent/25;
        if(quarter>job.lastProgress){
            job.lastProgress=quarter;
            reply(player,false,true,stage+" : "+percent+"% ("+job.pieceIndex+"/"+job.total+")");
        }
    }
    private static void reject(Job job,String reason){
        stop(job,false,"Export refuse : "+reason+". Monde inchange.");
    }
    private static void stop(Job job,boolean success,String reason){
        JOBS.remove(job.playerId,job);
        class_3222 player=job.world.method_8503().method_3760().method_14602(job.playerId);
        if(player!=null)reply(player,true,success,reason);
    }
    private static void reply(class_3222 player,boolean finished,boolean success,String message){
        ServerPlayNetworking.send(player,new StudioExportStatusPayload(finished,success,message));
        if(finished)player.method_7353(class_2561.method_43470("BrickCraft : "+message),false);
    }
}
