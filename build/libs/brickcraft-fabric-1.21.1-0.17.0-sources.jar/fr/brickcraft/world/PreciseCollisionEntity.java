package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;

/** Stores only 64 bytes per collision block: 8x8x8 sub-block occupancy, synced to clients. */
public final class PreciseCollisionEntity extends class_2586 {
    private long[] bits=new long[0];
    private transient class_265 cached;
    public PreciseCollisionEntity(class_2338 pos,class_2680 state){super(BrickCraft.PRECISE_COLLISION_ENTITY,pos,state);}
    public void setMask(long[] mask){
        if(mask==null||mask.length!=8)throw new IllegalArgumentException("Masque de collision invalide");
        bits=mask.clone();cached=null;method_5431();
        if(field_11863 instanceof net.minecraft.class_3218 server)
            server.method_14178().method_14128(field_11867);
    }
    public class_265 shape(){
        if(bits.length!=8)return class_259.method_1073(); // Unknown/legacy data must NOT become an invisible full wall.
        if(cached!=null)return cached;
        return cached=createShape(bits);
    }
    /** Shape utility shared by transparent collision blocks AND the visible projection anchor. */
    public static class_265 createShape(long[] bits){
        if(bits==null||bits.length!=8)return class_259.method_1073();
        // Merge occupied micro-voxels into maximal rectangular boxes for cheap collision tests.
        boolean[] used=new boolean[512];class_265 result=class_259.method_1073();
        for(int y=0;y<8;y++)for(int z=0;z<8;z++)for(int x=0;x<8;x++){
            if(!free(bits,x,y,z,used))continue;
            int xx=x+1;while(xx<8&&free(bits,xx,y,z,used))xx++;
            int zz=z+1;
            zloop:while(zz<8){for(int a=x;a<xx;a++)if(!free(bits,a,y,zz,used))break zloop;zz++;}
            int yy=y+1;
            yloop:while(yy<8){for(int b=z;b<zz;b++)for(int a=x;a<xx;a++)
                if(!free(bits,a,yy,b,used))break yloop;yy++;}
            for(int b=y;b<yy;b++)for(int c=z;c<zz;c++)for(int a=x;a<xx;a++)used[b*64+c*8+a]=true;
            result=class_259.method_1084(result,class_259.method_1081(x/8.0,y/8.0,z/8.0,xx/8.0,yy/8.0,zz/8.0));
        }
        return result;
    }
    private static boolean free(long[] bits,int x,int y,int z,boolean[] used){
        return !used[y*64+z*8+x]&&PreciseMeshCollisionPlan.occupied(bits,x,y,z);
    }
    @Override protected void method_11007(class_2487 nbt,class_7225.class_7874 lookup){
        super.method_11007(nbt,lookup);
        if(bits.length==8)nbt.method_10564("BrickCraftMicroVoxels",bits);
    }
    @Override public void method_11014(class_2487 nbt,class_7225.class_7874 lookup){
        super.method_11014(nbt,lookup);long[] data=nbt.method_10565("BrickCraftMicroVoxels");
        bits=data.length==8?data:new long[0];cached=null;
    }
    @Override public @Nullable class_2596<class_2602> method_38235(){
        return class_2622.method_38585(this);
    }
    @Override public class_2487 method_16887(class_7225.class_7874 lookup){return method_38244(lookup);}
}
