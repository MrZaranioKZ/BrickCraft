package fr.brickcraft.world;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

/** Invisible, per-cell sub-voxel collision preserving details in the original LDraw mesh. */
public final class PreciseCollisionBlock extends class_2237 {
    public static final MapCodec<PreciseCollisionBlock> CODEC=method_54094(PreciseCollisionBlock::new);
    public PreciseCollisionBlock(class_2251 settings){super(settings);}
    @Override protected MapCodec<? extends class_2237> method_53969(){return field_46280;}
    @Override public @Nullable class_2586 method_10123(class_2338 pos,class_2680 state){
        return new PreciseCollisionEntity(pos,state);
    }
    @Override protected class_2464 method_9604(class_2680 state){return class_2464.field_11455;}
    @Override protected class_265 method_9530(class_2680 state,class_1922 world,class_2338 pos,class_3726 ctx){
        return class_259.method_1073(); // Never interfere with the visible projection's raycast.
    }
    @Override protected class_265 method_9549(class_2680 state,class_1922 world,class_2338 pos,class_3726 ctx){
        return world.method_8321(pos) instanceof PreciseCollisionEntity be?be.shape():class_259.method_1077();
    }
}
