package fr.brickcraft.world;

import fr.brickcraft.core.BrickKind;
import net.minecraft.class_1792;

/** Each kind is a creative-inventory item usable with ordinary Minecraft hotbar. */
public final class BrickPartItem extends class_1792 {
    private final BrickKind kind;
    public BrickPartItem(BrickKind kind, class_1793 settings) {super(settings); this.kind=kind;}
    public BrickKind kind() {return kind;}
}
