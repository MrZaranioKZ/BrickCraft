package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

/** A 'fragment' cell: stores references to all complete world-space pieces crossing it. */
public final class BrickCellEntity extends class_2586 {
    public static final int MAX_PIECES = 48;
    private final ArrayList<BrickPiece> pieces = new ArrayList<>();
    private transient class_265 cachedShape;
    // If the LDraw zip is temporarily missing, retain unknown pieces in NBT intact.
    private final class_2499 unresolvedPieces = new class_2499();

    public BrickCellEntity(class_2338 pos, class_2680 state) { super(BrickCraft.CELL_ENTITY, pos, state); }
    public List<BrickPiece> pieces() { return List.copyOf(pieces); }

    /** Cached shape of the classic stud-grid cells: round studs instead of square cubes. */
    public class_265 outlineShape() {
        if(cachedShape!=null)return cachedShape;
        class_265 result=class_259.method_1073();
        for(BrickPiece part:pieces){
            double bottom=Math.max(0.0,part.y()/5.0-field_11867.method_10264());
            double top=Math.min(1.0,part.top()/5.0-field_11867.method_10264());
            if(top>bottom)result=class_259.method_1084(result,class_259.method_1081(0,bottom,0,1,top,1));
            if(part.kind().studs){
                double low=Math.max(0.0,part.top()/5.0-field_11867.method_10264());
                double high=Math.min(1.0,(part.top()+1)/5.0-field_11867.method_10264());
                if(high<=low)continue;
                // Eight horizontal bands approximate the real round 0.6-stud diameter.
                for(int i=0;i<8;i++){
                    double x0=.2+i*.6/8.0,x1=.2+(i+1)*.6/8.0;
                    double mid=(x0+x1)/2.0;
                    double half=Math.sqrt(Math.max(0,.3*.3-(mid-.5)*(mid-.5)));
                    result=class_259.method_1084(result,class_259.method_1081(x0,low,.5-half,x1,high,.5+half));
                }
            }
        }
        return cachedShape=result.method_1110()?class_259.method_1077():result;
    }

    public boolean canAdd(BrickPiece candidate) {
        if (pieces.size() >= MAX_PIECES || !unresolvedPieces.isEmpty()) return false;
        for (BrickPiece old : pieces) if (old.intersects(candidate)) return false;
        return true;
    }

    public boolean add(BrickPiece piece) {
        if (!piece.occupiedCells().contains(field_11867) || !canAdd(piece)) return false;
        pieces.add(piece); sync(); return true;
    }

    /** A fast insertion only for the server's prevalidated, cell-by-cell large export. */
    public boolean addFromExport(BrickPiece piece) {
        if(!canAdd(piece))return false;
        pieces.add(piece);sync();return true;
    }

    public boolean remove(BrickPiece piece) {
        if (!pieces.remove(piece)) return false;
        sync(); return true;
    }

    /** For the top of the visible LEGO under the cursor; allows exact LEGO layer stacking. */
    public BrickPiece topmost() {
        BrickPiece chosen = null;
        for (BrickPiece p : pieces) {
            if (chosen == null || p.top() > chosen.top()) chosen = p;
        }
        return chosen;
    }

    /** Distinguishes multiple plates in one cell by the precise clicked height. */
    public BrickPiece pickAt(double worldY, boolean topFace) {
        BrickPiece chosen=null;
        double best=Double.POSITIVE_INFINITY;
        for(BrickPiece p:pieces){
            double low=p.y()/5.0,high=p.top()/5.0;
            // A click at the joint belongs to the upper brick (its bottom), not to both.
            double distance;
            if(topFace)distance=Math.abs(worldY-high);
            else if(worldY>=low-.005 && worldY<=high+.005)distance=0;
            else distance=Math.min(Math.abs(worldY-low),Math.abs(worldY-high));
            if(distance<best-1e-6 || (Math.abs(distance-best)<1e-6 &&
                    chosen!=null && (topFace?p.top()>chosen.top():p.y()>chosen.y()))) {
                best=distance;chosen=p;
            }
        }
        return chosen;
    }

    private void sync() {
        cachedShape=null;
        method_5431();
        if (field_11863 instanceof class_3218 serverWorld) serverWorld.method_14178().method_14128(field_11867);
    }

    @Override protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_2499 items = new class_2499();
        for (BrickPiece p : pieces) {
            class_2487 v = new class_2487();
            v.method_10582("Kind", p.kind().name());
            v.method_10569("RGB", p.rgb()); v.method_10569("X", p.x()); v.method_10569("Y", p.y());
            v.method_10569("Z", p.z()); v.method_10569("Turn", p.turn()); v.method_10569("Angle",p.angle());
            v.method_10569("Pitch",p.pitch()); v.method_10569("Roll",p.roll());v.method_10569("LDrawColour",p.colorCode());
            if(p.kind()==BrickKind.LDRAW_PART)v.method_10582("LDrawId",p.partId());
            items.add(v);
        }
        for(int i=0;i<unresolvedPieces.size();i++)items.add(unresolvedPieces.method_10602(i).method_10553());
        nbt.method_10566("PiecesV2", items);
    }

    @Override public void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        pieces.clear();unresolvedPieces.clear();cachedShape=null;
        class_2499 items = nbt.method_10554("PiecesV2", class_2520.field_33260);
        // Previous V0.1 format intentionally not migrated: its geometry uses a different scale.
        for (int i=0; i<items.size() && pieces.size()<MAX_PIECES; i++) {
            class_2487 v = items.method_10602(i);
            try {
                BrickPiece p = new BrickPiece(BrickKind.valueOf(v.method_10558("Kind")),
                    v.method_10550("RGB") & 0xFFFFFF, v.method_10550("X"), v.method_10550("Y"),
                    v.method_10550("Z"), v.method_10550("Turn"),
                    v.method_10573("Angle", class_2520.field_33263) ? v.method_10550("Angle") : v.method_10550("Turn")*90,
                    v.method_10550("Pitch"),v.method_10550("Roll"),v.method_10558("LDrawId"),
                    v.method_10573("LDrawColour", class_2520.field_33263)?v.method_10550("LDrawColour"):-1);
                if(p.kind()==BrickKind.LDRAW_PART && !p.valid()) {
                    unresolvedPieces.add(v.method_10553()); // Preserve worlds when users forget complete.zip.
                } else if (p.valid() && p.occupiedCells().contains(field_11867) && canAdd(p))pieces.add(p);
                else if(!unresolvedPieces.isEmpty())unresolvedPieces.add(v.method_10553());
            } catch (IllegalArgumentException ignored) {
                if("LDRAW_PART".equals(v.method_10558("Kind")))unresolvedPieces.add(v.method_10553());
            }
        }
    }

    @Override public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
    @Override public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }
}
