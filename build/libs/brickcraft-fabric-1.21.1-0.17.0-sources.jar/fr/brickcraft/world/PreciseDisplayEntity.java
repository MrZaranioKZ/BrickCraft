package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseWorldModel;
import org.jetbrains.annotations.Nullable;
import java.io.IOException;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

/** Single-NBT-anchor storage; keep compressed original bytes even if complete.zip is missing. */
public final class PreciseDisplayEntity extends class_2586 {
    private PreciseWorldModel model;
    private byte[] packed=new byte[0];
    private boolean decodeAttempted=false;
    private long[] collisionCells=new long[0];
    // Version 0.12 accidentally omitted the entire 1x1x1 block under the anchor.
    // The projection anchor must provide collision for its own LEGO geometry.
    private long[] anchorMask=new long[0];
    private transient class_265 anchorShape;
    public boolean hasAnchorCollision(){return anchorMask.length==8;}
    public class_265 anchorCollisionShape(){
        if(anchorMask.length!=8)return class_259.method_1073();
        if(anchorShape==null)anchorShape=PreciseCollisionEntity.createShape(anchorMask);
        return anchorShape;
    }
    public void setAnchorCollisionMask(long[] data){
        if(data!=null&&data.length!=0&&data.length!=8)
            throw new IllegalArgumentException("Masque ancre invalide");
        anchorMask=data==null?new long[0]:data.clone();anchorShape=null;method_5431();
        if(field_11863 instanceof net.minecraft.class_3218 server)
            server.method_14178().method_14128(field_11867);
    }

    public long[] collisionCells(){return collisionCells.clone();}
    public void setCollisionCells(long[] cells){collisionCells=cells.clone();method_5431();}
    public PreciseDisplayEntity(class_2338 pos,class_2680 state){super(BrickCraft.PRECISE_ENTITY,pos,state);}
    public PreciseWorldModel model(){
        if(model==null && packed.length>0 && !decodeAttempted){
            decodeAttempted=true;
            try{model=PreciseWorldModel.readBytes(packed);}catch(IOException ignored){}
        }
        return model;
    }
    public void setModel(PreciseWorldModel value)throws IOException{
        byte[] bytes=value.writeBytes();
        this.model=value;this.packed=bytes;this.decodeAttempted=true;method_5431();
        if(field_11863 instanceof net.minecraft.class_3218 server)server.method_14178().method_14128(field_11867);
    }
    @Override protected void method_11007(class_2487 nbt,class_7225.class_7874 registry){
        super.method_11007(nbt,registry);
        nbt.method_10570("BrickCraftPreciseV1",packed);
        nbt.method_10564("BrickCraftPhysicsCells",collisionCells);
        if(anchorMask.length==8)nbt.method_10564("BrickCraftAnchorMicroVoxels",anchorMask);
    }
    @Override public void method_11014(class_2487 nbt,class_7225.class_7874 registry){
        super.method_11014(nbt,registry);
        packed=nbt.method_10547("BrickCraftPreciseV1");model=null;decodeAttempted=false;
        collisionCells=nbt.method_10565("BrickCraftPhysicsCells");
        long[] loadedMask=nbt.method_10565("BrickCraftAnchorMicroVoxels");
        anchorMask=loadedMask.length==8?loadedMask:new long[0];anchorShape=null;
        // Preserve corrupted/missing-library data in NBT instead of silently deleting it.
        if(packed.length>0)model();
    }
    @Override public @Nullable class_2596<class_2602> method_38235(){
        return class_2622.method_38585(this);
    }
    @Override public class_2487 method_16887(class_7225.class_7874 registry){
        return method_38244(registry);
    }
}
