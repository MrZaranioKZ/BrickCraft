package fr.brickcraft.world;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

/** One removable marker anchor for an entire lossless, NON-COLLIDING LDraw world projection. */
public final class PreciseDisplayBlock extends class_2237 {
    public static final MapCodec<PreciseDisplayBlock> CODEC=method_54094(PreciseDisplayBlock::new);
    public PreciseDisplayBlock(class_2251 settings){super(settings);}
    @Override protected MapCodec<? extends class_2237> method_53969(){return field_46280;}
    @Override protected class_2464 method_9604(class_2680 state){return class_2464.field_11458;}
    @Override public @Nullable class_2586 method_10123(class_2338 pos,class_2680 state){
        return new PreciseDisplayEntity(pos,state);
    }
    @Override protected void method_9536(class_2680 state,class_1937 world,class_2338 pos,class_2680 newState,boolean moved){
        if(!state.method_27852(newState.method_26204()) && world instanceof class_3218 server &&
                world.method_8321(pos) instanceof PreciseDisplayEntity entity)
            PrecisePhysicsManager.cleanup(server,entity);
        super.method_9536(state,world,pos,newState,moved);
    }
    // The underlying marker can be mined normally to remove the entire projection.
    @Override protected class_265 method_9530(class_2680 state,class_1922 world,class_2338 pos,class_3726 ctx){
        return class_259.method_1081(.3,0,.3,.7,.35,.7);
    }
    @Override protected class_265 method_9549(class_2680 state,class_1922 world,class_2338 pos,class_3726 ctx){
        return class_259.method_1073();
    }
}
