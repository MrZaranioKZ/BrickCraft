package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PrecisePhysicsPayload;
import fr.brickcraft.world.PreciseCollisionPlan.Cell;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.Map.Entry;

/** Conservative optional FULL VOXEL physics. Mutates only AIR, never overwrites existing terrain.
 * Every intended cell is registered on the anchor BEFORE placement, so cleanup can be retried. */
public final class PrecisePhysicsManager {
    private PrecisePhysicsManager(){}
    private record Job(class_3218 world,class_2338 anchor,class_3222 player,long[] cells,boolean enable,int next){}
    private static final Map<String,Job> JOBS=new LinkedHashMap<>();
    private static String key(class_3218 world,class_2338 pos){return world.method_27983().method_29177()+":"+pos.method_10063();}
    private static void say(class_3222 p,String msg){if(p!=null)p.method_7353(class_2561.method_43470("BrickCraft physique : "+msg),false);}
    public static void receive(class_3222 player,PrecisePhysicsPayload data){
        class_3218 world=player.method_51469();class_2338 anchor=data.anchor();
        if(!player.method_7337()||player.method_7325()||player.method_5649(anchor.method_10263()+.5,anchor.method_10264()+.5,anchor.method_10260()+.5)>192*192||
           !world.method_22340(anchor)||!world.method_8505(player,anchor)||
           !(world.method_8321(anchor) instanceof PreciseDisplayEntity be)||be.model()==null){
            say(player,"refuse : mode creatif, permissions et ancre chargee requis");return;
        }
        if(data.enable()){
            try{
                if(be.collisionCells().length>0){
                    long[] saved=be.collisionCells();
                    JOBS.put(key(world,anchor),new Job(world,anchor,player,saved,true,0));
                    say(player,"reprise de l'activation : "+saved.length+" cellules suivies");return;
                }
                var model=be.model();
                var cells=PreciseCollisionPlan.build(model.parts(),model.minX(),model.minY(),model.minZ(),
                        anchor.method_10263(),anchor.method_10264(),anchor.method_10260(),id->{
                            String ref=PreciseReferenceMapper.geometryId(id);
                            return ref==null?null:LDrawLibrary.originalBounds(ref);
                        });
                java.util.ArrayList<Long> targets=new java.util.ArrayList<>();int solid=0;
                for(var c:cells){
                    class_2338 pos=new class_2338(c.x(),c.y(),c.z());
                    if(!world.method_24794(pos)||!world.method_22340(pos)||!world.method_8505(player,pos))
                        throw new IllegalArgumentException("zone non chargee ou protegee : "+pos.method_23854());
                    if(world.method_8320(pos).method_26215())targets.add(pos.method_10063());
                    else if(world.method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                        throw new IllegalArgumentException("collision avec une autre projection");
                    else solid++; // Existing terrain already has a physical collision; do not touch it.
                }
                long[] values=targets.stream().mapToLong(Long::longValue).toArray();
                if(values.length==0){say(player,"aucune cellule libre necessaire (terrain existant)");return;}
                be.setCollisionCells(values); // persisted ownership BEFORE generating proxy blocks
                JOBS.put(key(world,anchor),new Job(world,anchor,player,values,true,0));
                say(player,"activation progressive : "+values.length+" cellules, "+solid+" deja occupees par le terrain");
            }catch(Exception e){say(player,"refuse sans modifier le terrain : "+e.getMessage());}
        }else{
            long[] existing=be.collisionCells();
            if(existing.length==0){say(player,"aucune collision a retirer");return;}
            JOBS.put(key(world,anchor),new Job(world,anchor,player,existing,false,0));
            say(player,"retrait progressif de "+existing.length+" cellules");
        }
    }
    public static void tick(MinecraftServer server){
        var iter=JOBS.entrySet().iterator();int budget=128;
        while(iter.hasNext()&&budget>0){
            var entry=iter.next();Job job=entry.getValue();
            if(job.world().method_8321(job.anchor()) instanceof PreciseDisplayEntity be){
                int i=job.next();
                while(i<job.cells().length && budget>0){
                    class_2338 pos=class_2338.method_10092(job.cells()[i]);
                    if(job.world().method_22340(pos)){
                        if(job.enable()){
                            if(job.world().method_8320(pos).method_26215())
                                job.world().method_8652(pos,BrickCraft.PRECISE_COLLISION.method_9564(),3);
                        }else if(job.world().method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                            job.world().method_8652(pos,class_2246.field_10124.method_9564(),3);
                    }
                    i++;budget--;
                }
                if(i>=job.cells().length){
                    if(!job.enable())be.setCollisionCells(new long[0]);
                    say(job.player(),(job.enable()?"activee":"retiree")+" : "+job.cells().length+" cellules traitees");
                    iter.remove();
                }else entry.setValue(new Job(job.world(),job.anchor(),job.player(),job.cells(),job.enable(),i));
            }else{iter.remove();} // Anchor removed: onStateReplaced has already run cleanup.
        }
    }
    /** Invoked only by anchor removal. Never removes unrelated Minecraft blocks. */
    public static void cleanup(class_3218 world,PreciseDisplayEntity be){
        JOBS.remove(key(world,be.method_11016()));
        for(long key:be.collisionCells()){
            class_2338 pos=class_2338.method_10092(key);
            if(world.method_22340(pos)&&world.method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                world.method_8652(pos,class_2246.field_10124.method_9564(),3);
        }
        be.setCollisionCells(new long[0]);
    }
}
