package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.net.PreciseManagePayload;
import fr.brickcraft.net.PreciseManageStatusPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** List loaded, nearby projection anchors. Remove only the exact selected anchor. */
public final class PreciseManageManager {
    private PreciseManageManager(){}
    private static void reply(class_3222 p,byte event,String message,List<PreciseManageStatusPayload.Entry> projects){
        ServerPlayNetworking.send(p,new PreciseManageStatusPayload(event,projects,message));
    }
    public static void receive(class_3222 player,PreciseManagePayload request){
        if(!player.method_7337()||player.method_7325()){
            reply(player,PreciseManageStatusPayload.ERROR,"Mode Creatif requis.",List.of());return;
        }
        if(request.operation()==PreciseManagePayload.LIST){list(player);return;}
        if(request.operation()==PreciseManagePayload.REMOVE){remove(player,request.anchor());return;}
        reply(player,PreciseManageStatusPayload.ERROR,"Operation inconnue.",List.of());
    }
    private static void list(class_3222 player){
        class_3218 world=player.method_51469();class_2338 base=player.method_24515();
        int cX=base.method_10263()>>4,cZ=base.method_10260()>>4;
        int sections=(PreciseManageRules.RADIUS+15)/16;
        ArrayList<PreciseManageStatusPayload.Entry> entries=new ArrayList<>();
        // isChunkLoaded is checked BEFORE getChunk; listing must never generate terrain.
        for(int x=cX-sections;x<=cX+sections;x++)for(int z=cZ-sections;z<=cZ+sections;z++){
            class_2338 probe=new class_2338(x<<4,base.method_10264(),z<<4);
            if(!world.method_22340(probe))continue;
            for(var be:world.method_8497(x,z).method_12214().values()){
                if(!(be instanceof PreciseDisplayEntity anchor))continue;
                class_2338 pos=anchor.method_11016();
                if(!PreciseManageRules.inRange(player.method_23317(),player.method_23318(),player.method_23321(),
                        pos.method_10263(),pos.method_10264(),pos.method_10260()))continue;
                if(!world.method_8320(pos).method_27852(BrickCraft.PRECISE_DISPLAY))continue;
                var model=anchor.model();
                entries.add(new PreciseManageStatusPayload.Entry(pos.method_10062(),
                        model==null?0:model.parts().size()));
            }
        }
        entries.sort(Comparator.comparingDouble(p->player.method_5649(
                p.anchor().method_10263()+.5,p.anchor().method_10264()+.5,p.anchor().method_10260()+.5)));
        if(entries.size()>PreciseManageStatusPayload.LIMIT)
            entries.subList(PreciseManageStatusPayload.LIMIT,entries.size()).clear();
        reply(player,PreciseManageStatusPayload.LIST,
                "Projections proches et chargees : "+entries.size(),entries);
    }
    private static void remove(class_3222 player,class_2338 pos){
        class_3218 world=player.method_51469();
        if(!PreciseManageRules.inRange(player.method_23317(),player.method_23318(),player.method_23321(),pos.method_10263(),pos.method_10264(),pos.method_10260())
                || !world.method_22340(pos) || !world.method_24794(pos)
                || !world.method_8505(player,pos)
                || !world.method_8320(pos).method_27852(BrickCraft.PRECISE_DISPLAY)
                || !(world.method_8321(pos) instanceof PreciseDisplayEntity)){
            reply(player,PreciseManageStatusPayload.ERROR,
                    "Retrait refuse : ancre absente, trop loin ou sans permission.",List.of());return;
        }
        if(world.method_8321(pos) instanceof PreciseDisplayEntity anchor && anchor.collisionCells().length>0){
            reply(player,PreciseManageStatusPayload.ERROR,
                    "Desactive la physique avant de retirer cette projection.",List.of());return;
        }
        // The projection consists of exactly one marker block and its compressed model.
        // No LEGO cells, other blocks or .io/.bcpx files are modified.
        if(!world.method_8652(pos,class_2246.field_10124.method_9564(),3)){
            reply(player,PreciseManageStatusPayload.ERROR,"Impossible de retirer l'ancre.",List.of());return;
        }
        reply(player,PreciseManageStatusPayload.REMOVED,
                "Projection retiree en "+pos.method_23854()+". Fichiers intacts.",
                List.of(new PreciseManageStatusPayload.Entry(pos,0)));
    }
}
