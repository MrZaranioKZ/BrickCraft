package fr.brickcraft.world;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

/** Invisible but solid voxel, created ONLY by a confirmed physics operation. No item is registered. */
public final class PreciseCollisionBlock extends class_2248 {
    public PreciseCollisionBlock(class_2251 settings){super(settings);}
    @Override protected class_2464 method_9604(class_2680 state){return class_2464.field_11455;}
    @Override protected class_265 method_9530(class_2680 state,class_1922 world,class_2338 pos,class_3726 ctx){
        return class_259.method_1073(); // Do not interfere with the regular LEGO picker or block selection.
    }
    @Override protected class_265 method_9549(class_2680 state,class_1922 world,class_2338 pos,class_3726 ctx){
        return class_259.method_1077();
    }
}
