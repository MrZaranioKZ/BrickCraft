package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Compact responsive two-panel editor, with a clipped isometric viewport. */
public final class BrickStudioScreen extends class_437 {
    private static final List<BrickPiece> ASSEMBLY = new ArrayList<>();
    private static final int GRID = 12;
    private final class_2338 target;
    private int cursorX = 0, cursorZ = 0;
    private float orbit=.72f;
    private float zoom=1f;
    private String status="Clic gauche : poser | clic droit-glisse : camera";
    private int leftW,rightW,viewLeft,viewRight;

    public BrickStudioScreen(class_2338 target) {
        super(class_2561.method_43470("BrickCraft Studio - V0.2"));
        this.target=target;
    }

    private void updateLayout() {
        leftW=Math.min(190,Math.max(140,field_22789/4));
        rightW=Math.min(176,Math.max(145,field_22789/5));
        viewLeft=leftW+8;
        viewRight=field_22789-rightW-8;
    }

    @Override protected void method_25426() {
        updateLayout();
        int colGap=5, x=12;
        int buttonW=(leftW-28-colGap)/2;
        BrickKind[] kinds=BrickKind.values();
        for(int i=0;i<kinds.length;i++) {
            final BrickKind kind=kinds[i];
            int row=i/2,col=i%2;
            button(x+col*(buttonW+colGap),52+row*27,buttonW,23,
                kind.title.replace("Brique ","B ").replace("Plaque ","P ").replace("Tuile ","T "),
                () -> {BrickSelection.kind=kind;status="Piece : "+kind.title;});
        }
        int right=field_22789-rightW+7;
        int bw=(rightW-24)/2;
        button(right,52,bw,22,"X -",()->cursorX=Math.max(0,cursorX-1));
        button(right+bw+5,52,bw,22,"X +",()->cursorX=Math.min(GRID-1,cursorX+1));
        button(right,80,bw,22,"Z -",()->cursorZ=Math.max(0,cursorZ-1));
        button(right+bw+5,80,bw,22,"Z +",()->cursorZ=Math.min(GRID-1,cursorZ+1));
        button(right,108,bw,22,"H -",()->BrickSelection.layer=Math.max(0,BrickSelection.layer-1));
        button(right+bw+5,108,bw,22,"H +",()->BrickSelection.layer=Math.min(30,BrickSelection.layer+1));
        button(right,136,bw,22,"Tourner",()->BrickSelection.turn=(BrickSelection.turn+1)&3);
        button(right+bw+5,136,bw,22,"Camera",()->orbit+=.45f);
        button(right,172,rightW-19,22,"Ajouter une piece",this::add);
        button(right,201,rightW-19,22,"Annuler dernier",()->{
            if(!ASSEMBLY.isEmpty()) {ASSEMBLY.remove(ASSEMBLY.size()-1);status="Dernier ajout annule";}
        });
        button(right,230,rightW-19,22,"Vider l'atelier",()->{ASSEMBLY.clear();status="Atelier vide";});
        button(right,266,rightW-19,26,"Construire en jeu",this::applyToWorld);
        button(right,299,rightW-19,22,"Fermer",this::method_25419);
    }

    private void button(int x,int y,int w,int h,String text,Runnable action) {
        method_37063(class_4185.method_46430(class_2561.method_43470(text),b->action.run())
                .method_46434(x,y,w,h).method_46431());
    }

    private void add() {
        BrickPiece p=BrickSelection.piece(cursorX,cursorZ);
        if(!p.valid() || p.x()+p.width()>GRID || p.z()+p.length()>GRID || p.top()>66) {
            status="Piece hors du plateau (12 x 12 / 33 plaques)";return;
        }
        if(ASSEMBLY.size()>=256) {status="Limite atelier : 256 pieces";return;}
        for(BrickPiece old:ASSEMBLY) if(p.intersects(old)) {
            status="Collision : emplacement occupe";return;
        }
        ASSEMBLY.add(p);
        status="Ajout : "+p.kind().title+" / total "+ASSEMBLY.size();
    }

    private void applyToWorld() {
        if(field_22787==null || field_22787.field_1724==null || !field_22787.field_1724.method_6047().method_31574(BrickCraft.TOOL)) {
            status="Garde l'outil BrickCraft en main";return;
        }
        if(target==null) {status="Vise le sol avant d'ouvrir le Studio";return;}
        if(ASSEMBLY.isEmpty()) {status="Ajoute au moins une piece";return;}
        for(BrickPiece local:ASSEMBLY) {
            ClientPlayNetworking.send(new BrickActionPayload(target,class_2350.field_11036,.5f,.5f,.5f,
                false,true,local));
        }
        status=ASSEMBLY.size()+" placements envoyes (le serveur peut refuser les collisions)";
    }

    @Override public void method_25394(class_332 ctx,int mouseX,int mouseY,float delta) {
        updateLayout();
        int bottom=field_22790-31;
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B1019);
        ctx.method_25294(4,35,leftW,bottom,0xFF1A2531);
        ctx.method_25294(viewLeft-2,35,viewRight+2,bottom,0xFF0E1925);
        ctx.method_25294(field_22789-rightW,35,field_22789-4,bottom,0xFF1A2531);
        ctx.method_25303(field_22793,"BRICKCRAFT / STUDIO 0.2",12,13,0xFFE8F4FE);
        ctx.method_25303(field_22793,"PIECES",12,39,0xFF99CADB);
        ctx.method_25303(field_22793,"CONTROLES",field_22789-rightW+8,39,0xFF99CADB);
        ctx.method_25303(field_22793,"Selection",12,143,0xFFA5B8C7);
        ctx.method_25303(field_22793,BrickSelection.kind.title,12,158,0xFFFFFFFF);
        ctx.method_25303(field_22793,"Rotation : "+BrickSelection.turn*90+" deg",12,174,0xFFB7CFDF);
        ctx.method_25303(field_22793,"Hauteur : "+BrickSelection.layer+" plaques",12,189,0xFFB7CFDF);
        ctx.method_25303(field_22793,"COULEURS",12,211,0xFF99CADB);
        int swatch=Math.max(15,(leftW-27)/8);
        for(int i=0;i<BrickPalette.COLORS.length;i++) {
            int px=12+(i%8)*swatch,py=230+(i/8)*(swatch+3);
            int border=BrickSelection.rgb==BrickPalette.COLORS[i]?0xFFFFFFFF:0xFF47576B;
            ctx.method_25294(px-1,py-1,px+swatch-2,py+swatch-2,border);
            ctx.method_25294(px+1,py+1,px+swatch-4,py+swatch-4,0xFF000000|BrickPalette.COLORS[i]);
        }
        ctx.method_25303(field_22793,"#"+String.format("%06X",BrickSelection.rgb),12,282,0xFFDDEBF4);
        ctx.method_25303(field_22793,"1 tenon = 1 bloc MC",12,305,0xFF9EC4D2);
        ctx.method_25303(field_22793,"Brique : 1.2 bloc",12,319,0xFF9EC4D2);
        ctx.method_25303(field_22793,"Plaque : 0.4 bloc",12,333,0xFF9EC4D2);
        ctx.method_25303(field_22793,"Pieces : "+ASSEMBLY.size(),12,355,0xFFFFFFFF);

        ctx.method_25303(field_22793,"X="+cursorX+" Z="+cursorZ+" H="+BrickSelection.layer,
                field_22789-rightW+8,337,0xFFBDD8EA);
        if(target!=null) ctx.method_25303(field_22793,"Ancre : "+target.method_23854(),
                field_22789-rightW+8,356,0xFF86CEDD);
        ctx.method_25303(field_22793,"Gauche : pose | droit : orbite",viewLeft+7,44,0xFFACCADB);
        ctx.method_25303(field_22793,"Molette : zoom / Q E : camera",viewLeft+7,58,0xFF97AEBC);
        ctx.method_44379(viewLeft,77,viewRight,bottom-2);
        renderViewport(ctx);
        ctx.method_44380();
        ctx.method_25294(0,bottom,field_22789,field_22790,0xFF20303E);
        ctx.method_25303(field_22793,status,12,bottom+10,0xFFF2D8A0);
        super.method_25394(ctx,mouseX,mouseY,delta);
    }

    private int centerX() {return (viewLeft+viewRight)/2;}
    private int centerY() {return (77+field_22790-33)/2+14;}
    private float baseZoom() {return Math.max(8f,Math.min((viewRight-viewLeft)/17f,(field_22790-113)/14f))*zoom;}
    private record P(int x,int y) {}
    private P project(float x,float y,float z) {
        float units=baseZoom();
        double u=(x-GRID/2f)*Math.cos(orbit)-(z-GRID/2f)*Math.sin(orbit);
        double d=(x-GRID/2f)*Math.sin(orbit)+(z-GRID/2f)*Math.cos(orbit);
        return new P((int)(centerX()+u*units),(int)(centerY()+d*units*.45f-y*units*.9f));
    }
    private double depth(float x,float z) {return x*Math.sin(orbit)+z*Math.cos(orbit);}

    private void renderViewport(class_332 ctx) {
        for(int k=0;k<=GRID;k++) {
            line(ctx,project(k,0,0),project(k,0,GRID),0xFF2F5465);
            line(ctx,project(0,0,k),project(GRID,0,k),0xFF2F5465);
        }
        List<BrickPiece> ordered=new ArrayList<>(ASSEMBLY);
        ordered.sort(Comparator.comparingDouble(p->depth(p.x()+p.width()/2f,p.z()+p.length()/2f)+p.y()*.04));
        for(BrickPiece p:ordered) drawBrick(ctx,p,false);
        BrickPiece ghost=BrickSelection.piece(cursorX,cursorZ);
        if(ghost.x()+ghost.width()<=GRID && ghost.z()+ghost.length()<=GRID) drawBrick(ctx,ghost,true);
    }

    private void drawBrick(class_332 ctx,BrickPiece p,boolean ghost) {
        float x=p.x(),z=p.z(),y=p.y()/5f,w=p.width(),d=p.length(),h=p.height()/5f;
        P a=project(x,y,z),b=project(x+w,y,z),c=project(x+w,y,z+d),e=project(x,y,z+d);
        P A=project(x,y+h,z),B=project(x+w,y+h,z),C=project(x+w,y+h,z+d),E=project(x,y+h,z+d);
        int alpha=ghost?100:255,rgb=p.rgb();
        face(ctx,new P[]{a,b,B,A},shade(rgb,.68,alpha));
        face(ctx,new P[]{b,c,C,B},shade(rgb,.75,alpha));
        face(ctx,new P[]{c,e,E,C},shade(rgb,.84,alpha));
        face(ctx,new P[]{e,a,A,E},shade(rgb,.64,alpha));
        face(ctx,new P[]{A,B,C,E},shade(rgb,1.12,alpha));
        if(p.kind().studs) {
            for(int i=0;i<p.width();i++) for(int j=0;j<p.length();j++) {
                P stud=project(x+i+.5f,y+h+.09f,z+j+.5f);
                int radius=Math.max(2,(int)(baseZoom()*.11f));
                ctx.method_25294(stud.x-radius,stud.y-radius,stud.x+radius,stud.y+radius,shade(rgb,1.32,alpha));
            }
        }
    }
    private static int shade(int rgb,double factor,int alpha) {
        int r=Math.min(255,(int)(((rgb>>16)&255)*factor));
        int g=Math.min(255,(int)(((rgb>>8)&255)*factor));
        int b=Math.min(255,(int)((rgb&255)*factor));
        return (alpha<<24)|(r<<16)|(g<<8)|b;
    }
    private static void line(class_332 ctx,P a,P b,int color) {
        int dx=Math.abs(b.x-a.x),dy=Math.abs(b.y-a.y);
        int sx=a.x<b.x?1:-1,sy=a.y<b.y?1:-1,err=dx-dy,x=a.x,y=a.y;
        while(true) {
            ctx.method_25294(x,y,x+1,y+1,color);
            if(x==b.x && y==b.y)break;
            int e2=2*err;
            if(e2>-dy) {err-=dy;x+=sx;}
            if(e2<dx) {err+=dx;y+=sy;}
        }
    }
    private static void face(class_332 ctx,P[] pts,int color) {
        int ymin=Integer.MAX_VALUE,ymax=Integer.MIN_VALUE;
        for(P p:pts) {ymin=Math.min(ymin,p.y);ymax=Math.max(ymax,p.y);}
        ymin=Math.max(0,ymin);ymax=Math.min(ctx.method_51443()-1,ymax);
        for(int y=ymin;y<=ymax;y++) {
            float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;
            for(int i=0;i<pts.length;i++) {
                P a=pts[i],b=pts[(i+1)%pts.length];
                if(a.y==b.y || y<Math.min(a.y,b.y) || y>=Math.max(a.y,b.y))continue;
                float xx=a.x+(float)(y-a.y)*(b.x-a.x)/(b.y-a.y);
                min=Math.min(min,xx);max=Math.max(max,xx);
            }
            if(max>=min)ctx.method_25294((int)Math.floor(min),y,(int)Math.ceil(max)+1,y+1,color);
        }
    }
    @Override public boolean method_25402(double mx,double my,int button) {
        int swatch=Math.max(15,(leftW-27)/8);
        if(button==0 && mx>=11 && mx<12+8*swatch && my>=229 && my<230+2*(swatch+3)) {
            int col=((int)mx-12)/swatch,row=((int)my-230)/(swatch+3),idx=row*8+col;
            if(col>=0 && col<8 && row>=0 && row<2 && idx<BrickPalette.COLORS.length) {
                BrickSelection.rgb=BrickPalette.COLORS[idx];status="Couleur : "+BrickPalette.NAMES[idx];return true;
            }
        }
        if(button==0 && mx>=viewLeft && mx<viewRight && my>77 && my<field_22790-33) {
            float s=baseZoom();
            double u=(mx-centerX())/s;
            double d=(my-centerY()+(BrickSelection.layer*2f/5f)*s*.9)/(.45*s);
            int gx=(int)Math.floor(u*Math.cos(orbit)+d*Math.sin(orbit)+GRID/2f);
            int gz=(int)Math.floor(-u*Math.sin(orbit)+d*Math.cos(orbit)+GRID/2f);
            cursorX=Math.clamp(gx,0,GRID-1);cursorZ=Math.clamp(gz,0,GRID-1);
            add();return true;
        }
        return super.method_25402(mx,my,button);
    }
    @Override public boolean method_25403(double mx,double my,int button,double dx,double dy) {
        if(button==1 && mx>=viewLeft && mx<viewRight) {orbit+=(float)dx*.013f;return true;}
        return super.method_25403(mx,my,button,dx,dy);
    }
    @Override public boolean method_25401(double mx,double my,double horizontal,double vertical) {
        if(mx>=viewLeft && mx<viewRight) {zoom=Math.clamp(zoom+(float)vertical*.10f,.4f,2.4f);return true;}
        return super.method_25401(mx,my,horizontal,vertical);
    }
    @Override public boolean method_25404(int key,int scan,int mods) {
        if(key==GLFW.GLFW_KEY_Q) {orbit-=.2f;return true;}
        if(key==GLFW.GLFW_KEY_E) {orbit+=.2f;return true;}
        if(key==GLFW.GLFW_KEY_R) {BrickSelection.turn=(BrickSelection.turn+1)&3;return true;}
        if(key==GLFW.GLFW_KEY_DELETE && !ASSEMBLY.isEmpty()) {ASSEMBLY.remove(ASSEMBLY.size()-1);return true;}
        return super.method_25404(key,scan,mods);
    }
    @Override public boolean method_25421() {return false;}
}
