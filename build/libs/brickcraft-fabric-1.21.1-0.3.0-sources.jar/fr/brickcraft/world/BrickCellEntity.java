package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import org.jetbrains.annotations.Nullable;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7225;

/** A 'fragment' cell: stores references to all complete world-space pieces crossing it. */
public final class BrickCellEntity extends class_2586 {
    public static final int MAX_PIECES = 48;
    private final ArrayList<BrickPiece> pieces = new ArrayList<>();

    public BrickCellEntity(class_2338 pos, class_2680 state) { super(BrickCraft.CELL_ENTITY, pos, state); }
    public List<BrickPiece> pieces() { return List.copyOf(pieces); }

    public boolean canAdd(BrickPiece candidate) {
        if (pieces.size() >= MAX_PIECES) return false;
        for (BrickPiece old : pieces) if (old.intersects(candidate)) return false;
        return true;
    }

    public boolean add(BrickPiece piece) {
        if (!piece.occupiedCells().contains(field_11867) || !canAdd(piece)) return false;
        pieces.add(piece); sync(); return true;
    }

    public boolean remove(BrickPiece piece) {
        if (!pieces.remove(piece)) return false;
        sync(); return true;
    }

    /** For the top of the visible LEGO under the cursor; allows exact LEGO layer stacking. */
    public BrickPiece topmost() {
        BrickPiece chosen = null;
        for (BrickPiece p : pieces) {
            if (chosen == null || p.top() > chosen.top()) chosen = p;
        }
        return chosen;
    }

    /** Find the piece actually clicked at a Y coordinate, not simply the highest piece in the cell. */
    public BrickPiece pickAt(double worldY, boolean topFace) {
        BrickPiece selected = null;
        double best = Double.POSITIVE_INFINITY;
        for (BrickPiece p : pieces) {
            double low = p.y()/5.0, high=(p.top()+(p.kind().studs?1:0))/5.0;
            double distance = topFace ? Math.abs(worldY-high) :
                    (worldY>=low-.03 && worldY<=high+.03 ? 0 : Math.min(Math.abs(worldY-low),Math.abs(worldY-high)));
            if (distance<best || (distance==best && selected!=null && p.top()>selected.top())) {
                best=distance; selected=p;
            }
        }
        return selected;
    }

    private void sync() {
        method_5431();
        if (field_11863 instanceof class_3218 serverWorld) serverWorld.method_14178().method_14128(field_11867);
    }

    @Override protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        class_2499 items = new class_2499();
        for (BrickPiece p : pieces) {
            class_2487 v = new class_2487();
            v.method_10582("Kind", p.kind().name());
            v.method_10569("RGB", p.rgb()); v.method_10569("X", p.x()); v.method_10569("Y", p.y());
            v.method_10569("Z", p.z()); v.method_10569("Turn", p.turn()); v.method_10569("Angle",p.angle());
            items.add(v);
        }
        nbt.method_10566("PiecesV2", items);
    }

    @Override public void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        pieces.clear();
        class_2499 items = nbt.method_10554("PiecesV2", class_2520.field_33260);
        // Previous V0.1 format intentionally not migrated: its geometry uses a different scale.
        for (int i=0; i<items.size() && pieces.size()<MAX_PIECES; i++) {
            class_2487 v = items.method_10602(i);
            try {
                BrickPiece p = new BrickPiece(BrickKind.valueOf(v.method_10558("Kind")),
                    v.method_10550("RGB") & 0xFFFFFF, v.method_10550("X"), v.method_10550("Y"),
                    v.method_10550("Z"), v.method_10550("Turn"),
                    v.method_10573("Angle", class_2520.field_33263) ? v.method_10550("Angle") : v.method_10550("Turn")*90);
                if (p.valid() && p.occupiedCells().contains(field_11867) && canAdd(p)) pieces.add(p);
            } catch (IllegalArgumentException ignored) { }
        }
    }

    @Override public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
    @Override public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }
}
