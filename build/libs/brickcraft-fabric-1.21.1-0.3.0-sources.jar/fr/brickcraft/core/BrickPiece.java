package fr.brickcraft.core;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;

/**
 * World coordinates: X/Z one stud = one Minecraft block; Y is fifths of a block.
 * A 3-plate brick is 1.2 blocks tall. Angle is degrees clockwise in X/Z world plane.
 * Rotation is around the footprint center, x/z remain the SW corner of its bounding box.
 * 'turn' is retained only to load older 0.2.x saves and their network model.
 */
public record BrickPiece(BrickKind kind,int rgb,int x,int y,int z,int turn,int angle) {
    private static final double EPS=1e-8;

    /** Legacy constructor: supports all existing V0.2.x saved pieces unchanged. */
    public BrickPiece(BrickKind kind,int rgb,int x,int y,int z,int turn) {
        this(kind,rgb,x,y,z,turn,Math.floorMod(turn,4)*90);
    }

    public static BrickPiece atAngle(BrickKind kind,int rgb,int x,int y,int z,int angle) {
        int a=Math.floorMod(angle,360);
        return new BrickPiece(kind,rgb,x,y,z,a/90,a);
    }

    public BrickPiece withAngle(int degrees) {return atAngle(kind,rgb,x,y,z,degrees);}
    public BrickPiece withColor(int color) {return new BrickPiece(kind,color,x,y,z,turn,angle);}

    private double cosine() {return Math.abs(angle%90)==0 ? switch(angle) {
        case 0 -> 1; case 90,270 -> 0; case 180 -> -1; default -> Math.cos(Math.toRadians(angle));
    } : Math.cos(Math.toRadians(angle));}
    private double sine() {return angle%90==0 ? switch(angle) {
        case 0,180 -> 0; case 90 -> 1; case 270 -> -1; default -> Math.sin(Math.toRadians(angle));
    } : Math.sin(Math.toRadians(angle));}
    public int width() {
        if (angle%90==0) return kind.width(angle/90);
        return (int)Math.ceil(Math.abs(kind.width*cosine())+Math.abs(kind.length*sine())-EPS);
    }
    public int length() {
        if (angle%90==0) return kind.length(angle/90);
        return (int)Math.ceil(Math.abs(kind.width*sine())+Math.abs(kind.length*cosine())-EPS);
    }
    public int height() {return kind.plates*2;}
    public int top() {return y+height();}
    public boolean valid() {
        return kind!=null && turn>=0 && turn<4 && angle>=0 && angle<360 &&
                x>=-29_999_980 && x<=29_999_980 && z>=-29_999_980 && z<=29_999_980 &&
                y>=-2000 && y<=10000 && (rgb&0xFF000000)==0;
    }

    /** Four corners in XZ, with consistent winding and exact world coordinates. */
    public double[][] corners() {
        double w=kind.width,l=kind.length,c=cosine(),s=sine();
        double midX=x+width()/2.,midZ=z+length()/2.;
        double[][] offsets={{-w/2,-l/2},{w/2,-l/2},{w/2,l/2},{-w/2,l/2}};
        double[][] result=new double[4][2];
        for(int i=0;i<4;i++) {
            double dx=offsets[i][0], dz=offsets[i][1];
            result[i][0]=midX+dx*c-dz*s;
            result[i][1]=midZ+dx*s+dz*c;
        }
        return result;
    }

    /** Stud centers after applying the same rotation as the plastic body. */
    public double[] stud(int ix,int iz) {
        double dx=ix+.5-kind.width/2.,dz=iz+.5-kind.length/2.;
        return new double[]{x+width()/2.+dx*cosine()-dz*sine(),
                z+length()/2.+dx*sine()+dz*cosine()};
    }

    private static boolean positiveOverlap(double[][] a,double[][] b) {
        for (int shape=0;shape<2;shape++) {
            double[][] p=(shape==0?a:b);
            for (int i=0;i<p.length;i++) {
                double dx=p[(i+1)%p.length][0]-p[i][0];
                double dz=p[(i+1)%p.length][1]-p[i][1];
                double ax=-dz,az=dx;
                double amin=Double.POSITIVE_INFINITY,amax=Double.NEGATIVE_INFINITY;
                double bmin=Double.POSITIVE_INFINITY,bmax=Double.NEGATIVE_INFINITY;
                for (double[] v:a) {double proj=v[0]*ax+v[1]*az;amin=Math.min(amin,proj);amax=Math.max(amax,proj);}
                for (double[] v:b) {double proj=v[0]*ax+v[1]*az;bmin=Math.min(bmin,proj);bmax=Math.max(bmax,proj);}
                if (amax<=bmin+EPS || bmax<=amin+EPS) return false;
            }
        }
        return true;
    }

    public boolean horizontalOverlaps(BrickPiece other) {
        if (x>=other.x+other.width() || x+width()<=other.x ||
                z>=other.z+other.length() || z+length()<=other.z) return false;
        return positiveOverlap(corners(),other.corners());
    }

    /** Only the brick body intersects. Studs overlap receiving undersides by design. */
    public boolean intersects(BrickPiece other) {
        return y<other.top() && top()>other.y && horizontalOverlaps(other);
    }

    private boolean intersectsSquare(int sx,int sz,double[][] polygon) {
        double[][] square={{sx,sz},{sx+1,sz},{sx+1,sz+1},{sx,sz+1}};
        return positiveOverlap(polygon,square);
    }

    /** Cell fragments are tracked per Minecraft block for persistence and interaction. */
    public List<class_2338> occupiedCells() {
        List<class_2338> result=new ArrayList<>();
        int yStart=Math.floorDiv(y,5);
        int yEnd=Math.floorDiv(top()+(kind.studs?1:0)-1,5);
        boolean square=angle%90==0;
        double[][] poly=square?null:corners();
        for(int yy=yStart;yy<=yEnd;yy++)
            for(int xx=x;xx<x+width();xx++)
                for(int zz=z;zz<z+length();zz++)
                    if (square || intersectsSquare(xx,zz,poly)) result.add(new class_2338(xx,yy,zz));
        return result;
    }

    /** The first occupied cell owns the mesh for angled pieces (avoids drawing duplicates). */
    public class_2338 renderAnchor() {
        int yy=Math.floorDiv(y,5);
        if(angle%90==0)return new class_2338(x,yy,z);
        double[][] polygon=corners();
        for(int xx=x;xx<x+width();xx++)
            for(int zz=z;zz<z+length();zz++)
                if(intersectsSquare(xx,zz,polygon))return new class_2338(xx,yy,zz);
        throw new IllegalStateException("Impossible to find a mesh anchor");
    }
}
