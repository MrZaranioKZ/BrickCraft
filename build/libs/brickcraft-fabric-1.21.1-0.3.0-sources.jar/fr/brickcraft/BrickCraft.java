package fr.brickcraft;

import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.world.BrickPartItem;
import java.util.EnumMap;
import java.util.Map;
import fr.brickcraft.net.BrickActionPayload;
import fr.brickcraft.world.BrickCellBlock;
import fr.brickcraft.world.BrickCellEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import java.util.List;

public final class BrickCraft implements ModInitializer {
    public static final BrickCellBlock CELL = class_2378.method_10230(class_7923.field_41175,
            class_2960.method_60655("brickcraft", "cell"),
            new BrickCellBlock(class_4970.class_2251.method_9637().method_22488().method_9632(.3f)));
    public static final class_1792 TOOL = class_2378.method_10230(class_7923.field_41178,
            class_2960.method_60655("brickcraft", "builder_wand"), new class_1792(new class_1792.class_1793().method_7889(1)));
    public static final Map<BrickKind, BrickPartItem> PART_ITEMS=new EnumMap<>(BrickKind.class);
    static {
        for (BrickKind kind : BrickKind.values()) {
            BrickPartItem item = class_2378.method_10230(class_7923.field_41178,
                    class_2960.method_60655("brickcraft",kind.name().toLowerCase(java.util.Locale.ROOT)),
                    new BrickPartItem(kind,new class_1792.class_1793().method_7889(64)));
            PART_ITEMS.put(kind,item);
        }
    }
    public static final class_2591<BrickCellEntity> CELL_ENTITY = class_2378.method_10230(
            class_7923.field_41181, class_2960.method_60655("brickcraft", "cell"),
            FabricBlockEntityTypeBuilder.create(BrickCellEntity::new, CELL).build());

    @Override public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> entries.method_45421(TOOL));
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            for (BrickKind kind : BrickKind.values()) entries.method_45421(PART_ITEMS.get(kind));
        });
        PayloadTypeRegistry.playC2S().register(BrickActionPayload.ID, BrickActionPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(BrickActionPayload.ID, (packet, context) -> {
            class_3222 player = context.player();
            if (player.method_7325() ||
                    !(player.method_6047().method_31574(TOOL) ||
                      player.method_6047().method_7909() instanceof BrickPartItem)) return;
            handle(player.method_51469(),player,packet);
        });
    }

    private static void handle(class_3218 world, class_3222 player, BrickActionPayload packet) {
        class_2338 hit = packet.hit();
        if (!world.method_24794(hit) || !world.method_22340(hit)
                || player.method_5707(class_243.method_24953(hit)) > 100.0) return;
        if (!world.method_8505(player, hit)) return;
        BrickPiece intent = packet.piece();
        if (intent == null || !intent.valid() ||
                (player.method_6047().method_7909() instanceof BrickPartItem selectedItem
                && selectedItem.kind() != intent.kind()) || !Float.isFinite(packet.localX()) ||
                !Float.isFinite(packet.localY()) || !Float.isFinite(packet.localZ())) return;

        if (packet.remove()) {
            if (world.method_8321(hit) instanceof BrickCellEntity cell) {
                BrickPiece selected = cell.pickAt(hit.method_10264()+packet.localY(), packet.side()==class_2350.field_11036);
                if (selected != null) remove(world,player,selected);
            }
            return;
        }

        final BrickPiece candidate;
        if (packet.studio()) {
            // Local studio model spans 0..11 studs and 0..60 units. Anchor is server-checked.
            if (intent.x()<0 || intent.x()>11 || intent.z()<0 || intent.z()>11 ||
                    intent.y()<0 || intent.y()>60 || !world.method_8320(hit).method_26215() &&
                    !world.method_8320(hit).method_27852(CELL)) return;
            candidate = new BrickPiece(intent.kind(),intent.rgb(), hit.method_10263()+intent.x(),
                    hit.method_10264()*5+intent.y(),hit.method_10260()+intent.z(),intent.turn(),intent.angle());
        } else {
            if (packet.localX() < -.01f || packet.localX() > 1.01f ||
                    packet.localY() < -.01f || packet.localY() > 1.01f ||
                    packet.localZ() < -.01f || packet.localZ() > 1.01f) return;
            boolean lego = world.method_8320(hit).method_27852(CELL);
            if (!lego && world.method_8320(hit).method_26215()) return;
            class_2350 side = packet.side();
            int px = hit.method_10263() + side.method_10148();
            int pz = hit.method_10260() + side.method_10165();
            int baseUnits = (hit.method_10264()+side.method_10164())*5;
            if (lego && world.method_8321(hit) instanceof BrickCellEntity cell) {
                BrickPiece selected = cell.pickAt(hit.method_10264()+packet.localY(),side==class_2350.field_11036);
                if (selected != null) {
                    if (side == class_2350.field_11036) {
                        px = hit.method_10263(); pz = hit.method_10260(); baseUnits = selected.top();
                    } else if (side.method_10166().method_10179()) {
                        baseUnits = selected.y();
                    }
                }
            }
            candidate = new BrickPiece(intent.kind(),intent.rgb(),px,baseUnits,pz,intent.turn(),intent.angle());
        }
        if (!place(world, player, candidate) && !packet.studio()) {
            player.method_7353(class_2561.method_43470("BrickCraft : place bloquee (collision / terrain / distance)"), true);
        }
    }

    /** Validate the complete footprint BEFORE touching any world block. */
    private static boolean place(class_3218 world, class_3222 player, BrickPiece piece) {
        if (!piece.valid()) return false;
        List<class_2338> locations = piece.occupiedCells();
        if (locations.size()>256) return false;
        for (class_2338 pos : locations) {
            if (!world.method_24794(pos) || !world.method_22340(pos)
                    || !world.method_8505(player,pos)
                    || player.method_5707(class_243.method_24953(pos))>256) return false;
            if (world.method_8320(pos).method_26215()) continue;
            if (!(world.method_8321(pos) instanceof BrickCellEntity cell) || !cell.canAdd(piece)) return false;
        }
        for (class_2338 pos : locations) {
            if (world.method_8320(pos).method_26215()) world.method_8652(pos,CELL.method_9564(),3);
            if (world.method_8321(pos) instanceof BrickCellEntity cell) cell.add(piece);
        }
        return true;
    }

    /** A LEGO piece is always removed from every fragment cell it occupies. */
    private static boolean remove(class_3218 world, class_3222 player, BrickPiece piece) {
        List<class_2338> locations=piece.occupiedCells();
        for (class_2338 pos:locations) {
            if (!world.method_22340(pos) || !world.method_8505(player,pos)
                    || !(world.method_8321(pos) instanceof BrickCellEntity cell)
                    || !cell.pieces().contains(piece)) return false;
        }
        for (class_2338 pos:locations) {
            if (world.method_8321(pos) instanceof BrickCellEntity cell && cell.remove(piece)
                    && cell.pieces().isEmpty()) world.method_8652(pos,class_2246.field_10124.method_9564(),3);
        }
        return true;
    }
}
