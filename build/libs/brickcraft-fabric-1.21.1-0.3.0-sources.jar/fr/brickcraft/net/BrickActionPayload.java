package fr.brickcraft.net;

import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/** Both UIs send placement intents. The server calculates and validates occupied cells. */
public record BrickActionPayload(class_2338 hit, class_2350 side, float localX, float localY,
                                 float localZ, boolean remove, boolean studio, BrickPiece piece)
        implements class_8710 {
    public static final class_8710.class_9154<BrickActionPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655("brickcraft", "action"));
    public static final class_9139<class_9129,BrickActionPayload> CODEC =
            class_9139.method_56438(BrickActionPayload::write, BrickActionPayload::read);

    private void write(class_9129 buf) {
        buf.method_10807(hit);
        buf.method_52997(side.method_10146());
        buf.method_52941(localX); buf.method_52941(localY); buf.method_52941(localZ);
        buf.method_52964(remove); buf.method_52964(studio);
        buf.method_10804(piece.kind().ordinal()); buf.method_53002(piece.rgb());
        buf.method_53002(piece.x()); buf.method_53002(piece.y()); buf.method_53002(piece.z());
        buf.method_52997(piece.turn());
        buf.method_52998(piece.angle());
    }

    private static BrickActionPayload read(class_9129 buf) {
        class_2338 hit = buf.method_10811();
        class_2350 side = class_2350.method_10143(buf.readByte());
        float x = buf.readFloat(), y = buf.readFloat(), z = buf.readFloat();
        boolean remove = buf.readBoolean(), studio = buf.readBoolean();
        int index = buf.method_10816(), rgb = buf.readInt();
        int px = buf.readInt(), py = buf.readInt(), pz = buf.readInt(), turn = buf.readByte();
        int angle = buf.readUnsignedShort();
        BrickKind[] kinds = BrickKind.values();
        BrickKind kind = kinds[Math.floorMod(index, kinds.length)];
        return new BrickActionPayload(hit, side, x,y,z, remove,studio,
                new BrickPiece(kind,rgb,px,py,pz,turn,angle));
    }
    @Override public class_8710.class_9154<? extends class_8710> method_56479() { return ID; }
}
