package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.world.BrickPartItem;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public final class BrickCraftClient implements ClientModInitializer {
    private static class_304 studioKey,nextKey,turnKey,colorKey,quickKey,stepKey;

    @Override public void onInitializeClient() {
        BlockEntityRendererRegistry.register(BrickCraft.CELL_ENTITY, BrickCellRenderer::new);
        studioKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.studio",class_3675.class_307.field_1668,GLFW.GLFW_KEY_B,"category.brickcraft"));
        nextKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.next",class_3675.class_307.field_1668,GLFW.GLFW_KEY_V,"category.brickcraft"));
        turnKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.turn",class_3675.class_307.field_1668,GLFW.GLFW_KEY_R,"category.brickcraft"));

        quickKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.quick",class_3675.class_307.field_1668,GLFW.GLFW_KEY_N,"category.brickcraft"));
        stepKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.step",class_3675.class_307.field_1668,GLFW.GLFW_KEY_G,"category.brickcraft"));
        colorKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.color",class_3675.class_307.field_1668,GLFW.GLFW_KEY_C,"category.brickcraft"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (studioKey.method_1436()) {
                if (client.field_1724 != null && client.field_1755 == null)
                    client.method_1507(new BrickStudioScreen(resolveTarget(client)));
            }
            while (quickKey.method_1436()) if (client.field_1755==null && client.field_1724!=null)
                client.method_1507(new BrickQuickScreen());
            while (stepKey.method_1436()) if (client.field_1755==null) {
                BrickSelection.cycleStep();
                if(client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(
                    "BrickCraft : pas de rotation " + BrickSelection.step() + "°"),true);
            }
            while (nextKey.method_1436()) if (client.field_1755==null) {
                BrickSelection.nextKind();
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(
                    "BrickCraft : "+BrickSelection.kind.title),true);
            }
            while (colorKey.method_1436()) if (client.field_1755==null) {
                BrickSelection.nextColor();
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(
                    "BrickCraft : " + BrickSelection.colorName()),true);
            }
            while (turnKey.method_1436()) if (client.field_1755==null) {
                BrickSelection.rotate(client.field_1724!=null && client.field_1724.method_5715() ? -1 : 1);
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(
                    "BrickCraft : rotation "+BrickSelection.angle+"° (pas "+BrickSelection.step()+"°)"),true);
            }
        });
        HudRenderCallback.EVENT.register((draw,tick) -> {
            class_310 client=class_310.method_1551();
            if(client.field_1724==null || client.field_1755!=null || client.field_1690.field_1842) return;
            boolean active=client.field_1724.method_6047().method_31574(BrickCraft.TOOL)
                    || client.field_1724.method_6047().method_7909() instanceof BrickPartItem;
            if(!active)return;
            BrickKind kind=client.field_1724.method_6047().method_7909() instanceof BrickPartItem item
                    ? item.kind():BrickSelection.kind;
            int x=6,y=draw.method_51443()-76;
            int w=Math.max(170,client.field_1772.method_1727(kind.title)+22);
            draw.method_25294(x-3,y-3,x+w+3,y+48,0xB5102230);
            draw.method_25294(x,y+3,x+8,y+15,0xFF000000|BrickSelection.rgb);
            draw.method_25303(client.field_1772,kind.title,x+13,y+4,0xFFEAF6FF);
            draw.method_25303(client.field_1772,
                    BrickSelection.colorName()+"  |  "+BrickSelection.angle+"° ("+BrickSelection.step()+"°)",
                    x+3,y+20,0xFFF2DDA1);
            draw.method_25303(client.field_1772,"N : pieces / couleurs   G : pas",x+3,y+34,0xFF99C0D1);
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand!=class_1268.field_5808 || !(player.method_5998(hand).method_31574(BrickCraft.TOOL) ||
                    player.method_5998(hand).method_7909() instanceof BrickPartItem))
                return class_1269.field_5811;
            if (world.field_9236) {
                BrickKind kind=player.method_5998(hand).method_7909() instanceof BrickPartItem item
                        ? item.kind() : BrickSelection.kind;
                BrickPiece selection=BrickPiece.atAngle(kind,BrickSelection.rgb,0,0,0,BrickSelection.angle);
                ClientPlayNetworking.send(new BrickActionPayload(
                    hit.method_17777(),hit.method_17780(),
                    (float)(hit.method_17784().field_1352-hit.method_17777().method_10263()),
                    (float)(hit.method_17784().field_1351-hit.method_17777().method_10264()),
                    (float)(hit.method_17784().field_1350-hit.method_17777().method_10260()),
                    player.method_5715(),false,selection));
            }
            return class_1269.field_5812;
        });
    }

    public static class_2338 resolveTarget(class_310 client) {
        if (client.field_1687 == null || !(client.field_1765 instanceof class_3965 hit)) return null;
        // Studio origin is placed NEXT TO a targeted normal block, vanilla-style.
        // A new model can also start from the top of an existing LEGO cell.
        if (client.field_1687.method_8320(hit.method_17777()).method_27852(BrickCraft.CELL))
            return hit.method_17780().method_10166().method_10178()
                    ? hit.method_17777().method_10084() : hit.method_17777().method_10093(hit.method_17780());
        return hit.method_17777().method_10093(hit.method_17780());
    }
}
