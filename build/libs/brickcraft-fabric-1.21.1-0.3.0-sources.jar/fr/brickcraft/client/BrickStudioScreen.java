package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * V0.3: angle-aware isometric editor; the world NBT format supports V0.2.x saves.
 * Client and server MUST both use 0.3 because networking has a new angle field.
 */
public final class BrickStudioScreen extends class_437 {
    private static final StudioAssembly ASSEMBLY = new StudioAssembly();
    private static final int GRID = StudioAssembly.GRID;
    private enum Tab { PIECES, COULEURS, POSITION }
    private enum Tool { POSER, DEPLACER, EFFACER }

    private final class_2338 target;
    private Tab tab = Tab.PIECES;
    private Tool tool = Tool.POSER;
    private StudioLayout layout;
    private int cursorX = 0, cursorZ = 0;
    private int selected = -1;
    private boolean autoSnap = true;
    private boolean confirmClear = false;
    private int shapePage=0;
    private float orbit = .72f;
    private float zoom = 1f;
    private boolean orbitDragging = false;
    private String status = "Clic gauche : poser | Molette : zoom | Droit-glisser : tourner la vue";

    public BrickStudioScreen(class_2338 target) {
        super(class_2561.method_43470("BrickCraft Studio - V0.3"));
        this.target = target;
    }

    @Override
    protected void method_25426() {
        layout = StudioLayout.calculate(field_22789, field_22790);
        final int left = layout.panelX() + 3;
        final int panel = layout.panelW() - 6;
        final int gap = 2;
        final int tabW = (panel - 2 * gap) / 3;

        button(left, 28, tabW, 19, "Pieces", () -> changeTab(Tab.PIECES));
        button(left + tabW + gap, 28, tabW, 19, "Couleurs", () -> changeTab(Tab.COULEURS));
        button(left + 2 * (tabW + gap), 28, panel - 2 * (tabW + gap), 19,
                "Pos.", () -> changeTab(Tab.POSITION));

        final int toolGap = 2;
        final int toolsWidth = layout.stageWidth() - toolGap*2;
        final int toolW = toolsWidth / 3;
        button(layout.stageX(), 28, toolW, 19, "Poser", () -> chooseTool(Tool.POSER));
        button(layout.stageX()+toolW+toolGap, 28, toolW, 19, "Bouger", () -> chooseTool(Tool.DEPLACER));
        button(layout.stageX()+toolW*2+toolGap*2, 28,
                Math.max(12, layout.stageWidth()-toolW*2-toolGap*2), 19,
                "Effacer", () -> chooseTool(Tool.EFFACER));

        if (tab == Tab.PIECES) {
            final int w = (panel - 8) / 2;
            BrickKind[] kinds = BrickKind.values();
            for (int i = shapePage*6; i < Math.min(kinds.length,(shapePage+1)*6); i++) {
                BrickKind kind = kinds[i];
                int idx=i-shapePage*6, row=idx/2, col=idx%2;
                int px = left + 2 + col * (w + 4);
                int py = 65 + row * 27;
                button(px, py, w, 23, shortName(kind), () -> {
                    BrickSelection.kind = kind;
                    selected = -1;
                    tool = Tool.POSER;
                    status = "Piece : " + kind.title + " | place-la dans la vue";
                });
            }
            button(left+2,149,w,19,"< Page",()->{
                shapePage=Math.max(0,shapePage-1);method_41843();
            });
            button(left+w+6,149,w,19,"Page >",()->{
                shapePage=Math.min((kinds.length-1)/6,shapePage+1);method_41843();
            });
        } else if (tab == Tab.POSITION) {
            final int bw = (panel - 8) / 2;
            final int step = Math.min(26,Math.max(21,(layout.footerY()-80)/5));
            for (int i = 0; i < 5; i++) {
                int py = 64 + i * step;
                switch (i) {
                    case 0 -> {button(left+2, py, bw, 19, "Angle -", () -> rotate(-1));
                               button(left+bw+6, py, bw, 19, "Angle +", () -> rotate(1));}
                    case 1 -> {button(left+2, py, panel-4, 19, "Pas : "+BrickSelection.step()+" deg", () -> {
                        BrickSelection.cycleStep();method_41843();
                    });}
                    case 2 -> {button(left+2, py, bw, 19, "H -", () -> BrickSelection.layer = Math.max(0, BrickSelection.layer-1));
                               button(left+bw+6, py, bw, 19, "H +", () -> BrickSelection.layer = Math.min(30, BrickSelection.layer+1));}
                    case 3 -> {button(left+2, py, panel-4, 19,
                            "Hauteur : " + (autoSnap ? "AUTO" : "MANUEL"), () -> {
                                autoSnap = !autoSnap;
                                status = autoSnap ? "Empilement automatique active" : "Hauteur manuelle activee";
                                method_41843();
                            });}
                    case 4 -> {button(left+2, py, panel-4, 19,
                            confirmClear ? "Confirmer VIDER" : "Vider atelier",this::confirmClear);}
                    default -> {}
                }
            }
        }

        final boolean compact = field_22789 < 560;
        final String[] names = compact
                ? new String[]{"Retour", "Refaire", "Copie", "Tourner", "En jeu", "Fermer"}
                : new String[]{"Annuler", "Retablir", "Dupliquer", "Tourner", "Construire en jeu", "Fermer"};
        final Runnable[] actions = {
                this::undo, this::redo, this::duplicate,
                this::rotate, this::applyToWorld, this::method_25419
        };
        final int spacing = 3, first = 6;
        final int available = field_22789 - 2*first - 5*spacing;
        final int base = available / names.length;
        int bx = first;
        for (int i=0;i<names.length;i++) {
            int bw = i==names.length-1 ? field_22789-first-bx : base;
            button(bx,layout.footerY(),bw,20,names[i],actions[i]);
            bx += bw+spacing;
        }
    }

    private void chooseTool(Tool next) {
        tool = next;
        selected = -1;
        status = switch (next) {
            case POSER -> "Poser : clique dans la grille pour ajouter. H = hauteur.";
            case DEPLACER -> "Bouger : clique une piece puis sa nouvelle position.";
            case EFFACER -> "Effacer : clique directement la piece a retirer.";
        };
    }

    private void changeTab(Tab next) {
        if(tab==next) return;
        tab = next;
        method_41843();
    }

    private static String shortName(BrickKind kind) {
        return kind.title.replace("Brique ", "B ")
                .replace("Plaque ", "P ").replace("Tuile ", "T ")
                .replace("Pente ","S ").replace('×', 'x');
    }

    private void button(int x, int y, int w, int h, String title, Runnable callback) {
        // Buttons must never reach the screen footer/status area or offscreen.
        if (w < 12 || h < 12 || x >= field_22789 || y < 0 || y+h > field_22790-19) return;
        if (y < layout.footerY() && y+h > layout.footerY()-3) return;
        method_37063(class_4185.method_46430(class_2561.method_43470(title), b -> callback.run())
                .method_46434(x,y,w,h).method_46431());
    }

    /** Candidate at the current cursor, snapped to the highest overlapping LEGO body. */
    private BrickPiece candidate(int ignoreIndex, BrickPiece source) {
        BrickKind kind = source == null ? BrickSelection.kind : source.kind();
        int rgb = source == null ? BrickSelection.rgb : source.rgb();
        int angle=source==null?BrickSelection.angle:source.angle();
        int height=BrickSelection.layer*2;
        if(autoSnap)height=ASSEMBLY.snapTop(cursorX,cursorZ,kind,angle,height,ignoreIndex);
        return BrickPiece.atAngle(kind,rgb,cursorX,height,cursorZ,angle);
    }

    private void add() {
        BrickPiece p = candidate(-1,null);
        if (ASSEMBLY.add(p)) {
            status = "Ajoute : " + p.kind().title + " a X=" + cursorX + " Z=" + cursorZ
                    + " H=" + p.y()/2 + " ("+ASSEMBLY.size()+" pieces)";
        } else {
            status = "Placement impossible : hors plateau, limite ou collision";
        }
    }

    private void undo() {
        if (ASSEMBLY.undo()) {selected=-1;status="Modification annulee";}
        else status="Rien a annuler";
    }
    private void redo() {
        if (ASSEMBLY.redo()) {selected=-1;status="Modification retablie";}
        else status="Rien a retablir";
    }
    private void duplicate() {
        BrickPiece p = ASSEMBLY.get(selected);
        if (p==null) {
            status="Selectionne d'abord une piece avec l'outil Bouger";
            chooseTool(Tool.DEPLACER);
            return;
        }
        BrickSelection.kind=p.kind(); BrickSelection.rgb=p.rgb();
        BrickSelection.angle=p.angle(); BrickSelection.turn=p.turn();
        cursorX=Math.min(GRID-1,p.x()+p.width());
        cursorZ=p.z(); BrickSelection.layer=Math.max(0,p.y()/2);
        selected=-1;tool=Tool.POSER;
        status="Copie chargee : clique pour poser une autre piece";
    }
    private void rotate(){rotate(1);}
    private void rotate(int direction) {
        if(tool==Tool.DEPLACER && selected>=0) {
            BrickPiece p=ASSEMBLY.get(selected);
            if(p!=null) {
                BrickPiece changed=p.withAngle(p.angle()+direction*BrickSelection.step());
                status=ASSEMBLY.replace(selected,changed)
                        ? "Piece tournee : "+changed.angle()+" deg"
                        : "Rotation bloquee (collision / bord)";
                return;
            }
        }
        BrickSelection.rotate(direction);
        status="Rotation : "+BrickSelection.angle+" deg (pas : "+BrickSelection.step()+" deg)";
    }

    private void confirmClear() {
        if(ASSEMBLY.size()==0) {status="Atelier deja vide";return;}
        if(!confirmClear) {
            confirmClear=true;
            status="Attention : clique a nouveau sur Vider pour confirmer";
            method_41843();return;
        }
        ASSEMBLY.clear(); selected=-1;confirmClear=false;
        status="Atelier vide (Ctrl+Z pour annuler)";
        method_41843();
    }

    private void applyToWorld() {
        if(field_22787==null || field_22787.field_1724==null || !field_22787.field_1724.method_6047().method_31574(BrickCraft.TOOL)) {
            status="Tiens l'outil BrickCraft dans la main";return;
        }
        if(target==null) {status="Vise le sol avant d'ouvrir le Studio";return;}
        if(ASSEMBLY.isEmpty()) {status="Ajoute une piece dans l'atelier";return;}
        for(BrickPiece local: ASSEMBLY.pieces()) {
            ClientPlayNetworking.send(new BrickActionPayload(target,class_2350.field_11036,.5f,.5f,.5f,
                    false,true,local));
        }
        status=ASSEMBLY.size()+" demandes de placement transmises au serveur (resultats non garantis)";
    }

    /** Own the whole background: no second blurred UI layer over labels. */
    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Intentionally empty. render() draws a completely opaque background.
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // The screen's scaled dimensions are fixed until Minecraft calls init() on resize.
        int sx=layout.stageX(), ex=layout.stageRight();
        int top=layout.stageTop(), bottom=layout.stageBottom();
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B111A);
        ctx.method_25294(4,23,layout.panelX()+layout.panelW()+2,bottom+3,0xFF162330);
        ctx.method_25294(sx,top,ex,bottom,0xFF0B1B27);
        ctx.method_25294(sx,top,ex,top+1,0xFF345267);
        ctx.method_25294(0,layout.footerY()-3,field_22789,field_22790,0xFF192A39);
        text(ctx,"BRICKCRAFT  /  STUDIO 0.3",9,8,0xFFE4F4FF,field_22789-16);
        int active=(tool==Tool.POSER?0:tool==Tool.DEPLACER?1:2);
        int tw=(layout.stageWidth()-4)/3;
        int highlightX=layout.stageX()+active*(tw+2);
        ctx.method_25294(highlightX,48,highlightX+tw,50,0xFF55D3D3);

        // Scissor sidebar content so no label can run behind the action row.
        ctx.method_44379(layout.panelX(),53,layout.panelX()+layout.panelW()+2,layout.footerY()-4);
        switch(tab) {
            case PIECES -> renderPiecesPanel(ctx);
            case COULEURS -> renderColorsPanel(ctx);
            case POSITION -> renderPositionPanel(ctx);
        }
        ctx.method_44380();

        ctx.method_44379(sx+2,top+2,ex-2,bottom-2);
        text(ctx,"12 x 12  |  Mode : " + tool.name(),sx+7,top+6,0xFFB7D8ED,ex-sx-12);
        text(ctx,"Gauche : action  |  Droit-glisser : orbite",sx+7,top+18,0xFF789AAB,ex-sx-12);
        ctx.method_44379(sx+2,top+32,ex-2,bottom-3);
        renderViewport(ctx,mouseX,mouseY);
        ctx.method_44380();
        text(ctx,"X="+cursorX+" Z="+cursorZ+" | "+ASSEMBLY.size()+" pieces | "+(autoSnap?"AUTO":"H="+BrickSelection.layer),
                sx+7,bottom-14,0xFFE4D29A,ex-sx-12);
        ctx.method_44380();

        text(ctx,status,9,field_22790-16,0xFFE4D29A,field_22789-16);
        super.method_25394(ctx,mouseX,mouseY,delta);
    }

    private void renderPiecesPanel(class_332 ctx) {
        text(ctx,"FORMES "+(shapePage*6+1)+"-"+Math.min(BrickKind.values().length,(shapePage+1)*6)
                +" / "+BrickKind.values().length,layout.panelX()+6,53,0xFF9DCCDD,layout.panelW()-12);
        // A thin outline around the selected piece button remains visible when widgets render.
        int panel=layout.panelW()-6, buttonW=(panel-8)/2;
        int index=BrickSelection.kind.ordinal()-shapePage*6;
        if(index>=0 && index<6) {
            int row=index/2,col=index%2;
            int px=layout.panelX()+5+col*(buttonW+4),py=65+row*27;
            int c=0xFF55D3D3;
            ctx.method_25294(px-2,py-2,px+buttonW+2,py,c);
            ctx.method_25294(px-2,py+23,px+buttonW+2,py+25,c);
            ctx.method_25294(px-2,py,px,py+23,c);
            ctx.method_25294(px+buttonW,py,px+buttonW+2,py+23,c);
        }
        text(ctx,"Selection",layout.panelX()+6,177,0xFF85A7BA,layout.panelW()-12);
        text(ctx,BrickSelection.kind.title,layout.panelX()+6,190,0xFFFFFFFF,layout.panelW()-12);
        text(ctx,"Angle : "+BrickSelection.angle+" deg  /  "+BrickSelection.step()+" deg",
                layout.panelX()+6,208,0xFF9BBECC,layout.panelW()-12);
        text(ctx,"Hauteur : "+BrickSelection.layer+" plaques",layout.panelX()+6,224,0xFF9BBECC,layout.panelW()-12);
        text(ctx,"Couleur : "+colorName(),layout.panelX()+6,242,0xFFF4D9A1,layout.panelW()-12);
        int rx=layout.panelX()+8,ry=263;
        ctx.method_25294(rx,ry,rx+30,ry+12,0xFF000000|BrickSelection.rgb);
    }

    private String colorName() {return BrickSelection.colorName();}

    private int swatchSize() {
        return Math.min(29,Math.max(19,(layout.panelW()-34)/4));
    }

    private void renderColorsPanel(class_332 ctx) {
        text(ctx,"PALETTE - 16 teintes",layout.panelX()+6,55,0xFF9DCCDD,layout.panelW()-12);
        int sw=swatchSize(),gap=3;
        int originX=layout.panelX()+9,originY=76;
        for(int i=0;i<BrickPalette.COLORS.length;i++) {
            int x=originX+(i%4)*(sw+gap),y=originY+(i/4)*(sw+gap);
            boolean selected=BrickSelection.rgb==BrickPalette.COLORS[i];
            ctx.method_25294(x-2,y-2,x+sw+2,y+sw+2,selected?0xFFFFFFFF:0xFF43596C);
            ctx.method_25294(x,y,x+sw,y+sw,0xFF000000|BrickPalette.COLORS[i]);
        }
        int under=originY+4*(sw+gap)+8;
        text(ctx,colorName(),layout.panelX()+6,under,0xFFF7F7F7,layout.panelW()-12);
        text(ctx,String.format("#%06X",BrickSelection.rgb),layout.panelX()+6,under+16,0xFF9DBDCD,layout.panelW()-12);
        text(ctx,"Clic sur une couleur",layout.panelX()+6,under+38,0xFF7A9CAC,layout.panelW()-12);
    }

    private void renderPositionPanel(class_332 ctx) {
        text(ctx,"REGLAGES",layout.panelX()+6,53,0xFF9DCCDD,layout.panelW()-12);
        if(layout.footerY()>=225) {
            text(ctx,"Angle : "+BrickSelection.angle+" deg",layout.panelX()+6,205,0xFFE4D29A,layout.panelW()-12);
            text(ctx,"Pas : "+BrickSelection.step()+" deg | Auto : "+(autoSnap?"oui":"non"),
                    layout.panelX()+6,222,0xFF9BBECC,layout.panelW()-12);
        }
    }

    private void text(class_332 ctx,String str,int x,int y,int rgb,int maxWidth) {
        if(maxWidth<10)return;
        // Text length is measured, so labels cannot paint over the viewport or footer.
        if(field_22793.method_1727(str)>maxWidth) {
            String suffix="...";
            int end=str.length();
            while(end>0 && field_22793.method_1727(str.substring(0,end)+suffix)>maxWidth)end--;
            str=str.substring(0,end)+suffix;
        }
        ctx.method_25303(field_22793,str,x,y,rgb);
    }

    private int centerX() {return (layout.stageX()+layout.stageRight())/2;}
    private int centerY() {return (layout.stageTop()+32+layout.stageBottom())/2+9;}
    private float baseZoom() {
        float byWidth=(layout.stageWidth()-16)/18f;
        float byHeight=(layout.stageHeight()-44)/12f;
        return Math.max(4f,Math.min(byWidth,byHeight))*zoom;
    }
    private record P(int x,int y) {}
    private P project(float x,float y,float z) {
        float units=baseZoom();
        double u=(x-GRID/2f)*Math.cos(orbit)-(z-GRID/2f)*Math.sin(orbit);
        double d=(x-GRID/2f)*Math.sin(orbit)+(z-GRID/2f)*Math.cos(orbit);
        return new P((int)(centerX()+u*units),(int)(centerY()+d*units*.45f-y*units*.9f));
    }
    private double depth(float x,float z) {return x*Math.sin(orbit)+z*Math.cos(orbit);}

    private void renderViewport(class_332 ctx, int mx, int my) {
        for(int k=0;k<=GRID;k++) {
            line(ctx,project(k,0,0),project(k,0,GRID),0xFF29526B);
            line(ctx,project(0,0,k),project(GRID,0,k),0xFF29526B);
        }
        List<BrickPiece> ordered = new ArrayList<>(ASSEMBLY.pieces());
        ordered.sort(Comparator.comparingDouble(p -> depth(p.x()+p.width()/2f,
                p.z()+p.length()/2f)+p.y()*.04));
        for (BrickPiece p:ordered) drawBrick(ctx,p,false);

        if (selected>=0 && tool==Tool.DEPLACER) {
            BrickPiece chosen=ASSEMBLY.get(selected);
            if (chosen!=null) drawOutline(ctx,chosen,0xFFFFD36F);
        }
        if (layout.insideStage(mx,my)) {
            Cursor pointer = resolveCursor(mx,my);
            cursorX = pointer.x;
            cursorZ = pointer.z;
            if (tool==Tool.POSER) {
                BrickPiece ghost = candidate(-1,null);
                boolean allowed=ASSEMBLY.canPlace(ghost,-1);
                if (ghost.x()+ghost.width()<=GRID && ghost.z()+ghost.length()<=GRID)
                    drawBrick(ctx,allowed?ghost:ghost.withColor(0xE74F55),true);
            } else if(tool==Tool.EFFACER || (tool==Tool.DEPLACER && selected<0)) {
                BrickPiece p=ASSEMBLY.get(pointer.index);
                if(p!=null) drawOutline(ctx,p,tool==Tool.EFFACER?0xFFFF5D5D:0xFF70DFFF);
            } else if(tool==Tool.DEPLACER && selected>=0) {
                BrickPiece source=ASSEMBLY.get(selected);
                if(source!=null) {
                    BrickPiece ghost=candidate(selected,source);
                    boolean okay=ASSEMBLY.canPlace(ghost,selected);
                    if(ghost.x()+ghost.width()<=GRID && ghost.z()+ghost.length()<=GRID)
                        drawBrick(ctx,okay?ghost:ghost.withColor(0xE74F55),true);
                }
            }
        }
    }

    private P[] corners(BrickPiece piece,float y) {
        double[][] world=piece.corners();
        P[] p=new P[4];
        for(int i=0;i<4;i++)p[i]=project((float)world[i][0],y,(float)world[i][1]);
        return p;
    }

    private void drawOutline(class_332 ctx,BrickPiece piece,int color) {
        P[] p=topCorners(piece);
        for(int i=0;i<4;i++)line(ctx,p[i],p[(i+1)%4],color);
    }

    private record Cursor(int x,int z,int index) {}

    private Cursor resolveCursor(double mx,double my) {
        // Hit-test the visible top faces first; clicking onto the top of a brick
        // should not select a cell behind it on the ground plane.
        int best=-1;
        double depth=-Double.MAX_VALUE;
        int pickY=0;
        List<BrickPiece> pieces=ASSEMBLY.pieces();
        for (int i=0;i<pieces.size();i++) {
            BrickPiece p=pieces.get(i);
            float top=p.top()/5f;
            P[] cs=topCorners(p);
            if (pointInQuad(mx,my,cs[0],cs[1],cs[2],cs[3])) {
                double order=depth(p.x()+p.width()/2f,p.z()+p.length()/2f)+p.y()*.04;
                if (order>=depth) {depth=order;best=i;pickY=p.top();}
            }
        }
        // Inverse the current isometric projection on the picked top plane.
        float u=baseZoom();
        double xx=(mx-centerX())/u;
        double dd=(my-centerY()+(pickY/5f)*u*.9f)/(u*.45f);
        int x=(int)Math.floor(xx*Math.cos(orbit)+dd*Math.sin(orbit)+GRID/2f);
        int z=(int)Math.floor(-xx*Math.sin(orbit)+dd*Math.cos(orbit)+GRID/2f);
        x=Math.clamp(x,0,GRID-1);
        z=Math.clamp(z,0,GRID-1);
        if(best>=0) {
            BrickPiece p=pieces.get(best);
            x=Math.clamp(x,p.x(),p.x()+p.width()-1);
            z=Math.clamp(z,p.z(),p.z()+p.length()-1);
        } else {
            // Fallback selection by footprint when a side is clicked.
            for (int i=pieces.size()-1;i>=0;i--) {
                BrickPiece p=pieces.get(i);
                if(x>=p.x() && x<p.x()+p.width() && z>=p.z() && z<p.z()+p.length() &&
                        BrickPiece.atAngle(BrickKind.PLATE_1X1,0,x,0,z,0).horizontalOverlaps(p)) {
                    best=i;break;
                }
            }
        }
        return new Cursor(x,z,best);
    }

    private static boolean pointInQuad(double px,double py,P a,P b,P c,P d) {
        return triangle(px,py,a,b,c) || triangle(px,py,a,c,d);
    }
    private static boolean triangle(double px,double py,P a,P b,P c) {
        double d1=(px-b.x)*(a.y-b.y)-(a.x-b.x)*(py-b.y);
        double d2=(px-c.x)*(b.y-c.y)-(b.x-c.x)*(py-c.y);
        double d3=(px-a.x)*(c.y-a.y)-(c.x-a.x)*(py-a.y);
        return !((d1<0 || d2<0 || d3<0) && (d1>0 || d2>0 || d3>0));
    }

    private P[] topCorners(BrickPiece p) {
        float high=p.top()/5f;
        P[] corners=corners(p,high);
        if(p.kind().slope) {
            double[][] xy=p.corners();
            for(int i=2;i<4;i++)corners[i]=project((float)xy[i][0],p.y()/5f+p.height()/5f*.14f,(float)xy[i][1]);
        }
        return corners;
    }

    private void drawBrick(class_332 ctx,BrickPiece p,boolean ghost) {
        float low=p.y()/5f,high=p.top()/5f;
        P[] bottom=corners(p,low),top=topCorners(p);
        int alpha=ghost?110:255,rgb=p.rgb();
        final double[] shades={.68,.75,.84,.64};
        for(int i=0;i<4;i++) {
            int j=(i+1)%4;
            face(ctx,new P[]{bottom[i],bottom[j],top[j],top[i]},shade(rgb,shades[i],alpha));
        }
        face(ctx,top,shade(rgb,1.12,alpha));
        if(p.kind().studs) {
            for(int i=0;i<p.kind().width;i++) for(int j=0;j<p.kind().length;j++) {
                double[] xy=p.stud(i,j);
                P stud=project((float)xy[0],high+.09f,(float)xy[1]);
                int radius=Math.max(2,(int)(baseZoom()*.11f));
                ctx.method_25294(stud.x-radius,stud.y-radius,stud.x+radius,stud.y+radius,
                        shade(rgb,1.32,alpha));
            }
        }
    }
    private static int shade(int rgb,double factor,int alpha) {
        int r=Math.min(255,(int)(((rgb>>16)&255)*factor));
        int g=Math.min(255,(int)(((rgb>>8)&255)*factor));
        int b=Math.min(255,(int)((rgb&255)*factor));
        return (alpha<<24)|(r<<16)|(g<<8)|b;
    }
    private static void line(class_332 ctx,P a,P b,int color) {
        int dx=Math.abs(b.x-a.x),dy=Math.abs(b.y-a.y);
        int sx=a.x<b.x?1:-1,sy=a.y<b.y?1:-1,err=dx-dy,x=a.x,y=a.y;
        while(true) {
            ctx.method_25294(x,y,x+1,y+1,color);
            if(x==b.x && y==b.y)break;
            int e2=2*err;
            if(e2>-dy) {err-=dy;x+=sx;}
            if(e2<dx) {err+=dx;y+=sy;}
        }
    }
    private static void face(class_332 ctx,P[] pts,int color) {
        int ymin=Integer.MAX_VALUE,ymax=Integer.MIN_VALUE;
        for(P p:pts) {ymin=Math.min(ymin,p.y);ymax=Math.max(ymax,p.y);}
        ymin=Math.max(0,ymin);ymax=Math.min(ctx.method_51443()-1,ymax);
        for(int y=ymin;y<=ymax;y++) {
            float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;
            for(int i=0;i<pts.length;i++) {
                P a=pts[i],b=pts[(i+1)%pts.length];
                if(a.y==b.y || y<Math.min(a.y,b.y) || y>=Math.max(a.y,b.y))continue;
                float xx=a.x+(float)(y-a.y)*(b.x-a.x)/(b.y-a.y);
                min=Math.min(min,xx);max=Math.max(max,xx);
            }
            if(max>=min)ctx.method_25294((int)Math.floor(min),y,(int)Math.ceil(max)+1,y+1,color);
        }
    }

    @Override public boolean method_25402(double mx,double my,int button) {
        if (button==0 && tab==Tab.COULEURS &&
                mx>=layout.panelX() && mx<layout.panelX()+layout.panelW()) {
            int sw=swatchSize(),gap=3;
            int originX=layout.panelX()+9,originY=76;
            for(int i=0;i<BrickPalette.COLORS.length;i++) {
                int x=originX+(i%4)*(sw+gap),y=originY+(i/4)*(sw+gap);
                if(mx>=x && mx<x+sw && my>=y && my<y+sw) {
                    BrickSelection.rgb=BrickPalette.COLORS[i];
                    BrickPiece p=ASSEMBLY.get(selected);
                    if (tool==Tool.DEPLACER && p!=null) {
                        ASSEMBLY.replace(selected,p.withColor(BrickSelection.rgb));
                        status="Piece recoloree : "+BrickSelection.colorName();
                    } else {
                        status="Couleur choisie : "+BrickSelection.colorName();
                    }
                    return true;
                }
            }
        }
        if(layout.insideStage(mx,my)) {
            if(button==1) {orbitDragging=true;return true;}
            if(button==0) {
                Cursor pointer=resolveCursor(mx,my);
                cursorX=pointer.x;cursorZ=pointer.z;
                switch(tool) {
                    case POSER -> add();
                    case EFFACER -> {
                        if (pointer.index>=0 && ASSEMBLY.remove(pointer.index)) {
                            selected=-1;status="Piece effacee (Ctrl+Z pour annuler)";
                        } else status="Clique une piece pour l'effacer";
                    }
                    case DEPLACER -> {
                        if(selected<0) {
                            selected=pointer.index;
                            status=selected>=0 ? "Piece selectionnee : clique sa destination"
                                    : "Clique une piece pour la selectionner";
                        } else {
                            BrickPiece old=ASSEMBLY.get(selected);
                            if(old!=null && pointer.index==selected) {
                                selected=-1;status="Selection annulee";
                            } else if(old!=null) {
                                BrickPiece dest=candidate(selected,old);
                                if (ASSEMBLY.replace(selected,dest)) {
                                    selected=-1;status="Piece deplacee (Ctrl+Z pour annuler)";
                                } else status="Deplacement impossible : collision ou bord";
                            } else selected=-1;
                        }
                    }
                }
                return true;
            }
        }
        return super.method_25402(mx,my,button);
    }
    @Override public boolean method_25403(double mx,double my,int button,double dx,double dy) {
        if(button==1 && orbitDragging) {orbit+=(float)dx*.013f;return true;}
        return super.method_25403(mx,my,button,dx,dy);
    }
    @Override public boolean method_25406(double mx,double my,int button) {
        if(button==1 && orbitDragging) {orbitDragging=false;return true;}
        return super.method_25406(mx,my,button);
    }
    @Override public boolean method_25401(double mx,double my,double horizontal,double vertical) {
        if(layout.insideStage(mx,my)) {
            zoom=Math.clamp(zoom+(float)vertical*.10f,.4f,2.5f);
            return true;
        }
        return super.method_25401(mx,my,horizontal,vertical);
    }
    @Override public boolean method_25404(int key,int scan,int mods) {
        boolean ctrl=(mods & GLFW.GLFW_MOD_CONTROL)!=0;
        if(ctrl && key==GLFW.GLFW_KEY_Z) {undo();return true;}
        if(ctrl && key==GLFW.GLFW_KEY_Y) {redo();return true;}
        if(ctrl && key==GLFW.GLFW_KEY_D) {duplicate();return true;}
        if(key==GLFW.GLFW_KEY_Q) {orbit-=.2f;return true;}
        if(key==GLFW.GLFW_KEY_E) {orbit+=.2f;return true;}
        if(key==GLFW.GLFW_KEY_R) {rotate((mods & GLFW.GLFW_MOD_SHIFT)!=0?-1:1);return true;}
        if(key==GLFW.GLFW_KEY_F) {BrickSelection.cycleStep();status="Pas : "+BrickSelection.step()+" deg";return true;}
        if(key==GLFW.GLFW_KEY_P) {chooseTool(Tool.POSER);return true;}
        if(key==GLFW.GLFW_KEY_M) {chooseTool(Tool.DEPLACER);return true;}
        if(key==GLFW.GLFW_KEY_G) {chooseTool(Tool.EFFACER);return true;}
        if(key==GLFW.GLFW_KEY_DELETE) {
            if (selected>=0 && ASSEMBLY.remove(selected)) {
                selected=-1;status="Piece effacee";
            } else undo();
            return true;
        }
        if(key>=GLFW.GLFW_KEY_1 && key<=GLFW.GLFW_KEY_6) {
            int index=shapePage*6+key-GLFW.GLFW_KEY_1;
            if(index>=BrickKind.values().length)return true;
            BrickSelection.kind=BrickKind.values()[index];
            selected=-1;tool=Tool.POSER;tab=Tab.PIECES;method_41843();
            return true;
        }
        if(key==GLFW.GLFW_KEY_PAGE_UP) {
            BrickSelection.layer=Math.min(30,BrickSelection.layer+1);return true;
        }
        if(key==GLFW.GLFW_KEY_PAGE_DOWN) {
            BrickSelection.layer=Math.max(0,BrickSelection.layer-1);return true;
        }
        return super.method_25404(key,scan,mods);
    }
    @Override public boolean method_25421() {return false;}
}
