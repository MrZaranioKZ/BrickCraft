package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

/**
 * Pocket build palette. Works independently from Studio and keeps the vanilla hotbar:
 * select a real brick item in creative inventory, OR select a brick here for the wand.
 */
public final class BrickQuickScreen extends class_437 {
    private int page=0;
    private int colCount,rowCount,perPage,leftX,leftW,rightX,rightW,topY;
    public BrickQuickScreen() {super(class_2561.method_43470("BrickCraft - construction rapide"));}

    @Override protected void method_25426() {
        leftX=12; rightW=Math.min(184,Math.max(120,field_22789/3));
        rightX=field_22789-rightW-12;
        leftW=rightX-leftX-12; topY=42;
        colCount=leftW>=320?3:2;
        rowCount=Math.max(2,Math.min(6,(field_22790-108)/29));
        perPage=colCount*rowCount;
        BrickKind[] kinds=BrickKind.values();
        int pages=(kinds.length+perPage-1)/perPage;
        page=Math.clamp(page,0,Math.max(0,pages-1));
        int gap=4;
        int buttonW=Math.max(20,(leftW-gap*(colCount-1))/colCount);
        for (int i=page*perPage;i<Math.min(kinds.length,(page+1)*perPage);i++) {
            BrickKind kind=kinds[i]; int slot=i-page*perPage;
            int x=leftX+(slot%colCount)*(buttonW+gap), y=topY+(slot/colCount)*29;
            method_37063(class_4185.method_46430(class_2561.method_43470(abbrev(kind)),b->{
                BrickSelection.kind=kind;
            }).method_46434(x,y,buttonW,25).method_46431());
        }
        int bottom=Math.min(field_22790-50,topY+rowCount*29+5);
        addButton(leftX,bottom,Math.max(35,leftW/3),20,"<",()->{page=Math.max(0,page-1);method_41843();});
        addButton(leftX+Math.max(35,leftW/3)+3,bottom,Math.max(35,leftW/3),20,">",()->{page=Math.min(pages-1,page+1);method_41843();});
        int ax=rightX, ay=topY+125;
        addButton(ax,ay,Math.max(30,rightW/3-3),19,"-",()->BrickSelection.rotate(-1));
        addButton(ax+rightW/3,ay,Math.max(30,rightW/3-3),19,"+",()->BrickSelection.rotate(1));
        addButton(ax+2*rightW/3,ay,Math.max(30,rightW/3-2),19,"Pas",BrickSelection::cycleStep);
        addButton(rightX,ay+26,rightW,19,"Revenir au jeu",this::method_25419);
    }

    private void addButton(int x,int y,int w,int h,String title,Runnable callback) {
        if(x+w<=field_22789 && y+h<field_22790-15 && w>=20)
            method_37063(class_4185.method_46430(class_2561.method_43470(title),b->callback.run())
                    .method_46434(x,y,w,h).method_46431());
    }
    private static String abbrev(BrickKind kind) {
        return kind.title.replace("Brique ","B ").replace("Plaque ","P ")
                .replace("Tuile ","T ").replace("Pente ","S ").replace('×','x');
    }
    @Override public void method_25420(class_332 ctx,int mx,int my,float delta) {}
    @Override public void method_25394(class_332 ctx,int mx,int my,float delta) {
        ctx.method_25294(0,0,field_22789,field_22790,0xE9091420);
        ctx.method_25294(leftX-5,topY-18,rightX-6,field_22790-37,0xFF152634);
        ctx.method_25294(rightX-5,topY-18,field_22789-8,field_22790-37,0xFF152634);
        super.method_25394(ctx,mx,my,delta);
        ctx.method_25303(field_22793,"BRICKCRAFT | Palette rapide",12,11,0xFFE6F3FF);
        ctx.method_25303(field_22793,"Pieces ("+(page+1)+")",leftX,topY-14,0xFF8BCBE4);
        ctx.method_25303(field_22793,"Couleurs",rightX,topY-14,0xFF8BCBE4);
        int gap=4,buttonW=Math.max(20,(leftW-gap*(colCount-1))/colCount);
        BrickKind[] kinds=BrickKind.values();
        for (int i=page*perPage;i<Math.min(kinds.length,(page+1)*perPage);i++) {
            BrickKind kind=kinds[i];int slot=i-page*perPage;
            int x=leftX+(slot%colCount)*(buttonW+gap),y=topY+(slot/colCount)*29;
            if(kind==BrickSelection.kind) {
                ctx.method_25294(x-2,y-2,x+buttonW+2,y+27,0xFF75E4D7);
            }
            ctx.method_51427(new class_1799(BrickCraft.PART_ITEMS.get(kind)),x+3,y+4);
        }
        int cellW=Math.max(22,(rightW-9)/4);
        for(int i=0;i<BrickPalette.COLORS.length;i++) {
            int x=rightX+(i%4)*cellW,y=topY+(i/4)*28;
            int c=BrickPalette.COLORS[i];
            ctx.method_25294(x,y,x+cellW-4,y+24,c==BrickSelection.rgb?0xFFFFFFFF:0xFF45596C);
            ctx.method_25294(x+2,y+2,x+cellW-6,y+22,0xFF000000|c);
        }
        ctx.method_25303(field_22793,BrickSelection.colorName(),rightX,topY+115,0xFFFFE5B1);
        ctx.method_25303(field_22793,"Angle : "+BrickSelection.angle+"° / "+BrickSelection.step()+"°",rightX,
                topY+174,0xFFC2E2ED);
        ctx.method_25303(field_22793,"Baguette : "+abbrev(BrickSelection.kind),leftX,
                field_22790-30,0xFFB9DDEB);
        ctx.method_25303(field_22793,"B / Studio  |  N / Palette  |  Echap",leftX,
                field_22790-15,0xFF91B0C3);
    }

    @Override public boolean method_25402(double x,double y,int button) {
        if(button==0) {
            int cellW=Math.max(22,(rightW-9)/4);
            for(int i=0;i<BrickPalette.COLORS.length;i++) {
                int xx=rightX+(i%4)*cellW,yy=topY+(i/4)*28;
                if(x>=xx && x<xx+cellW-4 && y>=yy && y<yy+24) {
                    BrickSelection.rgb=BrickPalette.COLORS[i];return true;
                }
            }
        }
        return super.method_25402(x,y,button);
    }
    @Override public boolean method_25404(int key,int scan,int modifiers) {
        if(key==GLFW.GLFW_KEY_R) {BrickSelection.rotate((modifiers&GLFW.GLFW_MOD_SHIFT)!=0?-1:1);return true;}
        if(key==GLFW.GLFW_KEY_G) {BrickSelection.cycleStep();return true;}
        if(key==GLFW.GLFW_KEY_C) {BrickSelection.nextColor();return true;}
        if(key==GLFW.GLFW_KEY_ESCAPE || key==GLFW.GLFW_KEY_N){method_25419();return true;}
        return super.method_25404(key,scan,modifiers);
    }
    @Override public boolean method_25421(){return false;}
}
