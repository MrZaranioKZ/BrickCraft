package fr.brickcraft.client;

import fr.brickcraft.core.BrickCapacityConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Per-installation settings (remote servers use their own limits). */
public final class BrickCapacityScreen extends class_437 {
    private final class_437 previous;
    private int partIndex,cellIndex;
    private String notice="";
    public BrickCapacityScreen(class_437 previous){
        super(class_2561.method_43470(BrickI18n.tr("BrickCraft - Capacites des grands sets")));this.previous=previous;
        partIndex=find(BrickCapacityConfig.PART_STEPS,BrickCapacityConfig.partsSetting());
        cellIndex=find(BrickCapacityConfig.CELL_STEPS,BrickCapacityConfig.cellsSetting());
    }
    private static int find(int[] arr,int v){for(int i=0;i<arr.length;i++)if(arr[i]==v)return i;return Math.max(0,arr.length-3);}
    private static String name(int n){return n==0?"SANS LIMITE CHOISIE":String.format(java.util.Locale.FRANCE,"%,d",n);}
    @Override protected void method_25426(){
        int w=Math.min(388,field_22789-24),x=(field_22789-w)/2,y=Math.max(48,field_22790/2-98);
        method_37063(new class_357(x,y+18,w,20,class_2561.method_43473(),partIndex/(double)(BrickCapacityConfig.PART_STEPS.length-1)){
            @Override protected void method_25346(){partIndex=(int)Math.round(field_22753*(BrickCapacityConfig.PART_STEPS.length-1));
                method_25355(class_2561.method_43470(BrickI18n.tr("Projection : "+name(BrickCapacityConfig.PART_STEPS[partIndex])+" pieces")));}
            @Override protected void method_25344(){partIndex=(int)Math.round(field_22753*(BrickCapacityConfig.PART_STEPS.length-1));method_25346();}
        });
        method_37063(new class_357(x,y+70,w,20,class_2561.method_43473(),cellIndex/(double)(BrickCapacityConfig.CELL_STEPS.length-1)){
            @Override protected void method_25346(){cellIndex=(int)Math.round(field_22753*(BrickCapacityConfig.CELL_STEPS.length-1));
                method_25355(class_2561.method_43470(BrickI18n.tr("Physique : "+name(BrickCapacityConfig.CELL_STEPS[cellIndex])+" cellules")));}
            @Override protected void method_25344(){cellIndex=(int)Math.round(field_22753*(BrickCapacityConfig.CELL_STEPS.length-1));method_25346();}
        });
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Enregistrer")),b->{
            try{BrickCapacityConfig.save(BrickCapacityConfig.PART_STEPS[partIndex],BrickCapacityConfig.CELL_STEPS[cellIndex]);method_25419();}
            catch(java.io.IOException ex){notice="Erreur : "+ex.getMessage();}
        }).method_46434(x,y+117,(w-6)/2,20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Annuler")),b->method_25419()).method_46434(x+(w+6)/2,y+117,(w-6)/2,20).method_46431());
    }
    @Override public void method_25420(class_332 d,int mx,int my,float dt){}
    @Override public void method_25394(class_332 d,int mx,int my,float dt){
        d.method_25294(0,0,field_22789,field_22790,0xFF0A1420);
        int y=Math.max(48,field_22790/2-98);
        d.method_25300(field_22793,BrickI18n.tr("BRICKCRAFT / CAPACITES"),field_22789/2,y-23,0xFF9CE7DD);
        d.method_25300(field_22793,BrickI18n.tr("Nombre de pieces par projection"),field_22789/2,y,0xFFE3EFFA);
        d.method_25300(field_22793,BrickI18n.tr("Cellules de collisions precises (1 bloc = 8x8x8)"),field_22789/2,y+52,0xFFE3EFFA);
        d.method_25300(field_22793,BrickI18n.tr("Droite : sans plafond choisi, mais securites techniques conservees."),field_22789/2,y+97,0xFFFFCC8A);
        d.method_25300(field_22793,BrickI18n.tr("Limites techniques : 250 000 pieces / 400 000 cellules / 20 M triangles"),field_22789/2,y+146,0xFFB4C9D9);
        d.method_25300(field_22793,BrickI18n.tr("Attention : beaucoup de collisions peut ralentir le serveur et grossir la sauvegarde."),field_22789/2,y+159,0xFFFFB7A3);
        if(!notice.isEmpty())d.method_25300(field_22793,BrickI18n.tr(notice),field_22789/2,y+174,0xFFFF8D8D);
        super.method_25394(d,mx,my,dt);
    }
    @Override public void method_25419(){field_22787.method_1507(previous);}
}
