package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseFreeAssembly;
import fr.brickcraft.importer.PreciseProjectIO;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.nio.file.Path;

/** V0.10.0: responsive editor, 2D projected picking, live 3-axis gizmos and lossless .bcpx. */
public final class PreciseFreeScreen extends class_437 {
    private static final double[] MOVE_STEPS={20,8,4,1,.25};
    private static final double[] ANGLE_STEPS={90,45,15,5,1,.25};
    private final ProjectImportScreen preview;
    private final PreciseFreeAssembly assembly;
    private final String filename;
    private class_342 partId,color,x,y,z,index,moveInput,angleInput;
    private class_4185 moveStepButton,angleStepButton,modeButton;
    private int moveStep=0,angleStep=0;
    private String status="Clic gauche dans l'apercu : selectionner | Maj+clic : choix superpose.";
    private boolean dirty=false,rotateMode=false,draggingGizmo=false;
    private PreciseFreeAssembly.Axis dragAxis;
    private PreviewSelectionMath.Frame dragFrame;
    private double dragMouseX,dragMouseY,dragOriginX,dragOriginY,dragOriginZ,lastDragValue=Double.NaN;
    private int panel,viewportLeft,viewportTop,viewportRight,viewportBottom;

    public PreciseFreeScreen(ProjectImportScreen preview,LDrawProjectReader.Result source,String filename){
        super(class_2561.method_43470(BrickI18n.tr("BrickCraft - Placement libre")));
        this.preview=preview;
        this.assembly=new PreciseFreeAssembly(source);
        this.filename=filename;
    }
    /** Compress vertical placement on small GUI heights without scaling widget hitboxes. */
    private int uiY(int baseline){
        double factor=Math.max(.66,Math.min(1.0,(field_22790-120)/320.0));
        return baseline<=32?baseline:(int)Math.round(32+(baseline-32)*factor);
    }
    private void button(int x,int y,int w,int h,String text,Runnable callback){
        if(w<15)return;
        if(field_22790<400)h=Math.min(h,16);
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr(text)),b->callback.run()).method_46434(x,y<330?uiY(y):y,w,h).method_46431());
    }
    private void footerButton(int xx,int yy,int width,String label,Runnable action){
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr(label)),b->action.run())
                .method_46434(xx,yy,width,20).method_46431());
    }
    private class_342 field(int x,int y,int w,String placeholder,int length){
        class_342 f=new class_342(field_22793,x,y<330?uiY(y):y,Math.max(18,w),18,class_2561.method_43470(BrickI18n.tr(placeholder)));
        f.method_1880(length);method_37063(f);return f;
    }
    @Override protected void method_25426(){
        panel=Math.max(270,Math.min(Math.min(405,field_22789-195),field_22789*38/100));
        panel=Math.min(panel,Math.max(230,field_22789-140));
        viewportLeft=panel+12;viewportTop=36;viewportRight=field_22789-9;viewportBottom=field_22790-29;
        int left=12, usable=panel-24;
        int q=(usable-12)/4,third=(usable-10)/3;
        button(left,37,q,19,"< Piece",()->pick(-1));
        button(left+q+4,37,q,19,"Piece >",()->pick(1));
        index=field(left+2*(q+4),37,q,"No",8);
        button(left+3*(q+4),37,q,19,"Aller",this::jump);
        partId=field(left,94,usable-112,"Reference LDraw",96);
        color=field(left+usable-106,94,106,"Couleur",8);
        x=field(left,138,third,"LDU X",24);
        y=field(left+third+5,138,third,"LDU Y",24);
        z=field(left+(third+5)*2,138,third,"LDU Z",24);
        int half=(usable-8)/2;
        moveStepButton=method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Pas pos.")),b->{
            moveStep=(moveStep+1)%MOVE_STEPS.length;updateStepTexts();
        }).method_46434(left,uiY(179),Math.max(58,half/2),field_22790<400?16:19).method_46431());
        moveInput=field(left+half/2+4,179,half-half/2-4,"LDU",20);
        angleStepButton=method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Pas rot.")),b->{
            angleStep=(angleStep+1)%ANGLE_STEPS.length;updateStepTexts();
        }).method_46434(left+half+8,uiY(179),Math.max(58,half/2),field_22790<400?16:19).method_46431());
        angleInput=field(left+half+8+half/2+4,179,half-half/2-4,"Degres",20);
        updateStepTexts();
        for(int c=0;c<3;c++){
            PreciseFreeAssembly.Axis axis=PreciseFreeAssembly.Axis.values()[c];
            int px=left+c*(third+5);
            button(px,207,third/2-2,19,axis+" -",()->stepMove(axis,-1));
            button(px+third/2+2,207,third/2-2,19,axis+" +",()->stepMove(axis,1));
            button(px,235,third/2-2,19,"R"+axis+" -",()->stepRotate(axis,-1));
            button(px+third/2+2,235,third/2-2,19,"R"+axis+" +",()->stepRotate(axis,1));
        }
        button(left,264,usable/2-3,19,"Appliquer",this::applyFields);
        button(left+usable/2+3,264,usable/2-3,19,"Rotation 0",()->change(assembly.resetRotation(),"Rotation initialisee"));
        button(left,289,third,19,"Ajouter",this::add);
        button(left+third+5,289,third,19,"Dupliquer",()->change(assembly.duplicate(),"Piece dupliquee"));
        button(left+(third+5)*2,289,third,19,"Supprimer",()->change(assembly.delete(),"Piece supprimee"));
        if(field_22790>=439){
            button(left,315,third,19,"Annuler",()->change(assembly.undo(),"Annulation"));
            button(left+third+5,315,third,19,"Retablir",()->change(assembly.redo(),"Retablissement"));
            modeButton=method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr("Mode: bouger")),b->toggleMode())
                    .method_46434(left+(third+5)*2,uiY(315),third,19).method_46431());
        }
        // Sticky footer stays clear of the last editable row even on small GUI scales.
        footerButton(left,field_22790-72,usable,"Enregistrer un nouveau .bcpx",this::save);
        footerButton(left,field_22790-45,usable,"Retour a l'import",()->field_22787.method_1507(preview));
        refreshFields();
    }
    private void toggleMode(){rotateMode=!rotateMode;
        if(modeButton!=null)modeButton.method_25355(class_2561.method_43470(BrickI18n.tr(rotateMode?"Mode: tourner":"Mode: bouger")));
        status=rotateMode?"Poignees : rotation autour de l'axe choisi (R).":"Poignees : deplacement sur l'axe choisi (G).";
    }
    private void updateStepTexts(){moveInput.method_1852(fmt(MOVE_STEPS[moveStep]));angleInput.method_1852(fmt(ANGLE_STEPS[angleStep]));}
    private static String fmt(double v){return v==(long)v?Long.toString((long)v):Double.toString(v);}
    private static double number(class_342 field){return Double.parseDouble(field.method_1882().strip().replace(',','.'));}
    private static double stepValue(class_342 field,double max){
        double value=number(field);
        if(!Double.isFinite(value)||value<=0||value>max)throw new IllegalArgumentException("Pas entre 0 et "+max);
        return value;
    }
    private void refreshFields(){
        var p=assembly.selected();
        index.method_1852(assembly.selectedIndex()<0?"-":Integer.toString(assembly.selectedIndex()+1));
        if(p==null){partId.method_1852("3005");color.method_1852("4");x.method_1852("0");y.method_1852("0");z.method_1852("0");}
        else{partId.method_1852(p.partId());color.method_1852(Integer.toString(p.color()));
            x.method_1852(fmt(p.x()));y.method_1852(fmt(p.y()));z.method_1852(fmt(p.z()));}
    }
    private void pick(int dir){
        if(assembly.size()==0){status="Aucune piece. Utilise Ajouter.";return;}
        assembly.select(Math.floorMod(assembly.selectedIndex()+dir,assembly.size()));refreshFields();
    }
    private void jump(){
        try{if(!assembly.select(Integer.parseInt(index.method_1882())-1))throw new IllegalArgumentException();refreshFields();}
        catch(Exception ex){status="Numero invalide : 1 a "+assembly.size();}
    }
    private LDrawProjectReader.Instance fromFields(double[] mat){
        return new LDrawProjectReader.Instance(partId.method_1882().strip().replace(".dat",""),
                Integer.parseInt(color.method_1882().strip()),number(x),number(y),number(z),mat);
    }
    private void applyFields(){
        try{var p=assembly.selected();
            if(p==null){status="Aucune piece : utilise Ajouter";return;}
            change(assembly.replace(fromFields(p.matrix())),"Champs appliques");
        }catch(Exception ex){status="Champs invalides : "+ex.getMessage();}
    }
    private void add(){
        try{change(assembly.add(fromFields(PreciseFreeAssembly.identity())),"Piece ajoutee");}
        catch(Exception ex){status="Ajout refuse : "+ex.getMessage();}
    }
    private void stepMove(PreciseFreeAssembly.Axis axis,int direction){
        try{double amount=direction*stepValue(moveInput,1000);
            change(assembly.move(axis,amount),"Deplacement "+axis+" : "+fmt(amount)+" LDU");}
        catch(Exception ex){status="Deplacement refuse : "+ex.getMessage();}
    }
    private void stepRotate(PreciseFreeAssembly.Axis axis,int direction){
        try{double amount=direction*stepValue(angleInput,360);
            change(assembly.rotate(axis,amount),"Rotation "+axis+" : "+fmt(amount)+" deg");}
        catch(Exception ex){status="Rotation refusee : "+ex.getMessage();}
    }
    private void change(boolean success,String message){
        if(!success){status="Aucune modification possible";return;}
        dirty=true;refreshFields();preview.applyFreeEdits(assembly.result());
        status=message+" | "+assembly.size()+" pieces";
    }
    private void save(){
        if(assembly.size()==0){status="Ajoute au moins une piece avant de sauver";return;}
        try{
            Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
            Files.createDirectories(folder);
            String stem=filename.replaceAll("(?i)\\.(io|ldr|mpd|bcpx)$","").replaceAll("[^a-zA-Z0-9_-]","_");
            if(stem.isEmpty())stem="atelier";
            Path dest=folder.resolve(stem+"_free_v099.bcpx");
            int suffix=2;
            while(Files.exists(dest)){dest=folder.resolve(stem+"_free_v099_"+(suffix++)+".bcpx");}
            PreciseProjectIO.save(dest,assembly.result());dirty=false;
            status="Sauvegarde : "+dest.getFileName()+" (source conservee)";
            preview.refreshFreeFiles(dest);
        }catch(Exception ex){status="Erreur de sauvegarde : "+ex.getMessage();}
    }
    private void limitedText(class_332 draw,String message,int xx,int yy,int max,int color){
        if(max<=5)return;
        while(field_22793.method_1727(message)>max&&message.length()>3)message=message.substring(0,message.length()-4)+"...";
        draw.method_25303(field_22793,BrickI18n.tr(message),xx,yy,color);
    }
    @Override public void method_25420(class_332 ctx,int mx,int my,float delta){}
    @Override public void method_25394(class_332 ctx,int mx,int my,float delta){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B111A);
        preview.renderFreeViewport(ctx,viewportLeft,viewportTop,viewportRight,viewportBottom,
                assembly.selectedIndex(),rotateMode);
        ctx.method_25294(4,30,panel+3,field_22790-26,0xFF172636);
        ctx.method_25294(4,30,panel+3,34,0xFF55CFD8);
        limitedText(ctx,"BRICKCRAFT / PLACEMENT LIBRE",12,9,field_22789-22,0xFFE7F8FF);
        limitedText(ctx,"Piece "+(assembly.selectedIndex()+1)+" / "+assembly.size()+(dirty?"  *":""),
                12,uiY(62),panel-23,0xFF9DE4E3);
        limitedText(ctx,"Reference / code couleur",12,uiY(78),panel-23,0xFFC0CEDA);
        limitedText(ctx,"Origine LDraw : X / Y / Z",12,uiY(117),panel-23,0xFFC0CEDA);
        if(field_22790>=420)limitedText(ctx,"1 stud = 20 LDU | 1 plate = 8 LDU",12,uiY(162),panel-23,0xFFE7C98F);
        // Help lives in the bottom status band, not between action buttons.

        limitedText(ctx,"Clic gauche : selection | Maj : suivant | Clic droit : orbite",viewportLeft+8,viewportTop+7,
                viewportRight-viewportLeft-16,0xFFAAC9D7);
        limitedText(ctx,"Clic molette : panoramique | Molette : zoom | G : bouger | R : tourner",
                viewportLeft+8,viewportTop+20,viewportRight-viewportLeft-16,0xFF7CA5B9);
        ctx.method_25294(0,field_22790-25,field_22789,field_22790,0xFF122334);
        limitedText(ctx,status,10,field_22790-18,field_22789-20,0xFFFFDA91);
        super.method_25394(ctx,mx,my,delta);
    }
    private boolean overViewport(double mx,double my){
        return mx>=viewportLeft&&mx<=viewportRight&&my>=viewportTop&&my<=viewportBottom;
    }
    @Override public boolean method_25402(double mx,double my,int button){
        if(button==0&&overViewport(mx,my)){
            int axis=preview.editorHitGizmo(mx,my,assembly.selectedIndex(),viewportLeft,viewportTop,viewportRight,viewportBottom);
            if(axis>=0 && assembly.selected()!=null){
                try{stepValue(rotateMode?angleInput:moveInput,rotateMode?360:1000);}
                catch(Exception ex){status="Pas de deplacement/rotation invalide";return true;}
                dragAxis=PreciseFreeAssembly.Axis.values()[axis];
                dragFrame=preview.editorDragFrame(viewportLeft,viewportTop,viewportRight,viewportBottom);
                var p=assembly.selected();
                dragOriginX=p.x();dragOriginY=p.y();dragOriginZ=p.z();
                dragMouseX=mx;dragMouseY=my;lastDragValue=Double.NaN;
                draggingGizmo=assembly.beginGesture();
                status="Glisse la poignee "+dragAxis+" ("+(rotateMode?"rotation":"deplacement")+")";
                return true;
            }
            int picked=preview.editorPickPart(mx,my,assembly.selectedIndex(),method_25442(),
                    viewportLeft,viewportTop,viewportRight,viewportBottom);
            if(picked>=0&&assembly.select(picked)){refreshFields();
                status="Piece "+(picked+1)+" / "+assembly.size()+" : "+assembly.selected().partId();}
            else status="Aucune piece sous le curseur";
            return true;
        }
        if(preview.editorPreviewMouseClick(mx,my,button,viewportLeft,viewportTop,viewportRight,viewportBottom))return true;
        return super.method_25402(mx,my,button);
    }
    @Override public boolean method_25403(double mx,double my,int button,double dx,double dy){
        if(button==0&&draggingGizmo&&assembly.selected()!=null){
            try{
                double step=stepValue(rotateMode?angleInput:moveInput,rotateMode?360:1000);
                double raw=rotateMode?(mx-dragMouseX)*1.35:
                        PreviewSelectionMath.axisDrag(dragFrame,mx,my,dragMouseX,dragMouseY,
                                dragOriginX,dragOriginY,dragOriginZ,dragAxis.ordinal());
                double delta=PreviewSelectionMath.snap(raw,step);
                if(Double.compare(delta,lastDragValue)==0)return true;
                if(assembly.updateGesture(dragAxis,delta,rotateMode)){
                    lastDragValue=delta;dirty=true;preview.applyFreeEdits(assembly.result());
                    status=(rotateMode?"Rotation ":"Deplacement ")+dragAxis+" : "+fmt(delta)+
                            (rotateMode?" deg":" LDU")+" (Ctrl+Z pour annuler)";
                }
            }catch(Exception ex){status="Manipulation interrompue : "+ex.getMessage();}
            return true;
        }
        if(preview.editorPreviewMouseDrag(button,dx,dy))return true;
        return super.method_25403(mx,my,button,dx,dy);
    }
    @Override public boolean method_25406(double mx,double my,int button){
        if(button==0&&draggingGizmo){
            draggingGizmo=false;assembly.finishGesture();refreshFields();return true;
        }
        if(preview.editorPreviewMouseRelease(button))return true;
        return super.method_25406(mx,my,button);
    }
    @Override public boolean method_25401(double mx,double my,double horizontal,double vertical){
        if(preview.editorPreviewWheel(mx,my,vertical,viewportLeft,viewportTop,viewportRight,viewportBottom))return true;
        return super.method_25401(mx,my,horizontal,vertical);
    }
    @Override public boolean method_25404(int key,int scancode,int modifiers){
        if((modifiers & GLFW.GLFW_MOD_CONTROL)!=0){
            if(key==GLFW.GLFW_KEY_Z){change(assembly.undo(),"Annulation");return true;}
            if(key==GLFW.GLFW_KEY_Y){change(assembly.redo(),"Retablissement");return true;}
            if(key==GLFW.GLFW_KEY_S){save();return true;}
            if(key==GLFW.GLFW_KEY_D){change(assembly.duplicate(),"Piece dupliquee");return true;}
        }
        if(!(method_25399() instanceof class_342)){
            if(key==GLFW.GLFW_KEY_G&&!rotateMode){return true;}
            if(key==GLFW.GLFW_KEY_G&&rotateMode){toggleMode();return true;}
            if(key==GLFW.GLFW_KEY_R&&!rotateMode){toggleMode();return true;}
            if(key==GLFW.GLFW_KEY_R&&rotateMode){return true;}
        }
        if(key==GLFW.GLFW_KEY_O && !(method_25399() instanceof class_342)){
            preview.toggleGpuPreview();status="Apercu GPU/CPU bascule (touche O)";return true;
        }
        if(key==GLFW.GLFW_KEY_ESCAPE){assembly.finishGesture();field_22787.method_1507(preview);return true;}
        return super.method_25404(key,scancode,modifiers);
    }
}
