package fr.brickcraft.client;

import fr.brickcraft.client.BrickGuideController.Material;
import fr.brickcraft.client.BrickGuideController.Mode;
import fr.brickcraft.world.PreciseDisplayEntity;
import org.lwjgl.glfw.GLFW;
import java.util.*;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Compact overlay UI: keep the model visible in the live world behind the controls. */
public final class BrickGuideScreen extends class_437 {
    private int projectIndex=0,materialPage=0;
    private boolean firstInit=true;
    private String message="";
    private int rows(){return Math.clamp((field_22790-365)/14,1,8);}
    public BrickGuideScreen(){super(class_2561.method_43470(BrickI18n.tr("BrickCraft - Notices interactives")));}
    private void button(int x,int y,int w,int h,String name,Runnable action){
        method_37063(class_4185.method_46430(class_2561.method_43470(BrickI18n.tr(name)),b->action.run()).method_46434(x,y,w,h).method_46431());
    }
    @Override protected void method_25426(){
        method_37067();
        var visible=BrickGuideController.nearby(field_22787);
        int panel=Math.min(390,field_22789-24),x=12;
        if(firstInit){
            firstInit=false;
            if(BrickGuideController.active()){
                for(int i=0;i<visible.size();i++)
                    if(visible.get(i).method_11016().equals(BrickGuideController.anchor())){
                        projectIndex=i;break;
                    }
            }
        }
        if(!visible.isEmpty()&&!BrickGuideController.active()){
            projectIndex=Math.clamp(projectIndex,0,visible.size()-1);
            BrickGuideController.attach(field_22787,visible.get(projectIndex));
        }
        int y=48;
        button(x,y,38,20,"<",()->{cycle(-1);});
        button(x+42,y,Math.max(60,panel-92),20,"Projet " +(visible.isEmpty()?"indisponible":
             "#"+(projectIndex+1)+" / "+visible.size()),()->cycle(1));
        button(x+panel-44,y,44,20,">",()->cycle(1));
        y+=31;
        int col=(panel-8)/2;
        button(x,y,col,22,"Couches",()->switchMode(Mode.LAYERS));
        button(x+col+8,y,col,22,"Etapes Studio",()->switchMode(Mode.SOURCE));
        y+=26;
        button(x,y,col,22,"Lots de 20",()->switchMode(Mode.LOTS));
        button(x+col+8,y,col,22,"Piece / piece",()->switchMode(Mode.PIECES));
        y+=38;
        button(x,y,56,22,"|<",()->jump(0));
        button(x+62,y,56,22,"-1",()->jump(BrickGuideController.step()-1));
        button(x+124,y,Math.max(50,panel-248),22,"+1",()->jump(BrickGuideController.step()+1));
        button(x+panel-118,y,56,22,"+10",()->jump(BrickGuideController.step()+10));
        button(x+panel-56,y,56,22,">|",()->jump(BrickGuideController.total()));
        y+=36;
        button(x,y,col,21,"Verifier pieces",()->{
            message=BrickGuideController.verifyRealPlacedParts(field_22787);materialPage=0;});
        button(x+col+8,y,col,21,"Confirmer (manuel)",()->{
            message=BrickGuideController.confirmManually(field_22787);materialPage=0;});
        y+=27;
        button(x,y,panel-8,19,"Cible 3D : "+(BrickGuideController.targetOverlay()?"ON":"OFF"),()->{
            BrickGuideController.toggleTargetOverlay();method_25426();});
        y+=25;
        button(x,y,col,21,"< Materiaux",()->{materialPage=Math.max(0,materialPage-1);});
        button(x+col+8,y,col,21,"Materiaux >",()->{materialPage++;});
        int lastY=Math.max(field_22790-38,y+146);
        button(x,lastY,col,22,"Quitter le menu",()->method_25419());
        button(x+col+8,lastY,col,22,"Retirer la notice",()->{
            BrickGuideController.hide();method_25419();
        });
    }
    private void cycle(int delta){
        var projects=BrickGuideController.nearby(field_22787);
        if(projects.isEmpty())return;
        projectIndex=Math.floorMod(projectIndex+delta,projects.size());
        BrickGuideController.attach(field_22787,projects.get(projectIndex));
        materialPage=0;method_25426();
    }
    private void jump(int step){BrickGuideController.jump(step);materialPage=0;}
    private void switchMode(Mode next){
        if(next==Mode.SOURCE&&!BrickGuideController.sourceAvailable()){
            message="Place le .io original dans config/brickcraft/imports/";
            return;
        }
        BrickGuideController.setMode(next);materialPage=0;message="";
    }
    @Override public boolean method_25404(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_PAGE_UP){jump(BrickGuideController.step()-1);return true;}
        if(key==GLFW.GLFW_KEY_PAGE_DOWN){jump(BrickGuideController.step()+1);return true;}
        if(key==GLFW.GLFW_KEY_HOME){jump(0);return true;}
        if(key==GLFW.GLFW_KEY_END){jump(BrickGuideController.total());return true;}
        return super.method_25404(key,scan,mods);
    }
    @Override public void method_25394(class_332 draw,int mouseX,int mouseY,float delta){
        int panel=Math.min(390,field_22789-24),x=12;
        draw.method_25294(x-7,17,x+panel+7,field_22790-9,0xE9112635);
        draw.method_25294(x-7,17,x+panel+7,20,0xFF46CBD4);
        super.method_25394(draw,mouseX,mouseY,delta);
        draw.method_25303(field_22793,BrickI18n.tr("BRICKCRAFT / NOTICE"),x+3,29,0xFFBDEFF6);
        int y=259;
        if(!BrickGuideController.active()){
            draw.method_25303(field_22793,BrickI18n.tr("Aucun projet visible : rapproche-toi du LEGO."),x+3,y,0xFFF0BF8F);
            return;
        }
        String[] captions={
            "Mode : "+switch(BrickGuideController.mode()){
                case SOURCE->"Etapes d'origine Studio";case LAYERS->"Couches calculees";
                case LOTS->"Lots automatiques";case PIECES->"Piece par piece";},
            "Progression : "+BrickGuideController.step()+" / "+BrickGuideController.total(),
            "Pieces visibles : "+BrickGuideController.shownCount()+" / "+BrickGuideController.partCount(),
            BrickGuideController.stepTitle(),
        };
        int maxTextY=field_22790-56;
        for(String s:captions){
            if(y+12>maxTextY)break;
            draw.method_25303(field_22793,BrickI18n.tr(cut(s,panel-8)),x+3,y,0xFFD9F3FA);y+=14;
        }
        int left=x+3;
        if(y+16<maxTextY)draw.method_25303(field_22793,BrickI18n.tr("--- Pieces pour cette etape ---"),left,y+4,0xFFF1D599);
        y+=23;
        List<BrickGuideController.Material> materials=BrickGuideController.materials();
        int maxPage=Math.max(0,(materials.size()-1)/rows());
        materialPage=Math.clamp(materialPage,0,maxPage);
        int from=materialPage*rows();
        for(int i=from;i<Math.min(materials.size(),from+rows());i++){
            var m=materials.get(i);
            int rgb=fr.brickcraft.ldraw.LDrawLibrary.argb(m.color(),0xAAAAAA)|0xFF000000;
            if(y+12>=maxTextY)break;
            draw.method_25294(left,y,left+9,y+9,rgb);
            String line="x"+m.quantity()+"  "+m.part()+"  |  "+BrickGuideController.colorName(m.color());
            draw.method_25303(field_22793,BrickI18n.tr(cut(line,panel-25)),left+14,y,0xFFECF5F8);y+=14;
        }
        y+=5;
        if(y+12<maxTextY)draw.method_25303(field_22793,BrickI18n.tr("Materiaux page "+(materialPage+1)+"/"+(maxPage+1)),left,y,0xFFB1C9D4);
        y+=15;
        String state=BrickGuideController.sourceMessage();
        if(y<field_22790-54)draw.method_25303(field_22793,BrickI18n.tr(cut(state,panel-8)),left,y,0xFF85DED2);
        if(!message.isEmpty()&&y+14<field_22790-50)
            draw.method_25303(field_22793,BrickI18n.tr(cut(message,panel-8)),left,y+14,0xFFFFC184);
    }
    private String cut(String s,int available){
        s=BrickI18n.tr(s);
        if(field_22793.method_1727(s)<=available)return s;
        while(s.length()>3 && field_22793.method_1727(s+"...")>available)s=s.substring(0,s.length()-1);
        return s+"...";
    }
    @Override public void method_25419(){field_22787.method_1507(null);}
    @Override public boolean method_25421(){return false;}
}
