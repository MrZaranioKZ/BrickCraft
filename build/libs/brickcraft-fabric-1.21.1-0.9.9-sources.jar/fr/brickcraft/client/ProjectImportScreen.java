package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.StudioProjectAnalysis;
import ;
import fr.brickcraft.client.PreviewSelectionMath.Frame;
import fr.brickcraft.client.PreviewSelectionMath.Point;
import fr.brickcraft.importer.BrickCraftProjectConverter;
import fr.brickcraft.importer.PreciseProjectIO;
import fr.brickcraft.importer.PreciseLDrawGeometry;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.importer.PreciseWorldModel.Bounds;
import fr.brickcraft.net.PreciseExportPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.ldraw.LDrawLibrary.Colour;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3965;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/** Direct .io/.mpd/.ldr loader, with lossless diagnostics and a source-coordinate preview. */
public final class ProjectImportScreen extends class_437 {
    private final BrickStudioScreen parent;
    private final Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
    private List<Path> sources=List.of();
    private int index=0;
    private LDrawProjectReader.Result current;
    private StudioProjectAnalysis.Summary summary;
    private boolean dirtyPreview=false;
    private Path loadedFile=null;
    private String status="Depose un fichier .io, .mpd ou .ldr dans le dossier imports.";
    private double orbit=.72, zoom=1.0, panX=0, panY=0;
    private boolean orbiting=false,panning=false;
    private int lastX,lastY;
    /** 0=points, 1=oriented bounding boxes, 2=actual LDraw triangles with adaptive LOD. */
    private int previewMode=2;
    // A bounded per-scene cache avoids decoding a huge .dat on every rendered frame.
    private final Map<String,LDrawLibrary.Mesh> meshes=new HashMap<>();
    private final Set<String> noMesh=new HashSet<>();
    private int cachedTriangles=0;
    private static final int MAX_CACHED_TRIANGLES=350_000;
    private static final int MAX_PART_TRIANGLES=2_500;
    private static final int MAX_RENDER_TRIANGLES=12_000;
    private int trianglesRendered=0;
    private int realMeshesRendered=0;
    private List<PreviewPart> previewParts=List.of();
    private double[] previewBounds=null; // min X/Y/Z, max X/Y/Z in original LDU
    private record PreviewPart(double[][] corners, int color, double depthX, double depthY, double depthZ,
                               LDrawProjectReader.Instance instance){}
    private record Dot(int x,int y,double depth,int color){}
    private record Pixel(int x,int y){}
    private record Face(Pixel[] verts,double depth,int color){}
    public ProjectImportScreen(BrickStudioScreen parent){
        super(class_2561.method_43470("BrickCraft - Importer un projet BrickLink"));
        this.parent=parent;
        reloadFiles();
    }
    private void reloadFiles(){
        try{
            Files.createDirectories(folder);
            try(var stream=Files.list(folder)){
                sources=stream.filter(Files::isRegularFile).filter(p->{
                    String n=p.getFileName().toString().toLowerCase(Locale.ROOT);
                    return n.endsWith(".io")||n.endsWith(".mpd")||n.endsWith(".ldr")||n.endsWith(".bcpx");
                }).sorted(Comparator.comparing(p->p.getFileName().toString(),String.CASE_INSENSITIVE_ORDER)).limit(200).toList();
            }
            index=Math.min(Math.max(0,index),Math.max(0,sources.size()-1));
        }catch(IOException e){status="Lecture du dossier impossible : "+e.getMessage();sources=List.of();}
    }
    private Path selectedFile(){return sources.isEmpty()?null:sources.get(index);}
    private void clearLoadedProject(){
        current=null;summary=null;dirtyPreview=false;loadedFile=null;
        previewParts=List.of();previewBounds=null;
        meshes.clear();noMesh.clear();cachedTriangles=0;
        panX=panY=0;zoom=1;orbit=.72;
    }
    private void backToStudio(){
        Runnable action=()->field_22787.method_1507(parent);
        if(dirtyPreview)field_22787.method_1507(new BrickConfirmScreen(this,"Quitter sans enregistrer ?",
                "Les changements non enregistres ne seront plus accessibles.",action));
        else action.run();
    }
    private void requestUnload(){
        if(current==null){status="Aucun projet charge : choisis un fichier puis Analyser.";return;}
        Runnable action=()->{clearLoadedProject();status="Projet decharge de l'editeur. Le fichier et les projections du monde sont conserves.";};
        if(dirtyPreview)field_22787.method_1507(new BrickConfirmScreen(this,
                "Decharger les modifications non sauvegardees ?",
                "Les modifications non enregistrees seront perdues, mais aucun fichier ne sera efface.",action));
        else action.run();
    }
    private void select(int offset){
        if(sources.isEmpty())return;
        Runnable action=()->{
            index=Math.floorMod(index+offset,sources.size());
            clearLoadedProject();status="Selection : "+selectedFile().getFileName()+" (non charge)";
        };
        if(dirtyPreview)field_22787.method_1507(new BrickConfirmScreen(this,"Changer de projet ?",
                "Les modifications non sauvegardees de l'editeur seront perdues.",action));
        else action.run();
    }
    private void requestAnalyze(){
        if(dirtyPreview)field_22787.method_1507(new BrickConfirmScreen(this,"Recharger le fichier ?",
                "Les changements non sauvegardes seront remplaces par le fichier sur disque.",this::analyze));
        else analyze();
    }
    private void analyze(){
        clearLoadedProject();
        Path source=selectedFile();
        if(source==null){status="Aucun fichier. Copie ton .io dans config/brickcraft/imports/";return;}
        try{
            current=source.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".bcpx")?
                    PreciseProjectIO.read(source):LDrawProjectReader.inspect(source);
            loadedFile=source;
            summary=StudioProjectAnalysis.analyze(current);
            meshes.clear();noMesh.clear();cachedTriangles=0;
            buildPreview();
            status="Charge : "+summary.quickStatus()+" (points / volumes / maillages)";
            panX=panY=0;zoom=1;
            saveReport();
        }catch(Exception e){current=null;summary=null;previewParts=List.of();previewBounds=null;
            status="Erreur d'analyse : "+e.getMessage();}
    }
    private void savePrecise(){
        if(current==null||loadedFile==null){status="Analyse d'abord un projet";return;}
        try {
            String original=loadedFile.getFileName().toString();
            String stem=original.replaceAll("(?i)\\.(bcpx|io|ldr|mpd)$","")
                    .replaceAll("[^a-zA-Z0-9._-]","_");
            if(stem.isBlank())stem="projet";
            Path output=folder.resolve(stem+"_copie_v097.bcpx");
            int seq=2;
            while(Files.exists(output))output=folder.resolve(stem+"_copie_v097_"+(seq++)+".bcpx");
            PreciseProjectIO.save(output,current);
            status="Sauvegarde precise (sans arrondi) : "+output.getFileName();
            dirtyPreview=false;reloadFiles();
        }catch(IOException e){status="BCPX : "+e.getMessage();}
    }
    private void cyclePreview(){previewMode=(previewMode+1)%3;method_41843();}
    private String modeName(){return switch(previewMode){case 0->"points";case 1->"volumes";default->"maillages";};}
    private void saveReport()throws IOException {
        if(summary==null || selectedFile()==null)return;
        String name=selectedFile().getFileName().toString().replaceAll("[^a-zA-Z0-9._-]","_");
        Path report=folder.resolve("reports").resolve(name+".diagnostic.txt");
        Files.createDirectories(report.getParent());
        Files.writeString(report,StudioProjectAnalysis.report(summary,selectedFile().getFileName().toString()));
    }
    private void convert(){
        if(current==null){status="Analyse d'abord le projet";return;}
        if(summary.missingInstances()>0 || summary.angled()>0){
            status="Import sans perte impossible : references manquantes ou rotations libres (voir rapport)";return;
        }
        try{
            BrickCraftProjectConverter.Conversion c=BrickCraftProjectConverter.convert(current);
            if(!c.success()){
                status="Conversion refusee : "+c.errors().get(0);
                return;
            }
            if(parent.acceptImportedProject(c.grid(),c.pieces())){
                field_22787.method_1507(parent);
            }else status="Le Studio refuse ce projet (limites ou collisions)";
        }catch(Exception e){status="Conversion echouee : "+e.getMessage();}
    }
    /** Visual-only, server-validated BCPX projection. The classic solid-brick world is untouched. */
    private void projectWorld(){
        if(current==null){status="Analyse un projet avant de le projeter";return;}
        if(field_22787.field_1724==null || field_22787.field_1687==null || field_22787.field_1761==null ||
                !field_22787.field_1761.method_2914()){
            status="Projection disponible uniquement en mode Creatif";return;
        }
        class_239 target=field_22787.field_1724.method_5745(12.0,1.0f,false);
        if(!(target instanceof class_3965 hit) || target.method_17783()!=class_239.class_240.field_1332){
            status="Vise un bloc au sol avant d'ouvrir le Studio";return;
        }
        class_2338 anchor=hit.method_17777().method_10093(hit.method_17780());
        if(!field_22787.field_1687.method_8320(anchor).method_26215()){
            status="Espace d'ancrage occupe : vise une surface avec de l'air au-dessus";return;
        }
        try{
            var bounds=PreciseWorldModel.analyze(current.parts());
            if(anchor.method_10264()+bounds.height()+1>=field_22787.field_1687.method_31600()){
                status="Chateau trop haut pour cet endroit";return;
            }
            ClientPlayNetworking.send(PreciseExportPayload.begin(anchor,current.parts().size()));
            for(int offset=0;offset<current.parts().size();offset+=PreciseExportPayload.BATCH_SIZE){
                int end=Math.min(current.parts().size(),offset+PreciseExportPayload.BATCH_SIZE);
                ClientPlayNetworking.send(PreciseExportPayload.batch(offset,current.parts().subList(offset,end)));
            }
            ClientPlayNetworking.send(PreciseExportPayload.commit());
            status="Projection envoyee : "+current.parts().size()+" pieces, "+bounds.mappedPrints()+
                    " imprimees sans texture. Retourne en jeu pour voir le resultat.";
        }catch(Exception e){status="Projection refusee : "+e.getMessage();}
    }
    private void addButton(int x,int y,int w,int h,String label,Runnable click){
        if(w<16)return;
        method_37063(class_4185.method_46430(class_2561.method_43470(label),b->click.run()).method_46434(x,y,w,h).method_46431());
    }
    /** V0.9.6: the advanced editor retains original doubles/matrices and reuses this preview. */
    private void openFreeEditor(){
        LDrawProjectReader.Result source=current!=null?current:
                new LDrawProjectReader.Result("brickcraft_free.ldr",0,List.of(),List.of());
        String file=loadedFile!=null?loadedFile.getFileName().toString():
                selectedFile()==null?"atelier.ldr":selectedFile().getFileName().toString();
        if(source.parts().size()>PreciseWorldModel.MAX_PARTS){
            status="Editeur libre limite a 4096 pieces; utilise un sous-modele.";return;
        }
        field_22787.method_1507(new PreciseFreeScreen(this,source,file));
    }
    void applyFreeEdits(LDrawProjectReader.Result result){
        current=result;
        // Keep LDraw preview meshes cached when only one transform changes.
        if(current.parts().isEmpty()){summary=null;previewParts=List.of();previewBounds=null;return;}
        summary=StudioProjectAnalysis.analyze(current);
        buildPreview();dirtyPreview=true;
        status="Atelier libre : "+current.parts().size()+" pieces (modifications non enregistrees)";
    }
    void refreshFreeFiles(Path destination){
        reloadFiles();
        int found=sources.indexOf(destination);
        if(found>=0)index=found;
        loadedFile=destination;
        dirtyPreview=false;
    }
    @Override protected void method_25426(){
        int pWidth=Math.max(228,Math.min(315,field_22789/3));
        addButton(10,40,(pWidth-25)/2,20,"< Projet",()->select(-1));
        addButton((pWidth+5)/2,40,(pWidth-25)/2,20,"Projet >",()->select(1));
        addButton(10,67,pWidth-20,20,"Actualiser les fichiers",()->{reloadFiles();status="Dossier actualise";});
        addButton(10,93,pWidth-20,20,"1. Analyser / previsualiser",this::requestAnalyze);
        addButton(10,120,pWidth-20,20,"2. Importer dans le Studio (strict)",this::convert);
        addButton(10,145,pWidth-20,18,"Apercu : "+modeName()+" (V)",this::cyclePreview);
        addButton(10,167,pWidth-20,19,"EDITEUR LIBRE 0.9.9",this::openFreeEditor);
        addButton(10,190,pWidth-20,18,"Sauvegarder precision (.bcpx)",this::savePrecise);
        addButton(10,211,pWidth-20,19,"3. Projeter dans le monde (BETA)",this::projectWorld);
        addButton(10,236,pWidth-20,19,"Decharger le projet (editeur)",this::requestUnload);
        addButton(10,261,pWidth-20,19,"Projections du monde / retirer",()->field_22787.method_1507(new PreciseWorldProjectsScreen(this)));
        addButton(10,field_22790-47,pWidth-20,20,"Retour au Studio",this::backToStudio);
    }
    @Override public void method_25420(class_332 context,int mx,int my,float delta){}
    private void drawText(class_332 ctx,String s,int x,int y,int max,int color){
        if(max<10)return;
        if(field_22793.method_1727(s)>max){
            String suffix="...";
            int n=s.length();
            while(n>0 && field_22793.method_1727(s.substring(0,n)+suffix)>max)n--;
            s=s.substring(0,n)+suffix;
        }
        ctx.method_25303(field_22793,s,x,y,color);
    }
    @Override public void method_25394(class_332 ctx,int mx,int my,float dt){
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B111A);
        int side=Math.max(228,Math.min(315,field_22789/3));
        int left=side+6, top=36, right=field_22789-8,bottom=field_22790-34;
        ctx.method_25294(4,30,side,bottom,0xFF162330);
        ctx.method_25294(left,top,right,bottom,0xFF0A1C29);
        drawText(ctx,"BRICKCRAFT  /  IMPORT IO-LDRAW 0.9.9",10,10,field_22789-20,0xFFE2F4FF);
        // All diagnostics are constrained above the footer button, at every GUI scale.
        int statsEnd=field_22790-54;
        ctx.method_44379(6,289,side-4,Math.max(290,statsEnd));
        drawText(ctx,"Fichiers : "+sources.size()+(current!=null?" | CHARGE":" | NON CHARGE"),12,292,side-22,0xFF9BC4D7);
        drawText(ctx,selectedFile()==null?"Aucun fichier detecte":selectedFile().getFileName().toString(),12,308,side-22,0xFFFFFFFF);
        if(summary!=null){
            int y=331;
            String[] lines={
                "Pieces : "+summary.pieces()+" | Formes : "+summary.designs(),
                "Couleurs : "+summary.colors()+" | Sous-modeles : "+summary.project().submodels(),
                "Manquantes : "+summary.missingInstances()+" occurrences",
                "Rotations libres : "+summary.angled(),
                "Decalages X/Z : "+summary.fractionalX()+" / "+summary.fractionalZ(),
                "Hauteurs fines : "+summary.fractionalY(),
                "Details : imports/reports/*.txt"
            };
            for(String line:lines){
                if(y+10>statsEnd)break;
                drawText(ctx,line,12,y,side-22,y==331?0xFF71E2D5:0xFFA7C6D8);
                y+=15;
            }
        }else{
            drawText(ctx,"Pour charger : Analyser / previsualiser",12,332,side-20,0xFF9FC4D9);
            drawText(ctx,"config/brickcraft/imports/",12,349,side-20,0xFF8EDBE1);
            drawText(ctx,".io .ldr .mpd .bcpx",12,366,side-20,0xFF9FC4D9);
        }
        ctx.method_44380();
        drawText(ctx,"Clic droit : orbite | Molette : zoom | Milieu : deplacer",left+7,top+8,right-left-14,0xFFB0D9E8);
        drawText(ctx,switch(previewMode){
            case 0 -> "Origines des pieces (rapide)";
            case 1 -> "Volumes orientes (gabarits)";
            default -> "Maillages LDraw exacts avec niveau de detail adaptatif";
        },left+7,top+22,right-left-14,0xFF9BB9C8);
        if(summary!=null){
            if(previewMode==0)renderDots(ctx,left+5,top+38,right-5,bottom-5);
            else renderVolumes(ctx,left+5,top+38,right-5,bottom-5,previewMode==2);
        }else drawText(ctx,"Aucun projet charge",left+20,top+78,right-left-40,0xFF92B2C7);
        // The footer always has its own opaque band, so no overdraw from the viewport.
        ctx.method_25294(0,field_22790-24,field_22789,field_22790,0xFF142638);
        drawText(ctx,status,10,field_22790-18,field_22789-20,0xFFEED29A);
        super.method_25394(ctx,mx,my,dt);
    }
    /** Only the 3D preview is painted by the editing screen: no imported UI widgets. */
    void renderFreeViewport(class_332 ctx,int left,int top,int right,int bottom,int selection,boolean rotateMode){
        ctx.method_25294(left,top,right,bottom,0xFF0A1C29);
        if(summary==null){
            drawText(ctx,"Atelier vide : ajoute une piece",left+15,top+30,right-left-30,0xFF90B7C9);
        }else{
            if(previewMode==0)renderDots(ctx,left+4,top+4,right-4,bottom-4);
            else renderVolumes(ctx,left+4,top+4,right-4,bottom-4,previewMode==2);
            drawFreeSelected(ctx,left+4,top+4,right-4,bottom-4,selection,rotateMode);
        }
    }
    private PreviewSelectionMath.Frame editorFrame(int left,int top,int right,int bottom){
        return previewBounds==null?null:PreviewSelectionMath.frame(previewBounds,orbit,zoom,panX,panY,
                left+4,top+4,right-4,bottom-4);
    }
    PreviewSelectionMath.Frame editorDragFrame(int left,int top,int right,int bottom){
        return editorFrame(left,top,right,bottom);
    }
    int editorPickPart(double mx,double my,int selected,boolean cycling,int left,int top,int right,int bottom){
        if(mx<left+4||mx>right-4||my<top+4||my>bottom-4||previewParts.isEmpty())return -1;
        var f=editorFrame(left,top,right,bottom);
        if(f==null)return -1;
        ArrayList<double[][]> volumes=new ArrayList<>(previewParts.size());
        for(var part:previewParts)volumes.add(part.corners());
        return PreviewSelectionMath.choose(PreviewSelectionMath.hits(f,volumes,mx,my),selected,cycling);
    }
    int editorHitGizmo(double mx,double my,int selection,int left,int top,int right,int bottom){
        if(selection<0||selection>=previewParts.size())return -1;
        var f=editorFrame(left,top,right,bottom);
        if(f==null)return -1;
        var p=previewParts.get(selection).instance();
        int chosen=-1;double best=100; // 10px radius on axis tips
        for(int axis=0;axis<3;axis++){
            var point=PreviewSelectionMath.axisEnd(f,p.x(),p.y(),p.z(),axis,gizmoLength(f));
            double dx=point.x()-mx,dy=point.y()-my,d=dx*dx+dy*dy;
            if(d<=best){best=d;chosen=axis;}
        }
        return chosen;
    }
    private static final int[][] BOX_EDGES={{0,1},{0,2},{0,4},{1,3},{1,5},{2,3},
                                             {2,6},{3,7},{4,5},{4,6},{5,7},{6,7}};
    private static final int[] GIZMO_COLORS={0xFFFF6565,0xFF75E49F,0xFF75ABFF};
    private static double gizmoLength(PreviewSelectionMath.Frame f){
        // A 40-LDU gizmo becomes invisible on large imported projects.
        // Keep handles ~35 GUI pixels apart, independent of the construction scale.
        return Math.max(20,Math.min(5000,35/Math.max(.0001,f.unit())));
    }
    private void drawFreeSelected(class_332 ctx,int x1,int y1,int x2,int y2,int selected,boolean rotate){
        if(selected<0||selected>=previewParts.size())return;
        var f=PreviewSelectionMath.frame(previewBounds,orbit,zoom,panX,panY,x1,y1,x2,y2);
        var box=previewParts.get(selected);
        var corners=PreviewSelectionMath.corners(f,box.corners());
        ctx.method_44379(x1,y1,x2,y2);
        for(int[] edge:BOX_EDGES){
            var a=corners[edge[0]];var b=corners[edge[1]];
            drawEditorLine(ctx,a.x(),a.y(),b.x(),b.y(),0xFFFFD46C);
        }
        var p=box.instance();var origin=f.project(p.x(),p.y(),p.z());
        for(int axis=0;axis<3;axis++){
            var tip=PreviewSelectionMath.axisEnd(f,p.x(),p.y(),p.z(),axis,gizmoLength(f));
            drawEditorLine(ctx,origin.x(),origin.y(),tip.x(),tip.y(),GIZMO_COLORS[axis]);
            int tx=(int)Math.round(tip.x()),ty=(int)Math.round(tip.y());
            ctx.method_25294(tx-4,ty-4,tx+5,ty+5,GIZMO_COLORS[axis]);
            ctx.method_25303(field_22793,"XYZ".substring(axis,axis+1),tx+5,ty-4,0xFFFFFFFF);
        }
        ctx.method_44380();
        // Keep the active-piece label BELOW the two instruction lines of the viewport.
        drawText(ctx,(rotate?"ROTATION":"DEPLACEMENT")+" | #"+(selected+1)+"  "+p.partId(),
                x1+8,y1+38,x2-x1-16,0xFFFFDF8B);
    }
    private static void drawEditorLine(class_332 ctx,double ax,double ay,double bx,double by,int color){
        // GUI-independent Bresenham line; only 12 bounding-box edges + 3 handles.
        int x=(int)Math.round(ax),y=(int)Math.round(ay),x2=(int)Math.round(bx),y2=(int)Math.round(by);
        int dx=Math.abs(x2-x),dy=Math.abs(y2-y),sx=x<x2?1:-1,sy=y<y2?1:-1,err=dx-dy;
        for(int steps=0;steps<4000;steps++){
            ctx.method_25294(x,y,x+2,y+2,color);
            if(x==x2&&y==y2)break;
            int e=err*2;
            if(e>-dy){err-=dy;x+=sx;}
            if(e<dx){err+=dx;y+=sy;}
        }
    }
    boolean editorPreviewMouseClick(double x,double y,int button,int left,int top,int right,int bottom){
        if(x<left||x>right||y<top||y>bottom)return false;
        if(button==1){orbiting=true;lastX=(int)x;lastY=(int)y;return true;}
        if(button==2){panning=true;lastX=(int)x;lastY=(int)y;return true;}
        return false;
    }
    boolean editorPreviewMouseDrag(int button,double dx,double dy){
        if(button==1&&orbiting){orbit+=dx*.01;return true;}
        if(button==2&&panning){panX+=dx;panY+=dy;return true;}
        return false;
    }
    boolean editorPreviewMouseRelease(int button){
        if(button==1&&orbiting){orbiting=false;return true;}
        if(button==2&&panning){panning=false;return true;}
        return false;
    }
    boolean editorPreviewWheel(double x,double y,double vertical,int left,int top,int right,int bottom){
        if(x<left||x>right||y<top||y>bottom)return false;
        zoom=Math.max(.1,Math.min(15,zoom*Math.pow(1.15,vertical)));return true;
    }
    /**
     * Source coordinates are preserved: each part box is transformed by its full
     * 3x3 LDraw matrix. No grid rounding, replacement design or world export here.
     * The boxes are only a fast diagnostic preview, not actual part triangles.
     */
    private void buildPreview(){
        if(summary==null){previewParts=List.of();previewBounds=null;return;}
        var source=summary.project().parts();
        java.util.Map<String,double[]> boundsCache=new java.util.HashMap<>();
        ArrayList<PreviewPart> result=new ArrayList<>(source.size());
        double[] all={Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY,
                      Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY,Double.NEGATIVE_INFINITY};
        for(var p:source){
            // The actual LDraw bounds refer to its local origin, not the normalized Minecraft mesh.
            double[] local=boundsCache.computeIfAbsent(p.partId(),id->{
                String actual=fr.brickcraft.importer.PreciseReferenceMapper.geometryId(id);
                double[] b=actual==null?null:LDrawLibrary.originalBounds(actual);
                return b!=null?b:new double[]{-10,-12,-10,10,12,10};
            });
            double[] m=p.matrix();
            double[][] corners=new double[8][3];
            for(int k=0;k<8;k++){
                double x=((k&1)==0)?local[0]:local[3];
                double y=((k&2)==0)?local[1]:local[4];
                double z=((k&4)==0)?local[2]:local[5];
                double[] point={p.x()+m[0]*x+m[1]*y+m[2]*z,
                                p.y()+m[3]*x+m[4]*y+m[5]*z,
                                p.z()+m[6]*x+m[7]*y+m[8]*z};
                corners[k]=point;
                for(int axis=0;axis<3;axis++){
                    all[axis]=Math.min(all[axis],point[axis]);
                    all[axis+3]=Math.max(all[axis+3],point[axis]);
                }
            }
            var color=LDrawLibrary.color(p.color());
            int argb=color==null?0xFFCED4DE:0xFF000000|color.rgb();
            result.add(new PreviewPart(corners,argb,p.x(),p.y(),p.z(),p));
        }
        previewParts=List.copyOf(result);
        previewBounds=all;
    }

    private void renderVolumes(class_332 ctx,int x1,int y1,int x2,int y2,boolean detailed){
        if(previewParts.isEmpty() || previewBounds==null || x2<=x1 || y2<=y1)return;
        double[] b=previewBounds;
        double cx=(b[0]+b[3])/2,cy=(b[1]+b[4])/2,cz=(b[2]+b[5])/2;
        double sx=Math.max(20,b[3]-b[0]),sy=Math.max(8,b[4]-b[1]),sz=Math.max(20,b[5]-b[2]);
        double co=Math.cos(orbit),si=Math.sin(orbit);
        double boundW=1,boundH=1;
        for(int i=0;i<8;i++){
            double x=((i&1)==0?-sx:sx)/2;
            double y=((i&2)==0?-sy:sy)/2;
            double z=((i&4)==0?-sz:sz)/2;
            boundW=Math.max(boundW,Math.abs(x*co-z*si));
            boundH=Math.max(boundH,Math.abs((x*si+z*co)*.40+y*.86));
        }
        double unit=Math.max(0.0001,Math.min((x2-x1-36)/(2*boundW),(y2-y1-36)/(2*boundH))*zoom);
        double centerX=(x1+x2)*.5+panX,centerY=(y1+y2)*.5+panY;
        // Painters' order for opaque gabarits. The low LOD is deliberately cheap.
        ArrayList<PreviewPart> ordered=new ArrayList<>(previewParts);
        ordered.sort(Comparator.comparingDouble(p->(p.depthX()-cx)*si+(p.depthZ()-cz)*co-(p.depthY()-cy)*.55));
        ctx.method_44379(x1,y1,x2,y2);
        int rendered=0;
        trianglesRendered=0;realMeshesRendered=0;
        int[] loadsLeft={2};
        for(PreviewPart part:ordered){
            Pixel[] pts=new Pixel[8];
            int minx=Integer.MAX_VALUE,miny=Integer.MAX_VALUE,maxx=Integer.MIN_VALUE,maxy=Integer.MIN_VALUE;
            for(int k=0;k<8;k++){
                double[] v=part.corners()[k];
                double x=v[0]-cx,y=v[1]-cy,z=v[2]-cz;
                int px=(int)Math.round(centerX+(x*co-z*si)*unit);
                int py=(int)Math.round(centerY+((x*si+z*co)*.4+y*.86)*unit);
                pts[k]=new Pixel(px,py);
                minx=Math.min(minx,px);maxx=Math.max(maxx,px);
                miny=Math.min(miny,py);maxy=Math.max(maxy,py);
            }
            if(maxx<x1 || minx>x2 || maxy<y1 || miny>y2)continue;
            // Small distant parts are 2px dots; larger parts show 3D gabarits.
            if((maxx-minx)*(maxy-miny)<9){
                int px=(minx+maxx)/2,py=(miny+maxy)/2;
                ctx.method_25294(px-1,py-1,px+2,py+2,part.color());
            }else if(detailed && (maxx-minx)*(maxy-miny)>42 &&
                    drawMesh(ctx,part,cx,cy,cz,co,si,unit,centerX,centerY,x1,y1,x2,y2,loadsLeft)){
                realMeshesRendered++;
            }else{
                // Sort all six faces for this part, including arbitrary LDraw rotation.
                int[][] faces={{0,4,5,1},{2,3,7,6},{0,2,6,4},
                               {1,5,7,3},{0,1,3,2},{4,6,7,5}};
                int[] shades={78,112,84,96,90,73};
                ArrayList<Face> orderedFaces=new ArrayList<>(6);
                for(int f=0;f<faces.length;f++){
                    Pixel[] v=new Pixel[4];double depth=0;
                    for(int k=0;k<4;k++){
                        int ix=faces[f][k];v[k]=pts[ix];
                        depth+=(part.corners()[ix][0]-cx)*si+(part.corners()[ix][2]-cz)*co-(part.corners()[ix][1]-cy)*.55;
                    }
                    orderedFaces.add(new Face(v,depth,shade(part.color(),shades[f])));
                }
                orderedFaces.sort(Comparator.comparingDouble(Face::depth));
                for(Face face:orderedFaces)fillFace(ctx,face.verts(),face.color(),x1,y1,x2,y2);
            }
            rendered++;
        }
        ctx.method_44380();
        drawText(ctx,detailed?"Detail : "+realMeshesRendered+" formes reelles / "+rendered+
                " pieces, "+trianglesRendered+" triangles (LOD)":
                "Apercu : "+rendered+" volumes",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    /** A bounded, lazy mesh cache: expensive .dat files are never expanded for every instance/frame. */
    private LDrawLibrary.Mesh previewMesh(String id,int[] loadsLeft){
        if(meshes.containsKey(id))return meshes.get(id);
        if(noMesh.contains(id)||loadsLeft[0]<=0)return null;
        loadsLeft[0]--;
        LDrawLibrary.Mesh mesh=LDrawLibrary.mesh(id);
        if(mesh==null || mesh.isEmpty() || mesh.triangles()>MAX_PART_TRIANGLES ||
                cachedTriangles+mesh.triangles()>MAX_CACHED_TRIANGLES){
            noMesh.add(id);return null;
        }
        cachedTriangles+=mesh.triangles();meshes.put(id,mesh);
        return mesh;
    }
    private boolean drawMesh(class_332 ctx,PreviewPart part,double cx,double cy,double cz,
                             double co,double si,double unit,double centerX,double centerY,
                             int x1,int y1,int x2,int y2,int[] loadsLeft){
        var src=part.instance();
        LDrawLibrary.Mesh mesh=previewMesh(src.partId(),loadsLeft);
        if(mesh==null || trianglesRendered+mesh.triangles()>MAX_RENDER_TRIANGLES)return false;
        double[] bounds=LDrawLibrary.originalBounds(src.partId());
        if(bounds==null)return false;
        float[] xyz=mesh.xyz();int[] faceColors=mesh.colors();
        double[] m=src.matrix(); // Fetch the matrix once; the rasterizer runs many triangles/frame.
        ArrayList<Face> faces=new ArrayList<>(mesh.triangles());
        for(int i=0;i<mesh.triangles();i++){
            Pixel[] vertices=new Pixel[3];double[] wx=new double[3],wy=new double[3],wz=new double[3];
            for(int j=0;j<3;j++){
                int k=i*9+j*3;
                double lx=bounds[0]+xyz[k]*20.0;
                double ly=bounds[4]-xyz[k+1]*20.0;
                double lz=bounds[2]+xyz[k+2]*20.0;
                wx[j]=src.x()+m[0]*lx+m[1]*ly+m[2]*lz;
                wy[j]=src.y()+m[3]*lx+m[4]*ly+m[5]*lz;
                wz[j]=src.z()+m[6]*lx+m[7]*ly+m[8]*lz;
                double x=wx[j]-cx,y=wy[j]-cy,z=wz[j]-cz;
                vertices[j]=new Pixel((int)Math.round(centerX+(x*co-z*si)*unit),
                        (int)Math.round(centerY+((x*si+z*co)*.40+y*.86)*unit));
            }
            double ux=wx[1]-wx[0],uy=wy[1]-wy[0],uz=wz[1]-wz[0];
            double vx=wx[2]-wx[0],vy=wy[2]-wy[0],vz=wz[2]-wz[0];
            double nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
            double length=Math.sqrt(nx*nx+ny*ny+nz*nz);
            if(length<0.0000001)continue;
            // Double-sided triangles: no assumption about BFC winding or mirrored MPD transforms.
            double light=.74+.15*Math.abs(ny)/length+.12*Math.abs(nx*si+nz*co)/length;
            int argb=LDrawLibrary.meshColor(faceColors[i],src.color(),part.color()&0xFFFFFF);
            int tint=shade(argb,(int)Math.round(light*100));
            double depth=((wx[0]+wx[1]+wx[2])/3-cx)*si+
                         ((wz[0]+wz[1]+wz[2])/3-cz)*co-
                         ((wy[0]+wy[1]+wy[2])/3-cy)*.55;
            faces.add(new Face(vertices,depth,tint));
        }
        faces.sort(Comparator.comparingDouble(Face::depth));
        for(Face f:faces)fillFace(ctx,f.verts(),f.color(),x1,y1,x2,y2);
        trianglesRendered+=mesh.triangles();
        return true;
    }
    private static int shade(int color,int factor){
        int r=Math.min(255,((color>>>16)&255)*factor/100),g=Math.min(255,((color>>>8)&255)*factor/100);
        int b=Math.min(255,(color&255)*factor/100);
        return (color&0xFF000000)|(r<<16)|(g<<8)|b;
    }
    private static void fillFace(class_332 ctx,Pixel[] v,int color,int x1,int y1,int x2,int y2){
        int lo=Integer.MAX_VALUE,hi=Integer.MIN_VALUE;
        for(Pixel p:v){lo=Math.min(lo,p.y());hi=Math.max(hi,p.y());}
        lo=Math.max(lo,y1);hi=Math.min(hi,y2-1);
        for(int y=lo;y<=hi;y++){
            double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
            for(int i=0;i<v.length;i++){
                Pixel a=v[i],b=v[(i+1)%v.length];
                if(a.y()==b.y()||y<Math.min(a.y(),b.y())||y>=Math.max(a.y(),b.y()))continue;
                double xx=a.x()+(double)(y-a.y())*(b.x()-a.x())/(b.y()-a.y());
                min=Math.min(min,xx);max=Math.max(max,xx);
            }
            if(max>=min){
                int lx=Math.max(x1,(int)Math.floor(min));int hx=Math.min(x2,(int)Math.ceil(max)+1);
                if(hx>lx)ctx.method_25294(lx,y,hx,y+1,color);
            }
        }
    }

    private void renderDots(class_332 ctx,int x1,int y1,int x2,int y2){
        if(summary==null||x2<=x1||y2<=y1)return;
        int count=summary.project().parts().size();
        if(count==0)return;
        double spanX=Math.max(20,summary.maxX()-summary.minX());
        double spanZ=Math.max(20,summary.maxZ()-summary.minZ());
        double spanY=Math.max(8,summary.maxY()-summary.minY());
        double c=Math.cos(orbit),s=Math.sin(orbit);
        double[][] sample={{0,0,0},{spanX,0,0},{0,0,spanZ},{spanX,0,spanZ},
                           {0,spanY,0},{spanX,spanY,0},{0,spanY,spanZ},{spanX,spanY,spanZ}};
        double boundX=1,boundY=1;
        for(double[] v:sample){
            double px=(v[0]-spanX/2)*c-(v[2]-spanZ/2)*s;
            double py=((v[0]-spanX/2)*s+(v[2]-spanZ/2)*c)*.40-(v[1]-spanY/2)*.86;
            boundX=Math.max(boundX,Math.abs(px));boundY=Math.max(boundY,Math.abs(py));
        }
        double unit=Math.min((x2-x1-32)/2.0/boundX,(y2-y1-32)/2.0/boundY)*zoom;
        double centerX=(x1+x2)/2.+panX,centerY=(y1+y2)/2.+panY;
        ArrayList<Dot> dots=new ArrayList<>(count);
        for(var p:summary.project().parts()){
            double xx=p.x()-summary.minX()-spanX/2;
            double zz=p.z()-summary.minZ()-spanZ/2;
            double yy=summary.maxY()-p.y()-spanY/2;
            double screenX=centerX+(xx*c-zz*s)*unit;
            double depth=xx*s+zz*c;
            double screenY=centerY+(depth*.40-yy*.86)*unit;
            if(screenX<x1+1||screenX>x2-1||screenY<y1+1||screenY>y2-1)continue;
            var color=LDrawLibrary.color(p.color());
            dots.add(new Dot((int)screenX,(int)screenY,depth,color==null?0xFFCED4DE:0xFF000000|color.rgb()));
        }
        dots.sort(Comparator.comparingDouble(Dot::depth));
        ctx.method_44379(x1,y1,x2,y2);
        for(Dot d:dots){
            int size=Math.max(2,Math.min(5,(int)(unit*8)));
            ctx.method_25294(d.x-size/2,d.y-size/2,d.x+size/2+1,d.y+size/2+1,d.color);
        }
        ctx.method_44380();
        drawText(ctx,count+" origines de pieces (mode rapide)",x1+5,y2-14,x2-x1-10,0xFF8DAABF);
    }
    @Override public boolean method_25402(double x,double y,int btn){
        if(x>=Math.max(228,Math.min(315,field_22789/3))+6 && y>36 && y<field_22790-34){
            if(btn==1){orbiting=true;lastX=(int)x;lastY=(int)y;return true;}
            if(btn==2){panning=true;lastX=(int)x;lastY=(int)y;return true;}
        }
        return super.method_25402(x,y,btn);
    }
    @Override public boolean method_25403(double x,double y,int button,double dx,double dy){
        if(orbiting && button==1){orbit+=dx*.01;return true;}
        if(panning && button==2){panX+=dx;panY+=dy;return true;}
        return super.method_25403(x,y,button,dx,dy);
    }
    @Override public boolean method_25406(double x,double y,int btn){
        if(btn==1)orbiting=false;
        if(btn==2)panning=false;
        return super.method_25406(x,y,btn);
    }
    @Override public boolean method_25401(double x,double y,double horiz,double vert){
        if(x>Math.max(228,Math.min(315,field_22789/3))){zoom=Math.max(.1,Math.min(15,zoom*Math.pow(1.15,vert)));return true;}
        return super.method_25401(x,y,horiz,vert);
    }
    @Override public boolean method_25404(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE){backToStudio();return true;}
        if(key==GLFW.GLFW_KEY_R){reloadFiles();return true;}
        if(key==GLFW.GLFW_KEY_ENTER){requestAnalyze();return true;}
        if(key==GLFW.GLFW_KEY_V){cyclePreview();return true;}
        if((mods & GLFW.GLFW_MOD_CONTROL)!=0 && key==GLFW.GLFW_KEY_S){savePrecise();return true;}
        return super.method_25404(key,scan,mods);
    }
}
