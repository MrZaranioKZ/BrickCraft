package fr.brickcraft;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.ldraw.LDrawLibrary.PartInfo;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2262;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.Locale;
import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/** Server-authoritative LEGO placement, usable from chat, /execute, functions and command blocks. */
public final class BrickCraftCommands {
    private BrickCraftCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher,registryAccess,environment)->{
            var root=method_9247("brickcraft").requires(source->source.method_9259(2))
                    .executes(c->help(c.getSource()));
            root.then(method_9247("help").executes(c->help(c.getSource())));
            root.then(method_9247("list").executes(c->{
                StringBuilder names=new StringBuilder();
                for(BrickKind kind:BrickKind.values())if(kind!=BrickKind.LDRAW_PART){
                    if(names.length()>0)names.append(", ");
                    names.append(kind.name().toLowerCase(Locale.ROOT));
                }
                c.getSource().method_9226(()->class_2561.method_43470("BrickCraft : "+names),false);
                return 1;
            }));
            root.then(method_9247("place").then(method_9244("kind",StringArgumentType.word())
                    .suggests((c,b)->{
                        for(BrickKind k:BrickKind.values())if(k!=BrickKind.LDRAW_PART)
                            b.suggest(k.name().toLowerCase(Locale.ROOT));
                        return b.buildFuture();
                    })
                    .then(positionBranch(false))));
            root.then(method_9247("ldraw").then(method_9244("part",StringArgumentType.word())
                    .suggests((c,b)->{
                        for(var p:LDrawLibrary.search(b.getRemaining(),36))b.suggest(p.id());
                        return b.buildFuture();
                    })
                    .then(positionBranch(true))));
            root.then(method_9247("give").then(method_9244("part",StringArgumentType.word())
                    .suggests((c,b)->{
                        for(var p:LDrawLibrary.search(b.getRemaining(),36))b.suggest(p.id());
                        return b.buildFuture();
                    })
                    .executes(c->give(c,1))
                    .then(method_9244("count",IntegerArgumentType.integer(1,64))
                            .executes(c->give(c,IntegerArgumentType.getInteger(c,"count"))))));
            dispatcher.register(root);
        });
    }

    private static com.mojang.brigadier.builder.RequiredArgumentBuilder<class_2168, net.minecraft.class_2267> positionBranch(boolean ldraw) {
        return method_9244("pos",class_2262.method_9698())
                .executes(c->place(c,ldraw,false,false))
                .then(method_9244("color",StringArgumentType.word())
                        .executes(c->place(c,ldraw,true,false))
                        .then(method_9244("angle",IntegerArgumentType.integer(-359,359))
                                .executes(c->place(c,ldraw,true,true))));
    }

    private static int help(class_2168 source){
        source.method_9226(()->class_2561.method_43470("BrickCraft : /brickcraft place <forme> <x y z> [couleur] [angle]"),false);
        source.method_9226(()->class_2561.method_43470("BrickCraft : /brickcraft ldraw <ref> <x y z> [couleur] [angle]"),false);
        source.method_9226(()->class_2561.method_43470("BrickCraft : /brickcraft give <ref> [quantite] | /brickcraft list"),false);
        source.method_9226(()->class_2561.method_43470("Couleurs : rouge, blanc, blue, #FF0000 ou 0xFF0000. Coordonnees relatives ~ admises."),false);
        return 1;
    }

    private static int place(CommandContext<class_2168> c,boolean ldraw,boolean withColor,boolean withAngle){
        class_2168 source=c.getSource();
        String ref=StringArgumentType.getString(c,ldraw?"part":"kind");
        BrickKind kind;
        String id="";
        if(ldraw){
            id=ref.toLowerCase(Locale.ROOT);
            if(!id.matches("[a-z0-9_-]{1,32}") || !LDrawLibrary.contains(id) || LDrawLibrary.mesh(id)==null){
                source.method_9213(class_2561.method_43470("Reference LDraw absente : "+ref));return 0;
            }
            kind=BrickKind.LDRAW_PART;
        }else{
            try{kind=BrickKind.valueOf(ref.toUpperCase(Locale.ROOT));}
            catch(IllegalArgumentException ex){source.method_9213(class_2561.method_43470("Forme inconnue. /brickcraft list"));return 0;}
            if(kind==BrickKind.LDRAW_PART){source.method_9213(class_2561.method_43470("Utilise /brickcraft ldraw <ref> ..."));return 0;}
        }
        int color=0xF4F4F4;
        try{
            if(withColor)color=BrickCommandPalette.rgb(StringArgumentType.getString(c,"color"));
        }catch(IllegalArgumentException ex){source.method_9213(class_2561.method_43470(ex.getMessage()));return 0;}
        int yaw=withAngle?Math.floorMod(IntegerArgumentType.getInteger(c,"angle"),360):0;
        class_2338 target=class_2262.method_48299(c,"pos");
        if(!source.method_9225().method_24794(target)||!source.method_9225().method_22340(target)){
            source.method_9213(class_2561.method_43470("Chunk non charge ou hors du monde : "+target.method_23854()));return 0;
        }
        BrickPiece piece=new BrickPiece(kind,color,target.method_10263(),target.method_10264()*5,target.method_10260(),yaw/90,yaw,0,0,id,-1);
        if(!BrickCraft.placeCommand(source.method_9225(),source.method_44023(),piece)){
            source.method_9213(class_2561.method_43470("Placement refuse : collision, terrain, protection ou trop de cellules."));
            return 0;
        }
        String name=ldraw?id:kind.name().toLowerCase(Locale.ROOT);
        source.method_9226(()->class_2561.method_43470("BrickCraft : "+name+" place a "+target.method_23854()),false);
        return 1;
    }

    private static int give(CommandContext<class_2168> c,int count){
        class_2168 source=c.getSource();
        String id=StringArgumentType.getString(c,"part").toLowerCase(Locale.ROOT);
        if(!id.matches("[a-z0-9_-]{1,32}") || !LDrawLibrary.contains(id) || LDrawLibrary.mesh(id)==null){
            source.method_9213(class_2561.method_43470("Reference LDraw non installee : "+id));return 0;
        }
        class_3222 player=source.method_44023();
        if(player==null){source.method_9213(class_2561.method_43470("La commande give doit etre lancee par un joueur."));return 0;}
        class_1799 item=BrickPartStacks.ldraw(id,count);
        player.method_7270(item);
        source.method_9226(()->class_2561.method_43470("BrickCraft : "+count+" piece(s) LDraw "+id+" ajoutee(s) a ton inventaire"),false);
        return count;
    }
}
