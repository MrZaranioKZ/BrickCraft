package fr.brickcraft.client;

import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.world.BrickCellEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_827;

/** Renders each one-stud world cell independently (no oversized BER culling). */
public final class BrickCellRenderer implements class_827<BrickCellEntity> {
    private static final class_2960 WHITE = class_2960.method_60655("minecraft", "textures/block/white_concrete.png");
    public BrickCellRenderer(class_5614.class_5615 ignored) {}

    @Override public void render(BrickCellEntity cell,float tickDelta,class_4587 matrices,
                                 class_4597 providers,int light,int overlay) {
        class_4588 out = providers.getBuffer(class_1921.method_23572(WHITE));
        class_2338 origin = cell.method_11016();
        for (BrickPiece p : cell.pieces()) {
            if (!p.tilted() && p.angle()%90==0 && !p.kind().slope) renderFragment(out,matrices,p,origin,light);
            else if (origin.equals(p.renderAnchor())) renderWholeAngle(out,matrices,p,origin,light);
        }
    }

    @Override public boolean rendersOutsideBoundingBox(BrickCellEntity entity) { return true; }

    /** Render an arbitrary-angle piece ONCE, on its home cell, not 4-64 times. */
    private static void renderWholeAngle(class_4588 out,class_4587 matrices,
                                         BrickPiece p,class_2338 cell,int light) {
        matrices.method_22903();
        double[] center=p.center();
        matrices.method_22904(center[0]-cell.method_10263(),center[1]-cell.method_10264(),center[2]-cell.method_10260());
        matrices.method_22907(class_7833.field_40715.rotationDegrees(p.angle()));
        matrices.method_22907(class_7833.field_40714.rotationDegrees(p.pitch()));
        matrices.method_22907(class_7833.field_40718.rotationDegrees(p.roll()));
        matrices.method_22904(-p.kind().width/2.,-p.kind().plates*.2,-p.kind().length/2.);
        float w=p.kind().width,d=p.kind().length,h=p.height()/5f,eps=.009f;
        int color=p.rgb();
        float a=eps,b=w-eps,c=eps,e=d-eps;
        float far=p.kind().slope ? h*.14f : h;
        face(out,matrices,color,light,0,1,0,a,h,c,a,far,e,b,far,e,b,h,c);
        face(out,matrices,color,light,0,-1,0,a,0,e,a,0,c,b,0,c,b,0,e);
        face(out,matrices,color,light,-1,0,0,a,0,e,a,far,e,a,h,c,a,0,c);
        face(out,matrices,color,light,1,0,0,b,0,c,b,h,c,b,far,e,b,0,e);
        face(out,matrices,color,light,0,0,-1,a,0,c,a,h,c,b,h,c,b,0,c);
        face(out,matrices,color,light,0,0,1,b,0,e,b,far,e,a,far,e,a,0,e);
        if(p.kind().studs)
            for(int ix=0;ix<p.kind().width;ix++) for(int iz=0;iz<p.kind().length;iz++)
                cylinder(out,matrices,ix+.5f,iz+.5f,.3f,h,h+.2f,color,light,true);
        matrices.method_22909();
    }

    private static void renderFragment(class_4588 out, class_4587 mat, BrickPiece p,
                                       class_2338 cell,int light) {
        float yBottom=p.y()/5f-cell.method_10264();
        float yTop=p.top()/5f-cell.method_10264();
        float lo=Math.max(0,yBottom), hi=Math.min(1,yTop);
        int rgb=p.rgb();
        if (hi>lo) {
            float inset=.009f;
            float x0 = cell.method_10263() == p.x() ? inset : 0;
            float x1 = cell.method_10263() == p.x()+p.width()-1 ? 1-inset : 1;
            float z0 = cell.method_10260() == p.z() ? inset : 0;
            float z1 = cell.method_10260() == p.z()+p.length()-1 ? 1-inset : 1;
            if (yTop<=1) face(out,mat,rgb,light,0,1,0,x0,hi,z0,x0,hi,z1,x1,hi,z1,x1,hi,z0);
            if (yBottom>=0) face(out,mat,rgb,light,0,-1,0,x0,lo,z1,x0,lo,z0,x1,lo,z0,x1,lo,z1);
            if (cell.method_10263()==p.x()+p.width()-1) face(out,mat,rgb,light,1,0,0,x1,lo,z0,x1,hi,z0,x1,hi,z1,x1,lo,z1);
            if (cell.method_10263()==p.x()) face(out,mat,rgb,light,-1,0,0,x0,lo,z1,x0,hi,z1,x0,hi,z0,x0,lo,z0);
            if (cell.method_10260()==p.z()+p.length()-1) face(out,mat,rgb,light,0,0,1,x1,lo,z1,x1,hi,z1,x0,hi,z1,x0,lo,z1);
            if (cell.method_10260()==p.z()) face(out,mat,rgb,light,0,0,-1,x0,lo,z0,x0,hi,z0,x1,hi,z0,x1,lo,z0);
        }
        if (p.kind().studs) {
            float studStart=yTop, studEnd=yTop+.2f;
            float s0=Math.max(0,studStart), s1=Math.min(1,studEnd);
            if (s1>s0) cylinder(out,mat,.5f,.5f,.3f,s0,s1,rgb,light,studEnd<=1.0f);
        }
    }

    private static void cylinder(class_4588 out,class_4587 mat,float cx,float cz,float radius,
                                 float lo,float hi,int color,int light,boolean topVisible) {
        int segments=12;
        for(int i=0;i<segments;i++) {
            double a=Math.PI*2*i/segments,b=Math.PI*2*(i+1)/segments;
            float x0=cx+radius*(float)Math.cos(a), z0=cz+radius*(float)Math.sin(a);
            float x1=cx+radius*(float)Math.cos(b), z1=cz+radius*(float)Math.sin(b);
            float nx=(float)Math.cos((a+b)/2), nz=(float)Math.sin((a+b)/2);
            face(out,mat,color,light,nx,0,nz, x0,lo,z0,x0,hi,z0,x1,hi,z1,x1,lo,z1);
            if(topVisible) {
                face(out,mat,color,light,0,1,0,cx,hi,cz,x0,hi,z0,x1,hi,z1,cx,hi,cz);
            }
        }
    }

    private static void face(class_4588 out,class_4587 mat,int rgb,int light,
                             float nx,float ny,float nz,float... v) {
        for (int i=0;i<4;i++) {
            float u=(i==2||i==3)?1f:0f, t=(i==1||i==2)?1f:0f;
            out.method_56824(mat.method_23760(),v[3*i],v[3*i+1],v[3*i+2])
                    .method_39415(0xFF000000 | rgb).method_22913(u,t)
                    .method_22922(class_4608.field_21444).method_60803(light)
                    .method_60831(mat.method_23760(),nx,ny,nz);
        }
    }
}
