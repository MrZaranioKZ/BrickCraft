package fr.brickcraft;

import fr.brickcraft.core.BrickKind;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Dedicated, searchable creative-inventory category for the existing physical pieces. */
public final class BrickCreativeCatalog {
    private BrickCreativeCatalog() {}

    public static void register() {
        class_1761 group=FabricItemGroup.builder()
                .method_47321(class_2561.method_43471("itemGroup.brickcraft.main"))
                .method_47320(()->new class_1799(BrickCraft.TOOL))
                .method_47317((context, entries)->{
                    entries.method_45421(BrickCraft.GUIDE_BOOK);
                    entries.method_45421(BrickCraft.TOOL);
                    entries.method_45421(BrickCraft.LDRAW_ITEM);
                    for(String prefix:new String[]{"BRICK_","PLATE_","TILE_","SLOPE_"}) {
                        for(BrickKind kind:BrickKind.values()) {
                            if(kind.name().startsWith(prefix))entries.method_45421(BrickCraft.PART_ITEMS.get(kind));
                        }
                    }
                }).method_47324();
        class_2378.method_10230(class_7923.field_44687,class_2960.method_60655("brickcraft","main"),group);
    }
}
