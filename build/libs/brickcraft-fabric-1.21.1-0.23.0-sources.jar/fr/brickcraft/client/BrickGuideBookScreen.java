package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

/** Short visual guide, not a wall of instructions. All text is a translation key. */
public final class BrickGuideBookScreen extends class_437 {
    private static final int PAGE_COUNT = 6;
    private int page;
    public BrickGuideBookScreen() {super(class_2561.method_43471("guide.brickcraft.title"));}
    public static void open() {
        class_310 mc=class_310.method_1551();
        if (mc!=null && mc.field_1755==null) mc.method_1507(new BrickGuideBookScreen());
    }
    private class_2561 txt(String key){return class_2561.method_43471("guide.brickcraft."+key);}
    @Override protected void method_25426(){
        int w=Math.min(384,field_22789-28),left=(field_22789-w)/2,foot=Math.min(field_22790-31,Math.max(134,field_22790/2+95));
        method_37063(class_4185.method_46430(txt("previous"),b->change(-1))
                .method_46434(left+12,foot,Math.max(60,(w-36)/3),20).method_46431()).field_22763=page>0;
        method_37063(class_4185.method_46430(txt("close"),b->method_25419())
                .method_46434(left+12+(w-36)/3+6,foot,Math.max(55,(w-36)/3),20).method_46431());
        method_37063(class_4185.method_46430(txt("next"),b->change(1))
                .method_46434(left+12+((w-36)/3+6)*2,foot,Math.max(60,(w-36)/3),20).method_46431()).field_22763=page<PAGE_COUNT-1;
    }
    private void change(int d){page=Math.clamp(page+d,0,PAGE_COUNT-1);method_41843();}
    @Override public void method_25420(class_332 ctx,int mouseX,int mouseY,float delta){}
    @Override public void method_25394(class_332 ctx,int mx,int my,float delta){
        ctx.method_25294(0,0,field_22789,field_22790,0xC908101A);
        int w=Math.min(384,field_22789-28),x=(field_22789-w)/2,y=Math.max(15,field_22790/2-124),h=Math.min(244,field_22790-y-33);
        ctx.method_25294(x,y,x+w,y+h,0xFF152435);
        ctx.method_25294(x+3,y+3,x+w-3,y+h-3,0xFFE8E4D9);
        ctx.method_25294(x+8,y+8,x+w-8,y+35,0xFF1F3347);
        ctx.method_27535(field_22793,txt("title"),x+18,y+17,0xFFF7F7F7);
        ctx.method_27535(field_22793,txt("page"+(page+1)+".title"),x+17,y+48,0xFF23455A);
        ctx.method_27535(field_22793,class_2561.method_43470((page+1)+" / "+PAGE_COUNT),x+w-55,y+48,0xFF506B80);
        int iconY=y+70;
        // Item renders are native Minecraft visuals, not decorative text pretending to be screenshots.
        switch(page){
            case 0 -> {icon(ctx,BrickCraft.GUIDE_BOOK,x+22,iconY);icon(ctx,BrickCraft.TOOL,x+72,iconY);icon(ctx,BrickCraft.LDRAW_ITEM,x+122,iconY);}
            case 1 -> {icon(ctx,BrickCraft.TOOL,x+22,iconY);icon(ctx,BrickCraft.PART_ITEMS.get(fr.brickcraft.core.BrickKind.BRICK_2X4),x+72,iconY);drawArrow(ctx,x+53,iconY+8);}
            case 2 -> {icon(ctx,BrickCraft.LDRAW_ITEM,x+22,iconY);drawArrow(ctx,x+53,iconY+8);icon(ctx,BrickCraft.TOOL,x+72,iconY);}
            case 3 -> {icon(ctx,BrickCraft.LDRAW_ITEM,x+22,iconY);drawArrow(ctx,x+53,iconY+8);icon(ctx,BrickCraft.PART_ITEMS.get(fr.brickcraft.core.BrickKind.BRICK_2X4),x+72,iconY);}
            case 4 -> {icon(ctx,BrickCraft.TOOL,x+22,iconY);icon(ctx,BrickCraft.LDRAW_ITEM,x+72,iconY);}
            case 5 -> {icon(ctx,BrickCraft.PART_ITEMS.get(fr.brickcraft.core.BrickKind.SLOPE_1X2),x+22,iconY);icon(ctx,BrickCraft.GUIDE_BOOK,x+72,iconY);}
        }
        int txtY=iconY+35;
        List<class_5481> lines=field_22793.method_1728(txt("page"+(page+1)+".body"),w-38);
        int maxLines=Math.max(1,(Math.min(y+h-40,field_22790-44)-txtY)/13);
        for(int i=0;i<Math.min(lines.size(),maxLines);i++)
            ctx.method_35720(field_22793,lines.get(i),x+19,txtY+i*13,0xFF344B5D);
        super.method_25394(ctx,mx,my,delta);
    }
    private void icon(class_332 ctx,net.minecraft.class_1792 item,int x,int y){
        if(item!=null){ctx.method_25294(x-3,y-3,x+20,y+20,0xFFCADBE2);ctx.method_51427(new class_1799(item),x,y);}
    }
    private void drawArrow(class_332 ctx,int x,int y){
        ctx.method_25294(x,y,x+11,y+2,0xFF5B9CB2);ctx.method_25294(x+8,y-3,x+11,y+5,0xFF5B9CB2);
    }
    @Override public boolean method_25404(int key,int scan,int modifiers){
        if(key==GLFW.GLFW_KEY_LEFT){change(-1);return true;}
        if(key==GLFW.GLFW_KEY_RIGHT){change(1);return true;}
        return super.method_25404(key,scan,modifiers);
    }
    @Override public void method_25419(){field_22787.method_1507(null);}
    @Override public boolean method_25421(){return false;}
}
