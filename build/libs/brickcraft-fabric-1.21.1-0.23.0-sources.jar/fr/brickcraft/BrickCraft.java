package fr.brickcraft;

import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.core.BrickCapacityConfig;
import fr.brickcraft.core.ConnectorSnapper;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.ldraw.LDrawLibrary;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import fr.brickcraft.world.BrickPartItem;
import java.util.EnumMap;
import java.util.Map;
import fr.brickcraft.net.BrickActionPayload;
import fr.brickcraft.net.BrickEditPayload;
import fr.brickcraft.net.StudioExportPayload;
import fr.brickcraft.net.StudioExportStatusPayload;
import fr.brickcraft.world.StudioExportManager;
import fr.brickcraft.world.PreciseDisplayBlock;
import fr.brickcraft.world.PreciseDisplayEntity;
import fr.brickcraft.world.PreciseCollisionBlock;
import fr.brickcraft.world.PreciseCollisionEntity;
import fr.brickcraft.net.PlayerScalePayload;
import fr.brickcraft.world.PlayerScaleManager;
import fr.brickcraft.world.PrecisePhysicsManager;
import fr.brickcraft.net.PrecisePhysicsPayload;
import fr.brickcraft.world.PreciseExportManager;
import fr.brickcraft.net.PreciseExportPayload;
import fr.brickcraft.net.PreciseManagePayload;
import fr.brickcraft.net.PreciseManageStatusPayload;
import fr.brickcraft.net.PreciseWorldEditPayload;
import fr.brickcraft.world.PreciseWorldEditManager;
import fr.brickcraft.world.PreciseManageManager;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import java.util.HashMap;
import java.util.ArrayDeque;
import java.util.UUID;
import java.util.Deque;
import fr.brickcraft.world.BrickCellBlock;
import fr.brickcraft.world.BrickCellEntity;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import java.util.List;

public final class BrickCraft implements ModInitializer {
    public static final BrickCellBlock CELL = class_2378.method_10230(class_7923.field_41175,
            class_2960.method_60655("brickcraft", "cell"),
            new BrickCellBlock(class_4970.class_2251.method_9637().method_22488().method_9624().method_9632(.3f)));
    public static final PreciseDisplayBlock PRECISE_DISPLAY=class_2378.method_10230(class_7923.field_41175,
            class_2960.method_60655("brickcraft","precise_display"),
            new PreciseDisplayBlock(class_4970.class_2251.method_9637().method_22488().method_9624().method_9632(1.0f)));
    public static final PreciseCollisionBlock PRECISE_COLLISION=class_2378.method_10230(class_7923.field_41175,
            class_2960.method_60655("brickcraft","precise_collision"),
            new PreciseCollisionBlock(class_4970.class_2251.method_9637().method_22488().method_9624().method_9632(-1.0f).method_42327()));
    public static final class_2591<PreciseCollisionEntity> PRECISE_COLLISION_ENTITY=class_2378.method_10230(
            class_7923.field_41181,class_2960.method_60655("brickcraft","precise_collision"),
            FabricBlockEntityTypeBuilder.create(PreciseCollisionEntity::new,PRECISE_COLLISION).build());
    public static final class_2591<PreciseDisplayEntity> PRECISE_ENTITY=class_2378.method_10230(
            class_7923.field_41181,class_2960.method_60655("brickcraft","precise_display"),
            FabricBlockEntityTypeBuilder.create(PreciseDisplayEntity::new,PRECISE_DISPLAY).build());
    public static final class_1792 TOOL = class_2378.method_10230(class_7923.field_41178,
            class_2960.method_60655("brickcraft", "builder_wand"), new class_1792(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 GUIDE_BOOK = class_2378.method_10230(class_7923.field_41178,
            class_2960.method_60655("brickcraft", "guide_book"), new BrickGuideBookItem(new class_1792.class_1793().method_7889(1)));
    public static final class_1792 LDRAW_ITEM = class_2378.method_10230(class_7923.field_41178,
            class_2960.method_60655("brickcraft","ldraw_part"),new class_1792(new class_1792.class_1793().method_7889(64)));
    public static final Map<BrickKind, BrickPartItem> PART_ITEMS=new EnumMap<>(BrickKind.class);
    static {
        for (BrickKind kind : BrickKind.values()) {
            if(kind==BrickKind.LDRAW_PART)continue;
            BrickPartItem item = class_2378.method_10230(class_7923.field_41178,
                    class_2960.method_60655("brickcraft",kind.name().toLowerCase(java.util.Locale.ROOT)),
                    new BrickPartItem(kind,new class_1792.class_1793().method_7889(64)));
            PART_ITEMS.put(kind,item);
        }
    }
    public static final class_2591<BrickCellEntity> CELL_ENTITY = class_2378.method_10230(
            class_7923.field_41181, class_2960.method_60655("brickcraft", "cell"),
            FabricBlockEntityTypeBuilder.create(BrickCellEntity::new, CELL).build());

    private record Edit(String worldId,BrickPiece piece,boolean placement){}
    private static final class History {
        final Deque<Edit> undo=new ArrayDeque<>(), redo=new ArrayDeque<>();
    }
    private static final Map<UUID,History> HISTORIES=new HashMap<>();
    private static String worldId(class_3218 world){return world.method_27983().method_29177().toString();}
    private static void remember(class_3218 world,class_3222 player,BrickPiece piece,boolean placement){
        History history=HISTORIES.computeIfAbsent(player.method_5667(),id->new History());
        history.undo.addFirst(new Edit(worldId(world),piece,placement));
        while(history.undo.size()>64)history.undo.removeLast();
        history.redo.clear();
    }
    private static void history(class_3222 player,boolean redo){
        History h=HISTORIES.get(player.method_5667());
        if(h==null)return;
        Deque<Edit> from=redo?h.redo:h.undo, to=redo?h.undo:h.redo;
        if(from.isEmpty()){player.method_7353(class_2561.method_43471("message.brickcraft.undo.empty"),true);return;}
        Edit e=from.peekFirst();class_3218 world=player.method_51469();
        if(!e.worldId().equals(worldId(world))){
            player.method_7353(class_2561.method_43471("message.brickcraft.undo.dimension"),true);
            return;
        }
        // Undo a placement by removal, or restore a deletion; redo does the opposite.
        boolean place=redo?e.placement():!e.placement();
        boolean success=place?place(world,player,e.piece()):remove(world,player,e.piece());
        if(success){from.removeFirst();to.addFirst(e);}
        else player.method_7353(class_2561.method_43471("message.brickcraft.undo.fail"),true);
    }

    @Override public void onInitialize() {
        BrickCapacityConfig.init(FabricLoader.getInstance().getConfigDir());
        LDrawLibrary.init(FabricLoader.getInstance().getConfigDir());
        BrickCreativeCatalog.register();
        BrickCraftCommands.register();
        PayloadTypeRegistry.playC2S().register(BrickActionPayload.ID, BrickActionPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(BrickEditPayload.ID, BrickEditPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(StudioExportPayload.ID, StudioExportPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(PreciseExportPayload.ID, PreciseExportPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(PreciseManagePayload.ID, PreciseManagePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(PreciseWorldEditPayload.ID, PreciseWorldEditPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(PrecisePhysicsPayload.ID, PrecisePhysicsPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(PlayerScalePayload.ID,PlayerScalePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StudioExportStatusPayload.ID, StudioExportStatusPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PreciseManageStatusPayload.ID, PreciseManageStatusPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(StudioExportPayload.ID,
                (packet,context)->StudioExportManager.receive(context.player(),packet));
        ServerTickEvents.END_SERVER_TICK.register(StudioExportManager::tick);
        ServerPlayNetworking.registerGlobalReceiver(PreciseExportPayload.ID,
                (packet,context)->PreciseExportManager.receive(context.player(),packet));
        ServerTickEvents.END_SERVER_TICK.register(PreciseExportManager::tick);
        ServerTickEvents.END_SERVER_TICK.register(PrecisePhysicsManager::tick);
        ServerTickEvents.END_SERVER_TICK.register(PlayerScaleManager::tick);
        ServerPlayerEvents.AFTER_RESPAWN.register(PlayerScaleManager::respawn);
        ServerPlayNetworking.registerGlobalReceiver(PrecisePhysicsPayload.ID,
                (packet,context)->PrecisePhysicsManager.receive(context.player(),packet));
        ServerPlayNetworking.registerGlobalReceiver(PlayerScalePayload.ID,
                (packet,context)->PlayerScaleManager.receive(context.player(),packet));
        ServerPlayNetworking.registerGlobalReceiver(PreciseManagePayload.ID,
                (packet,context)->PreciseManageManager.receive(context.player(),packet));
        ServerPlayNetworking.registerGlobalReceiver(PreciseWorldEditPayload.ID,
                (packet,context)->PreciseWorldEditManager.receive(context.player(),packet));
        ServerPlayNetworking.registerGlobalReceiver(BrickEditPayload.ID,(packet,context)->{
            class_3222 player=context.player();
            if(!player.method_7325())history(player,packet.redo());
        });
        // Intercept left click before Minecraft destroys the entire CELL containing stacked plates.
        AttackBlockCallback.EVENT.register((player,world,hand,pos,side)->{
            if(hand!=class_1268.field_5808 || player.method_7325() || !world.method_8320(pos).method_27852(CELL))
                return net.minecraft.class_1269.field_5811;
            if(world instanceof class_3218 server && player instanceof class_3222 sp &&
                    server.method_8321(pos) instanceof BrickCellEntity cell) {
                class_3965 actual=sp.method_5745(6.0,1.0f,false) instanceof class_3965 hit?hit:null;
                if(server.method_8505(sp,pos)) {
                    BrickPiece chosen=(actual!=null && actual.method_17777().equals(pos))
                            ?cell.pickAt(actual.method_17784().field_1351,actual.method_17780()==class_2350.field_11036)
                            :cell.topmost(); // fallback if another mod changes the server-side raycast
                    if(chosen!=null && remove(server,sp,chosen)) remember(server,sp,chosen,false);
                }
            }
            return net.minecraft.class_1269.field_5812;
        });
        ServerPlayNetworking.registerGlobalReceiver(BrickActionPayload.ID, (packet, context) -> {
            class_3222 player = context.player();
            if (player.method_7325() ||
                    !(player.method_6047().method_31574(TOOL) ||
                      player.method_6047().method_7909() instanceof BrickPartItem ||
                      player.method_6047().method_31574(LDRAW_ITEM))) return;
            // A customised /brickcraft give item cannot place an unrelated part;
            // the normal generic catalogue item retains the old free-selection behaviour.
            String bound=BrickPartStacks.boundLdrawId(player.method_6047());
            if(!packet.remove() && bound!=null && (packet.piece()==null ||
                    packet.piece().kind()!=BrickKind.LDRAW_PART ||
                    !bound.equalsIgnoreCase(packet.piece().partId())))return;
            handle(player.method_51469(),player,packet);
        });
    }

    private static void handle(class_3218 world, class_3222 player, BrickActionPayload packet) {
        class_2338 hit = packet.hit();
        if (!world.method_24794(hit) || !world.method_22340(hit)
                || player.method_5707(class_243.method_24953(hit)) > 100.0) return;
        if (!world.method_8505(player, hit)) return;
        BrickPiece intent = packet.piece();
        if (intent == null || !intent.valid() ||
                !Float.isFinite(packet.localX()) ||
                !Float.isFinite(packet.localY()) || !Float.isFinite(packet.localZ())) return;

        if (packet.remove()) {
            if (world.method_8321(hit) instanceof BrickCellEntity cell) {
                BrickPiece selected = cell.pickAt(hit.method_10264()+packet.localY(), packet.side()==class_2350.field_11036);
                if (selected != null && remove(world,player,selected)) remember(world,player,selected,false);
            }
            return;
        }

        // The old single-action Studio export is intentionally disabled. Large plans must
        // use StudioExportPayload for full preflight and chunk-safe batched placement.
        if(packet.studio()) {
            player.method_7353(class_2561.method_43471("message.brickcraft.export.old_protocol"),true);
            return;
        }
        final BrickPiece candidate;
        {
            if (packet.localX() < -.01f || packet.localX() > 1.01f ||
                    packet.localY() < -.01f || packet.localY() > 1.01f ||
                    packet.localZ() < -.01f || packet.localZ() > 1.01f) return;
            boolean lego = world.method_8320(hit).method_27852(CELL);
            if (!lego && world.method_8320(hit).method_26215()) return;
            class_2350 side = packet.side();
            int px = hit.method_10263() + side.method_10148();
            int pz = hit.method_10260() + side.method_10165();
            int baseUnits = (hit.method_10264()+side.method_10164())*5;
            if (lego && world.method_8321(hit) instanceof BrickCellEntity cell) {
                BrickPiece selected = cell.pickAt(hit.method_10264()+packet.localY(),side==class_2350.field_11036);
                if (selected != null) {
                    if (side == class_2350.field_11036) {
                        px = hit.method_10263(); pz = hit.method_10260(); baseUnits = selected.top();
                    } else if (side.method_10166().method_10179()) {
                        baseUnits = selected.y();
                    }
                }
            }
            BrickPiece provisional = new BrickPiece(intent.kind(),intent.rgb(),px,baseUnits,pz,
                    intent.turn(),intent.angle(),intent.pitch(),intent.roll(),intent.partId(),intent.colorCode());
            if(lego && side==class_2350.field_11036 && world.method_8321(hit) instanceof BrickCellEntity cell){
                BrickPiece support=cell.pickAt(hit.method_10264()+packet.localY(),true);
                // Only attach to a connector of the actually selected LEGO piece.
                // Clicks on top/bottom use the *real* LEGO face height rather than the
                // surrounding Minecraft block's 1x1x1 collision surface.
                double clickY=support==null?hit.method_10264()+packet.localY():
                    side==class_2350.field_11036?support.top()/5.0:
                    side==class_2350.field_11033?support.y()/5.0:hit.method_10264()+packet.localY();
                candidate=support==null?provisional:ConnectorSnapper.snap(provisional,support,
                        hit.method_10263()+packet.localX(),clickY,hit.method_10260()+packet.localZ(),null).piece();
            }else candidate=provisional;
        }
        if(place(world,player,candidate)) remember(world,player,candidate,true);
        else player.method_7353(class_2561.method_43471("message.brickcraft.place.blocked"),true);
    }

    /** Server-side command placement; ignores player's reach but respects chunk and region safety. */
    public static boolean placeCommand(class_3218 world,class_3222 player,BrickPiece piece) {
        if(!placeChecked(world,player,piece,false))return false;
        if(player!=null)remember(world,player,piece,true);
        return true;
    }

    /** Validate the complete footprint BEFORE touching any world block. */
    private static boolean place(class_3218 world, class_3222 player, BrickPiece piece) {
        return placeChecked(world,player,piece,true);
    }
    private static boolean placeChecked(class_3218 world, class_3222 player,
                                        BrickPiece piece,boolean checkReach) {
        if (!piece.valid()) return false;
        if(piece.kind()==BrickKind.LDRAW_PART && LDrawLibrary.mesh(piece.partId())==null)return false;
        List<class_2338> locations = piece.occupiedCells();
        if (locations.size()>256) return false;
        for (class_2338 pos : locations) {
            if (!world.method_24794(pos) || !world.method_22340(pos)) return false;
            if(player!=null && (!world.method_8505(player,pos)
                    || (checkReach && player.method_5707(class_243.method_24953(pos))>256))) return false;
            if (world.method_8320(pos).method_26215()) continue;
            if (!(world.method_8321(pos) instanceof BrickCellEntity cell) || !cell.canAdd(piece)) return false;
        }
        for (class_2338 pos : locations) {
            if (world.method_8320(pos).method_26215()) world.method_8652(pos,CELL.method_9564(),3);
            if (world.method_8321(pos) instanceof BrickCellEntity cell) cell.add(piece);
        }
        return true;
    }

    /** A LEGO piece is always removed from every fragment cell it occupies. */
    private static boolean remove(class_3218 world, class_3222 player, BrickPiece piece) {
        List<class_2338> locations=piece.occupiedCells();
        for (class_2338 pos:locations) {
            if (!world.method_22340(pos) || !world.method_8505(player,pos)
                    || !(world.method_8321(pos) instanceof BrickCellEntity cell)
                    || !cell.pieces().contains(piece)) return false;
        }
        for (class_2338 pos:locations) {
            if (world.method_8321(pos) instanceof BrickCellEntity cell && cell.remove(piece)
                    && cell.pieces().isEmpty()) world.method_8652(pos,class_2246.field_10124.method_9564(),3);
        }
        return true;
    }
}
