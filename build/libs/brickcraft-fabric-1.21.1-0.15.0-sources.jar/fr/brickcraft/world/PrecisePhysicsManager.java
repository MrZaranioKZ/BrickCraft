package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PrecisePhysicsPayload;
import fr.brickcraft.world.PreciseMeshCollisionPlan.Cell;
import fr.brickcraft.world.PreciseMeshCollisionPlan.Result;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.*;
import java.util.Map.Entry;

/** LDraw surface + multi-axis parity rasterization, quantized to 8^3 micro-voxels per cell.
 * Only AIR is filled; all cell ownership is recorded on the anchor BEFORE block placement.
 * A voxel mask is persisted on EACH proxy BlockEntity and synced to clients. */
public final class PrecisePhysicsManager {
    private PrecisePhysicsManager(){}
    private record Job(class_3218 world,class_2338 anchor,class_3222 player,long[] cells,
                       Map<Long,long[]> masks,long[] anchorMask,boolean enable,int next){}
    private static final Map<String,Job> JOBS=new LinkedHashMap<>();
    private static String key(class_3218 world,class_2338 pos){return world.method_27983().method_29177()+":"+pos.method_10063();}
    private static void say(class_3222 p,String msg){if(p!=null)p.method_7353(class_2561.method_43470("BrickCraft physique : "+msg),false);}
    public static void receive(class_3222 player,PrecisePhysicsPayload data){
        class_3218 world=player.method_51469();class_2338 anchor=data.anchor();
        if(!player.method_7337()||player.method_7325()||player.method_5649(anchor.method_10263()+.5,anchor.method_10264()+.5,anchor.method_10260()+.5)>192*192||
           !world.method_22340(anchor)||!world.method_8505(player,anchor)||
           !(world.method_8321(anchor) instanceof PreciseDisplayEntity be)||be.model()==null){
            say(player,"refuse : mode creatif, permissions et ancre chargee requis");return;
        }
        if(JOBS.containsKey(key(world,anchor))){say(player,"operation deja en cours sur cette projection");return;}
        if(data.enable()){
            try{
                var model=be.model();
                // Original library mesh, never reduced by the GPU triangle/LOD slider.
                Map<String,PreciseMeshCollisionPlan.Geometry> geometryCache=new HashMap<>();
                var result=PreciseMeshCollisionPlan.build(model.parts(),model.minX(),model.minY(),model.minZ(),
                        anchor.method_10263(),anchor.method_10264(),anchor.method_10260(),id->geometryCache.computeIfAbsent(id,partId->{
                            String ref=PreciseReferenceMapper.geometryId(partId);
                            if(ref==null)return null;
                            double[] bounds=LDrawLibrary.originalBounds(ref);
                            LDrawLibrary.Mesh mesh=LDrawLibrary.mesh(ref);
                            return bounds==null||mesh==null?null:new PreciseMeshCollisionPlan.Geometry(mesh.xyz(),bounds);
                        }));
                long[] anchorMask=result.masks().getOrDefault(
                        new PreciseMeshCollisionPlan.Cell(anchor.method_10263(),anchor.method_10264(),anchor.method_10260()),new long[0]);
                Map<Long,long[]> prepared=new LinkedHashMap<>();
                for(var cell:result.masks().entrySet()){
                    var c=cell.getKey();
                    if(c.x()==anchor.method_10263()&&c.y()==anchor.method_10264()&&c.z()==anchor.method_10260())continue;
                    prepared.put(new class_2338(c.x(),c.y(),c.z()).method_10063(),cell.getValue());
                }
                long[] previous=be.collisionCells();
                if(previous.length>0){
                    // Resume an interrupted job without replacing any existing terrain or foreign proxies.
                    Map<Long,long[]> owned=new LinkedHashMap<>();
                    for(long pos:previous)if(prepared.containsKey(pos))owned.put(pos,prepared.get(pos));
                    if(owned.size()!=previous.length){
                        say(player,"anciennes collisions incompatibles : Physique OFF puis ON requis");return;
                    }
                    for(long encoded:previous){
                        class_2338 pos=class_2338.method_10092(encoded);
                        if(!world.method_22340(pos)||!world.method_8505(player,pos))
                            throw new IllegalArgumentException("zone non chargee/protegee : "+pos.method_23854());
                        if(!world.method_8320(pos).method_26215()&&!world.method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                            throw new IllegalArgumentException("terrain modifie : "+pos.method_23854());
                    }
                    JOBS.put(key(world,anchor),new Job(world,anchor,player,previous,owned,anchorMask,true,0));
                    say(player,"reprise ou mise a jour de "+previous.length+" cellules 1/8 bloc");return;
                }
                Map<Long,long[]> free=new LinkedHashMap<>();int terrain=0;
                for(var entry:prepared.entrySet()){
                    class_2338 pos=class_2338.method_10092(entry.getKey());
                    if(!world.method_24794(pos)||!world.method_22340(pos)||!world.method_8505(player,pos))
                        throw new IllegalArgumentException("zone non chargee ou protegee : "+pos.method_23854());
                    if(world.method_8320(pos).method_26215())free.put(entry.getKey(),entry.getValue());
                    else if(world.method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                        throw new IllegalArgumentException("collision avec une autre projection");
                    else terrain++;
                }
                long[] keys=free.keySet().stream().mapToLong(Long::longValue).toArray();
                if(keys.length==0){
                    be.setAnchorCollisionMask(anchorMask);
                    say(player,"seule l'ancre a une forme libre (autres cellules occupees par le terrain)");return;
                }
                be.setCollisionCells(keys); // ownership persisted before any world mutation
                JOBS.put(key(world,anchor),new Job(world,anchor,player,keys,free,anchorMask,true,0));
                say(player,"maillage reel : "+keys.length+" blocs x 8^3 sous-voxels, "+result.triangles()+
                        " triangles, "+terrain+" cellules IGNOREES (terrain existant). Placement progressif.");
            }catch(Exception e){say(player,"refuse avant pose : "+e.getMessage());}
        }else{
            long[] existing=be.collisionCells();
            if(existing.length==0 && !be.hasAnchorCollision()){say(player,"aucune collision a retirer");return;}
            JOBS.put(key(world,anchor),new Job(world,anchor,player,existing,Map.of(),new long[0],false,0));
            say(player,"retrait progressif de "+existing.length+" cellules");
        }
    }
    public static void tick(MinecraftServer server){
        var iter=JOBS.entrySet().iterator();int budget=128;
        while(iter.hasNext()&&budget>0){
            var entry=iter.next();Job job=entry.getValue();
            if(job.world().method_8321(job.anchor()) instanceof PreciseDisplayEntity be){
                int i=job.next();
                while(i<job.cells().length && budget>0){
                    long encoded=job.cells()[i];class_2338 pos=class_2338.method_10092(encoded);
                    if(!job.world().method_22340(pos))break; // Never silently skip an unloaded cell.
                    {
                        if(job.enable()){
                            if(job.world().method_8320(pos).method_26215())
                                job.world().method_8652(pos,BrickCraft.PRECISE_COLLISION.method_9564(),3);
                            if(job.world().method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION)&&
                               job.world().method_8321(pos) instanceof PreciseCollisionEntity cell){
                                long[] mask=job.masks().get(encoded);
                                if(mask!=null)cell.setMask(mask);
                            }
                        }else if(job.world().method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                            job.world().method_8652(pos,class_2246.field_10124.method_9564(),3);
                    }
                    i++;budget--;
                }
                if(i>=job.cells().length){
                    if(!job.enable())be.setCollisionCells(new long[0]);
                    be.setAnchorCollisionMask(job.enable()?job.anchorMask():new long[0]);
                    say(job.player(),(job.enable()?"activee (LDraw, 1/8 bloc)":"retiree")+
                            " : "+job.cells().length+" cellules traitees");
                    iter.remove();
                }else entry.setValue(new Job(job.world(),job.anchor(),job.player(),job.cells(),job.masks(),job.anchorMask(),job.enable(),i));
            }else iter.remove(); // anchor's onStateReplaced already invoked cleanup
        }
    }
    /** Triggered by anchor destruction; only touches loaded chunks and our own collision blocks. */
    public static void cleanup(class_3218 world,PreciseDisplayEntity be){
        JOBS.remove(key(world,be.method_11016()));
        for(long key:be.collisionCells()){
            class_2338 pos=class_2338.method_10092(key);
            if(world.method_22340(pos)&&world.method_8320(pos).method_27852(BrickCraft.PRECISE_COLLISION))
                world.method_8652(pos,class_2246.field_10124.method_9564(),3);
        }
        be.setCollisionCells(new long[0]);
        be.setAnchorCollisionMask(new long[0]);
    }
}
