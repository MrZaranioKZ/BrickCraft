package fr.brickcraft.client;

import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseFreeAssembly;
import fr.brickcraft.importer.PreciseProjectIO;
import fr.brickcraft.ldraw.LDrawLibrary;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/** V0.9.6: precise in-game editor with live parent 3D preview, no integer grid. */
public final class PreciseFreeScreen extends class_437 {
    private static final double[] MOVE_STEPS={20,8,4,1,.25};
    private static final double[] ANGLE_STEPS={90,45,15,5,1,.25};
    private final ProjectImportScreen preview;
    private final PreciseFreeAssembly assembly;
    private final String filename;
    private class_342 partId,color,x,y,z,index,moveInput,angleInput;
    private class_4185 moveStepButton,angleStepButton;
    private int moveStep=0,angleStep=0;
    private String status="Selectionne une piece, ou ajoute-en une avec sa reference LDraw.";
    private boolean dirty=false;

    public PreciseFreeScreen(ProjectImportScreen preview,LDrawProjectReader.Result source,String filename){
        super(class_2561.method_43470("BrickCraft - Placement libre V0.9.7"));
        this.preview=preview;
        this.assembly=new PreciseFreeAssembly(source);
        this.filename=filename;
    }
    private void button(int x,int y,int w,int h,String text,Runnable callback){
        method_37063(class_4185.method_46430(class_2561.method_43470(text),b->callback.run()).method_46434(x,y,w,h).method_46431());
    }
    private class_342 field(int x,int y,int w,String placeholder,int length){
        class_342 f=new class_342(field_22793,x,y,w,18,class_2561.method_43470(placeholder));
        f.method_1880(length);method_37063(f);return f;
    }
    @Override protected void method_25426(){
        int w=Math.min(418,Math.max(325,field_22789*2/5));
        int left=10, usable=w-20;
        int quarter=(usable-12)/4,third=(usable-10)/3;
        button(left,39,quarter,19,"< Piece",()->pick(-1));
        button(left+quarter+4,39,quarter,19,"Piece >",()->pick(1));
        index=field(left+2*(quarter+4),39,quarter,"Numero",8);
        button(left+3*(quarter+4),39,quarter,19,"Aller",this::jump);
        partId=field(left,86,usable-115,"ID LDraw / 3005",96);
        color=field(left+usable-108,86,108,"Couleur",8);
        int fy=127;
        x=field(left,fy,third,"LDU X",24);
        y=field(left+third+5,fy,third,"LDU Y",24);
        z=field(left+(third+5)*2,fy,third,"LDU Z",24);
        int half=usable/2-3;
        moveStepButton=method_37063(class_4185.method_46430(class_2561.method_43470("Pas pos. >"),b->{
            moveStep=(moveStep+1)%MOVE_STEPS.length;updateStepTexts();
        }).method_46434(left,166,82,18).method_46431());
        moveInput=field(left+86,166,half-87,"LDU",20);
        angleStepButton=method_37063(class_4185.method_46430(class_2561.method_43470("Pas rot. >"),b->{
            angleStep=(angleStep+1)%ANGLE_STEPS.length;updateStepTexts();
        }).method_46434(left+usable/2+3,166,82,18).method_46431());
        angleInput=field(left+usable/2+89,166,half-87,"Degres",20);
        updateStepTexts();
        int ay=195;
        for(int c=0;c<3;c++){
            PreciseFreeAssembly.Axis axis=PreciseFreeAssembly.Axis.values()[c];
            int px=left+c*(third+5);
            button(px,ay,third/2-2,19,""+axis+" -",()->stepMove(axis,-1));
            button(px+third/2+2,ay,third/2-2,19,""+axis+" +",()->stepMove(axis,1));
            button(px,ay+27,third/2-2,19,"R"+axis+" -",()->stepRotate(axis,-1));
            button(px+third/2+2,ay+27,third/2-2,19,"R"+axis+" +",()->stepRotate(axis,1));
        }
        button(left,259,usable/2-3,19,"Appliquer champs",this::applyFields);
        button(left+usable/2+3,259,usable/2-3,19,"Rotation 0",()->change(assembly.resetRotation(),"Rotation remise a zero"));
        button(left,286,third,19,"Ajouter",this::add);
        button(left+third+5,286,third,19,"Dupliquer",()->change(assembly.duplicate(),"Piece dupliquee"));
        button(left+(third+5)*2,286,third,19,"Supprimer",()->change(assembly.delete(),"Piece supprimee"));
        button(left,316,usable/2-3,19,"Annuler",()->change(assembly.undo(),"Annulation"));
        button(left+usable/2+3,316,usable/2-3,19,"Retablir",()->change(assembly.redo(),"Retablissement"));
        button(left,Math.max(335,field_22790-78),usable,19,"Enregistrer un nouveau .bcpx",this::save);
        button(left,Math.max(361,field_22790-52),usable,19,"Retour a l'apercu / projection",()->field_22787.method_1507(preview));
        refreshFields();
    }
    private void updateStepTexts(){
        moveInput.method_1852(fmt(MOVE_STEPS[moveStep]));
        angleInput.method_1852(fmt(ANGLE_STEPS[angleStep]));
    }
    private static String fmt(double v){return v==(long)v?Long.toString((long)v):Double.toString(v);}
    private static double stepValue(class_342 field,double max){
        double value=Double.parseDouble(field.method_1882().strip().replace(',','.'));
        if(!Double.isFinite(value)||value<=0||value>max)throw new IllegalArgumentException("Pas requis entre 0 et "+max);
        return value;
    }
    private void refreshFields(){
        var p=assembly.selected();
        index.method_1852(assembly.selectedIndex()<0?"-":Integer.toString(assembly.selectedIndex()+1));
        if(p==null){partId.method_1852("3005");color.method_1852("4");x.method_1852("0");y.method_1852("0");z.method_1852("0");}
        else {partId.method_1852(p.partId());color.method_1852(Integer.toString(p.color()));
            x.method_1852(fmt(p.x()));y.method_1852(fmt(p.y()));z.method_1852(fmt(p.z()));}
    }
    private void pick(int dir){
        if(assembly.size()==0){status="Aucune piece. Utilise Ajouter.";return;}
        assembly.select(Math.floorMod(assembly.selectedIndex()+dir,assembly.size()));refreshFields();
    }
    private void jump(){
        try{if(!assembly.select(Integer.parseInt(index.method_1882())-1))throw new IllegalArgumentException();refreshFields();}
        catch(Exception ex){status="Numero invalide : entre une valeur entre 1 et "+assembly.size();}
    }
    private LDrawProjectReader.Instance fromFields(double[] mat){
        return new LDrawProjectReader.Instance(partId.method_1882().strip().replace(".dat", ""),
                Integer.parseInt(color.method_1882().strip()),Double.parseDouble(x.method_1882().strip().replace(',','.')),
                Double.parseDouble(y.method_1882().strip().replace(',','.')),
                Double.parseDouble(z.method_1882().strip().replace(',','.')),mat);
    }
    private void applyFields(){
        try{var p=assembly.selected();
            if(p==null){status="Aucune piece selectionnee : utilise Ajouter";return;}
            change(assembly.replace(fromFields(p.matrix())),"Modifications appliquees");
        }catch(Exception ex){status="Champs invalides : "+ex.getMessage();}
    }
    private void add(){
        try{change(assembly.add(fromFields(PreciseFreeAssembly.identity())),"Piece ajoutee (rotation initiale 0 deg)");}
        catch(Exception ex){status="Ajout refuse : "+ex.getMessage();}
    }
    private void stepMove(PreciseFreeAssembly.Axis axis,int direction){
        try{change(assembly.move(axis,direction*stepValue(moveInput,1000)),"Deplacement "+axis+" de "+fmt(direction*stepValue(moveInput,1000))+" LDU");}
        catch(Exception ex){status="Deplacement refuse : "+ex.getMessage();}
    }
    private void stepRotate(PreciseFreeAssembly.Axis axis,int direction){
        try{change(assembly.rotate(axis,direction*stepValue(angleInput,360)),"Rotation "+axis+" de "+fmt(direction*stepValue(angleInput,360))+" deg");}
        catch(Exception ex){status="Rotation refusee : "+ex.getMessage();}
    }
    private void change(boolean success,String message){
        if(!success){status="Aucune piece selectionnee";return;}
        dirty=true;refreshFields();preview.applyFreeEdits(assembly.result());
        status=message+" | "+assembly.size()+" pieces";
    }
    private void save(){
        if(assembly.size()==0){status="Ajoute au moins une piece avant de sauver";return;}
        try{
            Path folder=FabricLoader.getInstance().getConfigDir().resolve("brickcraft").resolve("imports");
            Files.createDirectories(folder);
            String stem=filename.replaceAll("(?i)\\.(io|ldr|mpd|bcpx)$","").replaceAll("[^a-zA-Z0-9_-]","_");
            if(stem.isEmpty())stem="atelier";
            Path dest=folder.resolve(stem+"_free_v097.bcpx");
            int suffix=2;
            while(Files.exists(dest)){dest=folder.resolve(stem+"_free_v097_"+(suffix++)+".bcpx");}
            PreciseProjectIO.save(dest,assembly.result());dirty=false;
            status="Sauvegarde : "+dest.getFileName()+" (source intacte)";
            preview.refreshFreeFiles(dest);
        }catch(Exception ex){status="Erreur de sauvegarde : "+ex.getMessage();}
    }
    @Override public void method_25420(class_332 draw,int mx,int my,float delta){}
    @Override public void method_25394(class_332 draw,int mx,int my,float delta){
        // Draw only the 3D preview: never render the previous screen's own widget tree.
        int w=Math.min(418,Math.max(325,field_22789*2/5));
        draw.method_25294(0,0,field_22789,field_22790,0xFF0B111A);
        int viewportLeft=w+10,viewportTop=37,viewportRight=field_22789-8,viewportBottom=field_22790-32;
        preview.renderFreeViewport(draw,viewportLeft,viewportTop,viewportRight,viewportBottom);
        draw.method_25294(3,28,w+2,field_22790-27,0xFF172636);
        draw.method_25294(3,28,w+2,31,0xFF55CFD8);
        draw.method_25303(field_22793,"BRICKCRAFT / PLACEMENT LIBRE 0.9.7",10,10,0xFFE7F8FF);
        draw.method_25303(field_22793,"Clic droit : orbite | Milieu : deplacer | Molette : zoom",viewportLeft+7,42,0xFFAAC9D7);
        draw.method_25303(field_22793,"Piece "+(assembly.selectedIndex()+1)+" / "+assembly.size()+
                (dirty?"  * Non enregistre":""),10,64,0xFF9DE4E3);
        draw.method_25303(field_22793,"Reference / code couleur",10,75,0xFFC0CEDA);
        draw.method_25303(field_22793,"Origine LDraw : X / Y / Z (decimales)",10,112,0xFFC0CEDA);
        draw.method_25303(field_22793,"1 stud = 20 LDU  |  1 plate = 8 LDU",10,151,0xFFE7C98F);
        if(field_22790>475)draw.method_25303(field_22793,
                "Ctrl+Z/Y : annuler/retablir | Ctrl+S : sauvegarder",10,360,0xFF9ABBC9);
        draw.method_25294(0,field_22790-25,field_22789,field_22790,0xFF122334);
        String message=status;
        while(field_22793.method_1727(message)>field_22789-25 && message.length()>8)message=message.substring(0,message.length()-4)+"...";
        draw.method_25303(field_22793,message,10,field_22790-18,0xFFFFDA91);
        super.method_25394(draw,mx,my,delta);
    }
    @Override public boolean method_25402(double x,double y,int button){
        int w=Math.min(418,Math.max(325,field_22789*2/5));
        if(preview.editorPreviewMouseClick(x,y,button,w+10,37,field_22789-8,field_22790-32))return true;
        return super.method_25402(x,y,button);
    }
    @Override public boolean method_25403(double x,double y,int button,double dx,double dy){
        if(preview.editorPreviewMouseDrag(button,dx,dy))return true;
        return super.method_25403(x,y,button,dx,dy);
    }
    @Override public boolean method_25406(double x,double y,int button){
        if(preview.editorPreviewMouseRelease(button))return true;
        return super.method_25406(x,y,button);
    }
    @Override public boolean method_25401(double x,double y,double horizontal,double vertical){
        int w=Math.min(418,Math.max(325,field_22789*2/5));
        if(preview.editorPreviewWheel(x,y,vertical,w+10,37,field_22789-8,field_22790-32))return true;
        return super.method_25401(x,y,horizontal,vertical);
    }
    @Override public boolean method_25404(int key,int scancode,int modifiers){
        if((modifiers & GLFW.GLFW_MOD_CONTROL)!=0){
            if(key==GLFW.GLFW_KEY_Z){change(assembly.undo(),"Annulation");return true;}
            if(key==GLFW.GLFW_KEY_Y){change(assembly.redo(),"Retablissement");return true;}
            if(key==GLFW.GLFW_KEY_S){save();return true;}
            if(key==GLFW.GLFW_KEY_D){change(assembly.duplicate(),"Piece dupliquee");return true;}
        }
        if(key==GLFW.GLFW_KEY_ESCAPE){field_22787.method_1507(preview);return true;}
        return super.method_25404(key,scancode,modifiers);
    }
}
