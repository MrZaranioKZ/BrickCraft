package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickCatalog;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import fr.brickcraft.ldraw.LDrawLibrary;
import org.lwjgl.glfw.GLFW;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** N palette: starter parts + thousands of official LDraw parts (loaded from local ZIP). */
public final class BrickQuickScreen extends class_437 {
    private String query="";
    private class_342 search;
    private int page=0,colorPage=0,colCount,rows,perPage,leftX,leftW,rightX,rightW,topY,cardW;
    private boolean ldraw=LDrawLibrary.available();
    private List<BrickKind> legacy=List.of();
    private List<LDrawLibrary.PartInfo> imported=List.of();
    private List<LDrawLibrary.Colour> colors=List.of();
    public BrickQuickScreen(){super(class_2561.method_43470("BrickCraft - catalogue LDraw"));}
    private int matchCount(){return ldraw?imported.size():legacy.size();}
    private void updateMatches(){
        legacy=BrickCatalog.search(query);
        imported=LDrawLibrary.search(query,500);
        page=0;
    }
    @Override protected void method_25426(){
        leftX=12;rightW=Math.min(196,Math.max(128,field_22789/3));rightX=field_22789-rightW-12;
        leftW=Math.max(90,rightX-leftX-12);topY=87;
        colCount=leftW>=340?3:2;
        rows=Math.max(2,Math.min(8,(field_22790-161)/30));perPage=colCount*rows;
        cardW=(leftW-4*(colCount-1))/colCount;
        colors=LDrawLibrary.colors();updateMatches();
        search=new class_342(field_22793,leftX,33,leftW,20,class_2561.method_43470("Recherche : nom, dimensions ou ID LDraw"));
        search.method_1880(60);search.method_1852(query);
        search.method_1863(value->{
            query=value;updateMatches();
            if(!ldraw){
                BrickCatalog.Entry element=BrickCatalog.findElement(value);
                if(element!=null){BrickSelection.kind=element.kind();BrickSelection.partId="";BrickSelection.rgb=element.rgb();}
            }
        });
        method_37063(search);
        button(leftX,57,(leftW-4)/2,19,"Classiques",()->{ldraw=false;page=0;});
        button(leftX+(leftW-4)/2+4,57,(leftW-4)/2,19,"LDraw",()->{ldraw=true;page=0;});
        int bottom=Math.min(field_22790-46,topY+rows*30+14);
        int bw=Math.max(42,(leftW-5)/2);
        button(leftX,bottom,bw,20,"< Page",()->page=Math.max(0,page-1));
        button(leftX+bw+5,bottom,bw,20,"Page >",()->page=Math.min(Math.max(0,(matchCount()-1)/perPage),page+1));
        button(rightX,topY+138,(rightW-4)/2,19,"< Couleurs",()->colorPage=Math.max(0,colorPage-1));
        button(rightX+(rightW-4)/2+4,topY+138,(rightW-4)/2,19,"Couleurs >",()->colorPage++);
        int y=topY+170;
        button(rightX,y,rightW/3-3,19,"Y -",()->BrickSelection.rotate(-1));
        button(rightX+rightW/3,y,rightW/3-3,19,"Y +",()->BrickSelection.rotate(1));
        button(rightX+rightW*2/3,y,rightW/3-3,19,"Pas",BrickSelection::cycleStep);
        button(rightX,y+24,rightW/2-2,19,"X +",()->BrickSelection.rotatePitch(1));
        button(rightX+rightW/2+2,y+24,rightW/2-2,19,"Z +",()->BrickSelection.rotateRoll(1));
        button(rightX,y+48,rightW,19,"Reset rotation",BrickSelection::resetRotation);
        button(rightX,y+76,rightW,19,"Retour en jeu",this::method_25419);
    }
    private void button(int x,int y,int w,int h,String label,Runnable action){
        if(y+h>=field_22790-12 || w<18)return;
        method_37063(class_4185.method_46430(class_2561.method_43470(label),b->action.run()).method_46434(x,y,w,h).method_46431());
    }
    @Override public void method_25420(class_332 ctx,int mx,int my,float delta){}
    @Override public void method_25394(class_332 ctx,int mx,int my,float delta){
        ctx.method_25294(0,0,field_22789,field_22790,0xE9091420);
        ctx.method_25294(leftX-5,topY-62,rightX-6,field_22790-38,0xFF152634);
        ctx.method_25294(rightX-5,topY-62,field_22789-8,field_22790-38,0xFF152634);
        ctx.method_25303(field_22793,"BRICKCRAFT | Catalogue de pieces",12,10,0xFFE6F3FF);
        String label=ldraw?"LDraw "+LDrawLibrary.size()+" | "+imported.size()+" resultats (max 500)"
                :"Formes classiques : "+legacy.size();
        ctx.method_25303(field_22793,field_22793.method_27523(label,leftW),leftX,topY-7,0xFF8BCBE4);
        ctx.method_25303(field_22793,"Couleurs"+(colors.isEmpty()?" (16)":" ("+colors.size()+")"),rightX,topY-7,0xFF8BCBE4);
        int count=matchCount();page=Math.min(page,Math.max(0,(count-1)/perPage));
        for(int i=page*perPage;i<Math.min(count,(page+1)*perPage);i++){
            int slot=i-page*perPage;
            int x=leftX+(slot%colCount)*(cardW+4),y=topY+12+(slot/colCount)*30;
            boolean selected;
            String name;
            if(ldraw){
                LDrawLibrary.PartInfo part=imported.get(i);
                selected=BrickSelection.kind==BrickKind.LDRAW_PART&&part.id().equals(BrickSelection.partId);
                name=part.id()+" "+part.name();
            }else{
                BrickKind k=legacy.get(i);selected=k==BrickSelection.kind;
                name=k.title.replace("Brique ","B ").replace("Plaque ","P ").replace("Tuile ","T ")
                      .replace("Pente ","S ").replace('×','x');
            }
            ctx.method_25294(x-1,y-1,x+cardW+1,y+27,selected?0xFF70DDCE:0xFF345366);
            ctx.method_25294(x,y,x+cardW,y+26,0xFF344556);
            int tx=x+4;
            if(!ldraw){ctx.method_51427(new class_1799(BrickCraft.PART_ITEMS.get(legacy.get(i))),x+3,y+5);tx=x+23;}
            ctx.method_25303(field_22793,field_22793.method_27523(name,cardW-(tx-x)-4),tx,y+8,0xFFE9F5F8);
        }
        int cellW=Math.max(22,(rightW-9)/4);
        boolean many=!colors.isEmpty();
        int total=many?colors.size():BrickPalette.COLORS.length;
        int maxPage=Math.max(0,(total-1)/16);colorPage=Math.min(colorPage,maxPage);
        for(int i=0;i<16 && colorPage*16+i<total;i++){
            int x=rightX+(i%4)*cellW,y=topY+13+(i/4)*26;
            int color=many?colors.get(colorPage*16+i).rgb():BrickPalette.COLORS[colorPage*16+i];
            ctx.method_25294(x,y,x+cellW-4,y+23,color==BrickSelection.rgb?0xFFFFFFFF:0xFF45596C);
            ctx.method_25294(x+2,y+2,x+cellW-6,y+21,0xFF000000|color);
        }
        ctx.method_25303(field_22793,"Palette "+(colorPage+1)+"/"+(maxPage+1),rightX,topY+121,0xFFFFE5B1);
        ctx.method_25303(field_22793,"Y="+BrickSelection.angle+" X="+BrickSelection.pitch+" Z="+BrickSelection.roll,
                rightX,topY+157,0xFFC2E2ED);
        ctx.method_25303(field_22793,field_22793.method_27523("Selection : "+BrickSelection.selectedName(),field_22789-24),leftX,field_22790-31,0xFFB9DDEB);
        ctx.method_25303(field_22793,field_22793.method_27523(
            "N : fermer | R : tourner | "+LDrawLibrary.status(),field_22789-24),leftX,field_22790-16,0xFF91B0C3);
        super.method_25394(ctx,mx,my,delta);
    }
    @Override public boolean method_25402(double x,double y,int button){
        if(button==0){
            int count=matchCount();
            for(int i=page*perPage;i<Math.min(count,(page+1)*perPage);i++){
                int slot=i-page*perPage,xx=leftX+(slot%colCount)*(cardW+4),yy=topY+12+(slot/colCount)*30;
                if(x>=xx&&x<xx+cardW&&y>=yy&&y<yy+26){
                    if(ldraw){
                        BrickSelection.kind=BrickKind.LDRAW_PART;
                        BrickSelection.partId=imported.get(i).id();
                        if(query.trim().equals("6258572"))BrickSelection.rgb=0xFF6D77;
                    }else{
                        BrickSelection.kind=legacy.get(i);BrickSelection.partId="";
                        BrickCatalog.Entry element=BrickCatalog.findElement(query);
                        if(element!=null&&element.kind()==BrickSelection.kind)BrickSelection.rgb=element.rgb();
                    }
                    BrickSelection.sampled=true;
                    return true;
                }
            }
            int total=colors.isEmpty()?BrickPalette.COLORS.length:colors.size();
            int cellW=Math.max(22,(rightW-9)/4);
            for(int i=0;i<16&&colorPage*16+i<total;i++){
                int xx=rightX+(i%4)*cellW,yy=topY+13+(i/4)*26;
                if(x>=xx&&x<xx+cellW-4&&y>=yy&&y<yy+23){
                    BrickSelection.rgb=colors.isEmpty()?BrickPalette.COLORS[colorPage*16+i]:colors.get(colorPage*16+i).rgb();
                    return true;
                }
            }
        }
        return super.method_25402(x,y,button);
    }
    @Override public boolean method_25404(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE){method_25419();return true;}
        if(search!=null&&search.method_25370())return super.method_25404(key,scan,mods);
        if(key==GLFW.GLFW_KEY_N){method_25419();return true;}
        if(key==GLFW.GLFW_KEY_R){BrickSelection.rotate((mods&GLFW.GLFW_MOD_SHIFT)!=0?-1:1);return true;}
        if(key==GLFW.GLFW_KEY_X){BrickSelection.rotatePitch(1);return true;}
        if(key==GLFW.GLFW_KEY_Z){BrickSelection.rotateRoll(1);return true;}
        if(key==GLFW.GLFW_KEY_H){BrickSelection.resetRotation();return true;}
        if(key==GLFW.GLFW_KEY_G){BrickSelection.cycleStep();return true;}
        if(key==GLFW.GLFW_KEY_C){BrickSelection.nextColor();return true;}
        return super.method_25404(key,scan,mods);
    }
    @Override public boolean method_25421(){return false;}
}
