package fr.brickcraft.client;

import com.mojang.blaze3d.systems.RenderSystem;
import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.world.PreciseDisplayEntity;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.Map.Entry;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_291;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9799;
import net.minecraft.class_9801;

/**
 * 0.9.5.1 corrected GPU path. Static, camera-independent LEGO triangles are uploaded
 * once as POSITION_COLOR TRIANGLES. Normal frames only bind and draw existing buffers.
 * IMPORTANT: all calls (including clear) must take place on the client render thread.
 * The legacy 0.9.4 renderer remains available through gpu_render_mode=legacy.
 */
final class PreciseGpuRenderer {
    private record Key(int x,int y,int z){}
    private static final int VERTEX_BYTES=16; // POSITION_COLOR: 3 floats + 4 color bytes
    private final int cellSize,uploadsPerFrame,limitBytes,quality;
    private Object currentWorld;
    private final LinkedHashMap<class_2338,Scene> scenes=new LinkedHashMap<>(8,.75f,true);
    private final Map<String,LDrawLibrary.Mesh> meshCache=new HashMap<>();
    private int memoryBytes;
    private long uploadedTriangles,renderedTriangles,drawCalls,lastDrawNanos,lastUploadNanos;
    private int pendingSections;
    private int memoryBlockedSections;
    private boolean visibility=true;
    // In V0.9.5, experimental camera-direction culling could hide valid sections.
    // Disabled by default until a tested frustum/AABB implementation replaces it.
    private boolean cullingEnabled;
    // The BER's MatrixStack is not necessarily the complete view matrix for direct VBOs.
    // Explicit camera view is the safe default; prior implementation is diagnostic only.
    private boolean explicitCameraView;
    private int totalSections,visibleSections,culledSections,readySections,unloadedSections;


    /**
     * quality: 0=tiny, 1=low, 2=medium, 3=full (all are original LEGO meshes).
     */
    PreciseGpuRenderer(Properties settings){
        cellSize=integer(settings,"gpu_section_blocks",12,4,32);
        uploadsPerFrame=integer(settings,"gpu_uploads_per_frame",2,1,12);
        limitBytes=integer(settings,"gpu_max_memory_mb",192,32,1024)*1024*1024;
        String q=settings.getProperty("gpu_mesh_quality","low").trim().toLowerCase(Locale.ROOT);
        quality=q.equals("tiny")?0:q.equals("medium")?2:q.equals("full")?3:1;
        cullingEnabled=settings.getProperty("gpu_culling","off").trim().equalsIgnoreCase("legacy");
        explicitCameraView=!settings.getProperty("gpu_view_matrix","explicit")
                .trim().equalsIgnoreCase("entity");
    }
    private static int integer(Properties p,String key,int fallback,int lo,int hi){
        try{return Math.clamp(Integer.parseInt(p.getProperty(key,"")),lo,hi);}
        catch(NumberFormatException ignored){return fallback;}
    }
    private static final class Section {
        final List<Integer> indices=new ArrayList<>();
        double loX=Double.POSITIVE_INFINITY,loY=Double.POSITIVE_INFINITY,loZ=Double.POSITIVE_INFINITY;
        double hiX=Double.NEGATIVE_INFINITY,hiY=Double.NEGATIVE_INFINITY,hiZ=Double.NEGATIVE_INFINITY;
        class_291 opaque,transparent;
        int trianglesOpaque,trianglesTransparent,bytes;
        boolean complete;
        boolean memoryDeferred;
        void include(double x,double y,double z,double radius){
            loX=Math.min(loX,x-radius);loY=Math.min(loY,y-radius);loZ=Math.min(loZ,z-radius);
            hiX=Math.max(hiX,x+radius);hiY=Math.max(hiY,y+radius);hiZ=Math.max(hiZ,z+radius);
        }
        double cx(){return (loX+hiX)/2;}
        double cy(){return (loY+hiY)/2;}
        double cz(){return (loZ+hiZ)/2;}
        double radius(){return Math.sqrt(Math.pow(hiX-loX,2)+Math.pow(hiY-loY,2)+Math.pow(hiZ-loZ,2))*.5;}
        double distanceSquared(double x,double y,double z){
            double dx=Math.max(0,Math.max(loX-x,x-hiX));
            double dy=Math.max(0,Math.max(loY-y,y-hiY));
            double dz=Math.max(0,Math.max(loZ-z,z-hiZ));
            return dx*dx+dy*dy+dz*dz;
        }
        void close(){
            if(opaque!=null){opaque.close();opaque=null;}
            if(transparent!=null){transparent.close();transparent=null;}
        }
    }
    private static final class Scene {
        final PreciseWorldModel model;
        final List<Section> sections;
        final class_2338 anchor;
        Scene(PreciseWorldModel model,class_2338 anchor,List<Section> sections){
            this.model=model;this.anchor=anchor;this.sections=sections;
        }
        void close(){for(Section section:sections)section.close();}
    }

    private Scene getScene(PreciseDisplayEntity be,PreciseWorldModel model,Object world){
        if(currentWorld!=world){close();currentWorld=world;}
        class_2338 pos=be.method_11016();
        Scene current=scenes.get(pos);
        if(current!=null && current.model==model)return current;
        if(current!=null){memoryBytes-=bytes(current);current.close();scenes.remove(pos);}
        Scene scene=new Scene(model,pos,planSections(model,pos));
        scenes.put(pos,scene);
        // Avoid unbounded GPU use when multiple projections exist in one world.
        while(scenes.size()>8){
            var it=scenes.entrySet().iterator();var oldest=it.next();
            memoryBytes-=bytes(oldest.getValue());oldest.getValue().close();it.remove();
        }
        return scene;
    }
    private static int bytes(Scene scene){
        int n=0;for(Section section:scene.sections)n+=section.bytes;return n;
    }
    private List<Section> planSections(PreciseWorldModel model,class_2338 anchor){
        Map<PreciseGpuPlan.Cell,Section> grouped=new LinkedHashMap<>();
        List<LDrawProjectReader.Instance> parts=model.parts();
        for(int i=0;i<parts.size();i++){
            var p=parts.get(i);
            // Centre of the actual LDraw part (not just the stud location).
            String id=PreciseReferenceMapper.geometryId(p.partId());
            double[] b=id==null?null:LDrawLibrary.originalBounds(id);
            if(b==null)continue;
            double[] m=p.matrix();
            double x=(b[0]+b[3])*.5,y=(b[1]+b[4])*.5,z=(b[2]+b[5])*.5;
            double wx=(p.x()+m[0]*x+m[1]*y+m[2]*z)/20-model.minX();
            double wy=-(p.y()+m[3]*x+m[4]*y+m[5]*z)/20-model.minY();
            double wz=(p.z()+m[6]*x+m[7]*y+m[8]*z)/20-model.minZ();
            double dx=b[3]-b[0],dy=b[4]-b[1],dz=b[5]-b[2];
            double r=Math.sqrt(dx*dx+dy*dy+dz*dz)/40;
            Section section=grouped.computeIfAbsent(PreciseGpuPlan.cell(wx,wy,wz,cellSize),k->new Section());
            section.indices.add(i);section.include(wx,wy,wz,r);
        }
        return new ArrayList<>(grouped.values());
    }
    private LDrawLibrary.Mesh mesh(String id){
        if(meshCache.containsKey(id))return meshCache.get(id);
        LDrawLibrary.Mesh full=LDrawLibrary.mesh(id);
        LDrawLibrary.Mesh selected=null;
        if(full!=null && !full.isEmpty()){
            if(quality==3)selected=full;
            else{
                PreciseMeshLods.Levels levels=PreciseMeshLods.generate(full);
                selected=quality==0?levels.tiny():quality==1?levels.low():levels.medium();
            }
        }
        meshCache.put(id,selected);
        return selected;
    }
    private record Counters(int opaque,int transparent){}
    private static final class Builder {
        final class_9799 alloc;
        final class_287 out;
        int tris;
        Builder(int estimatedBytes){
            alloc=new class_9799(Math.max(4096,estimatedBytes));
            out=new class_287(alloc,class_293.class_5596.field_27379,class_290.field_1576);
        }
        void v(float x,float y,float z,int color){out.method_22912(x,y,z).method_39415(color);}
        class_291 upload(){
            if(tris==0){alloc.close();return null;}
            try(class_9801 built=out.method_60800()){
                class_291 gpu=new class_291(class_291.class_8555.field_44793);
                try{
                    gpu.method_1353();gpu.method_1352(built);return gpu;
                }catch(RuntimeException exc){gpu.close();throw exc;}
                finally{class_291.method_1354();}
            }finally{alloc.close();}
        }
    }
    /** Load one whole spatial section and transfer it to the GPU exactly once. */
    private void uploadSection(Section section,PreciseWorldModel model){
        long start=System.nanoTime();
        // Estimate; BufferAllocator grows if real meshes exceed estimate.
        Builder opaque=new Builder(section.indices.size()*1200);
        Builder glass=new Builder(section.indices.size()*128);
        for(int i:section.indices){
            var p=model.parts().get(i);String id=PreciseReferenceMapper.geometryId(p.partId());
            if(id==null)continue;
            double[] bounds=LDrawLibrary.originalBounds(id);
            LDrawLibrary.Mesh mesh=mesh(id);
            if(mesh==null || bounds==null)continue;
            float[] xyz=mesh.xyz();int[] colors=mesh.colors();double[] mat=p.matrix();
            double baseX=model.minX(),baseY=model.minY(),baseZ=model.minZ();
            int fallback=LDrawLibrary.resolveColor(p.color(),0xD0D0D0);
            float[] transformed=new float[9];
            for(int t=0;t<mesh.triangles();t++){
                int rgb=LDrawLibrary.meshColor(colors[t],p.color(),fallback);
                Builder dst=((rgb>>>24)&255)<250?glass:opaque;
                int o=t*9;
                for(int v=0;v<3;v++){
                    int j=o+v*3;
                    double x=bounds[0]+xyz[j]*20;
                    double y=bounds[4]-xyz[j+1]*20;
                    double z=bounds[2]+xyz[j+2]*20;
                    transformed[v*3]=(float)((p.x()+mat[0]*x+mat[1]*y+mat[2]*z)/20-baseX);
                    transformed[v*3+1]=(float)(-(p.y()+mat[3]*x+mat[4]*y+mat[5]*z)/20-baseY);
                    transformed[v*3+2]=(float)((p.z()+mat[6]*x+mat[7]*y+mat[8]*z)/20-baseZ);
                }
                // PositionColor has no normal attribute. Bake a gentle directional shade.
                float nx=(transformed[4]-transformed[1])*(transformed[8]-transformed[2])-(transformed[5]-transformed[2])*(transformed[7]-transformed[1]);
                float ny=(transformed[5]-transformed[2])*(transformed[6]-transformed[0])-(transformed[3]-transformed[0])*(transformed[8]-transformed[2]);
                float nz=(transformed[3]-transformed[0])*(transformed[7]-transformed[1])-(transformed[4]-transformed[1])*(transformed[6]-transformed[0]);
                float mag=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
                if(mag<1e-8f)continue;
                float lit=(float)(.72+.28*Math.abs((nx*.3+ny*.86+nz*.40)/mag));
                int color=shade(rgb,lit);
                for(int v=0;v<3;v++){
                    dst.v(transformed[v*3],transformed[v*3+1],transformed[v*3+2],color);
                }
                dst.tris++;
            }
        }
        // Guard against building an unlimited number of GPU buffers.
        int targetBytes=(opaque.tris+glass.tris)*3*VERTEX_BYTES;
        if(memoryBytes+targetBytes>limitBytes){
            // Cancel the native builders safely; leave the section pending for reporting.
            // upload() cleans temporary allocations, and buffers are immediately closed.
            class_291 a=opaque.upload(),b=glass.upload();
            if(a!=null)a.close();if(b!=null)b.close();
            section.complete=true;section.memoryDeferred=true;
            memoryBlockedSections++;
            return;
        }
        class_291 a=null,b=null;
        try{
            a=opaque.upload();b=glass.upload();
            section.opaque=a;section.transparent=b;
            section.trianglesOpaque=opaque.tris;section.trianglesTransparent=glass.tris;
            section.bytes=targetBytes;memoryBytes+=targetBytes;
            uploadedTriangles+=opaque.tris+glass.tris;
            section.complete=true;
        }catch(RuntimeException exc){
            if(a!=null)a.close();if(b!=null)b.close();throw exc;
        }finally{lastUploadNanos=System.nanoTime()-start;}
    }
    private static int shade(int argb,float mul){
        int r=(int)(((argb>>16)&255)*mul),g=(int)(((argb>>8)&255)*mul),b=(int)((argb&255)*mul);
        return (argb&0xFF000000)|(r<<16)|(g<<8)|b;
    }

    /** Direct VBO rendering with explicit world-to-camera transform.
     *  All VBO vertices are in model-local space relative to the BE anchor:
     *  worldPoint = anchor + localVertex. The camera matrix must first subtract the
     *  camera position from the anchor and then apply inverse camera rotation.
     *  Do not apply the BER MatrixStack *and* this translation (double transform).
     */
    private Matrix4f viewMatrix(PreciseDisplayEntity entity,class_4587 matrices,
                                net.minecraft.class_4184 camera){
        if(!explicitCameraView){
            // Old V0.9.5 path, available only to compare screenshots (F10).
            return new Matrix4f(matrices.method_23760().method_23761());
        }
        class_243 cam=camera.method_19326(); class_2338 anchor=entity.method_11016();
        // The quaternion describes camera-to-world; its conjugate is the view rotation.
        Quaternionf inverse=new Quaternionf(camera.method_23767()).conjugate();
        return new Matrix4f().rotate(inverse).translate(
                (float)((double)anchor.method_10263()-cam.field_1352),
                (float)((double)anchor.method_10264()-cam.field_1351),
                (float)((double)anchor.method_10260()-cam.field_1350));
    }
    void render(PreciseDisplayEntity entity,PreciseWorldModel model,class_4587 matrices){
        class_310 client=class_310.method_1551();
        if(client.field_1687==null)return;
        Scene scene=getScene(entity,model,client.field_1687);
        if(scene.sections.isEmpty() && !model.parts().isEmpty())
            throw new IllegalStateException("Aucun lot GPU planifie : activer le renderer legacy");
        var camera=client.field_1773.method_19418();
        class_243 cam=camera.method_19326();
        double x=cam.field_1352-entity.method_11016().method_10263(),y=cam.field_1351-entity.method_11016().method_10264(),z=cam.field_1350-entity.method_11016().method_10260();
        List<Section> visible=new ArrayList<>(scene.sections.size());
        totalSections=scene.sections.size();culledSections=0;
        if(cullingEnabled){
            Vector3f forward=new Vector3f(0,0,-1).rotate(camera.method_23767());
            for(Section s:scene.sections){
                if(PreciseGpuPlan.behindCamera(x,y,z,s.cx(),s.cy(),s.cz(),forward.x,forward.y,forward.z,s.radius())){
                    culledSections++;continue;
                }
                visible.add(s);
            }
        }else{
            // The safe mode neither hides NOR skips preparation of any section.
            visible.addAll(scene.sections);
        }
        visible.sort(Comparator.comparingDouble(s->s.distanceSquared(x,y,z)));
        visibleSections=visible.size();
        int remainingUploads=uploadsPerFrame;
        pendingSections=0;
        for(Section s:visible){
            if(s.complete)continue;
            pendingSections++;
            if(remainingUploads>0){uploadSection(s,model);remainingUploads--;}
        }
        // Keep counter semantics explicit: complete but memory-deferred is NOT ready.
        readySections=0;unloadedSections=0;
        for(Section s:scene.sections){
            if(s.memoryDeferred || !s.complete)unloadedSections++;
            else readySections++;
        }
        if(!visibility)return;
        long start=System.nanoTime();renderedTriangles=0;drawCalls=0;
        Matrix4f view=viewMatrix(entity,matrices,camera);
        Matrix4f projection=RenderSystem.getProjectionMatrix();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull(); // LDraw often has mixed-face winding.
        try{
            RenderSystem.disableBlend();RenderSystem.depthMask(true);
            for(Section s:visible)if(s.opaque!=null){
                s.opaque.method_1353();s.opaque.method_34427(view,projection,class_757.method_34540());
                renderedTriangles+=s.trianglesOpaque;drawCalls++;
            }
            RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();RenderSystem.depthMask(false);
            // Translucent batches are sorted far to near at section granularity.
            for(int i=visible.size()-1;i>=0;i--){Section s=visible.get(i);
                if(s.transparent!=null){
                    s.transparent.method_1353();s.transparent.method_34427(view,projection,class_757.method_34540());
                    renderedTriangles+=s.trianglesTransparent;drawCalls++;
                }
            }
        }finally{
            class_291.method_1354();RenderSystem.depthMask(true);RenderSystem.disableBlend();RenderSystem.enableCull();
            lastDrawNanos=System.nanoTime()-start;
        }
    }
    String stats(){
        return "GPU CAMERA:" + (explicitCameraView?"EXPLICITE":"ANCIENNE")
                + " | CULL:"+(cullingEnabled?"ON":"OFF")
                + " | visibles:"+visibleSections+"/"+totalSections
                + " | prets:"+readySections+" manquants:"+unloadedSections+" rejetes:"+culledSections
                + "\n"+drawCalls+" draw | "+renderedTriangles+" tris | "
                +String.format(Locale.ROOT,"%.2f",lastDrawNanos/1e6)+" ms CPU"
                + " | VRAM estim.:"+(memoryBytes/1048576)+" MiB"
                +(memoryBlockedSections>0?" | MEMOIRE BLOQUE "+memoryBlockedSections:"");
    }
    boolean toggleViewMatrix(){explicitCameraView=!explicitCameraView;return explicitCameraView;}
    boolean toggleCulling(){cullingEnabled=!cullingEnabled;return cullingEnabled;}
    boolean explicitCameraView(){return explicitCameraView;}
    boolean cullingEnabled(){return cullingEnabled;}
    void setVisible(boolean v){visibility=v;}
    void close(){
        for(Scene s:scenes.values())s.close();
        scenes.clear();meshCache.clear();memoryBytes=0;memoryBlockedSections=0;currentWorld=null;
    }
}
