package fr.brickcraft.client;

import fr.brickcraft.client.WorldPiecePicker.Hit;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.net.PreciseWorldEditPayload;
import fr.brickcraft.world.PreciseDisplayEntity;
import fr.brickcraft.world.PreciseWorldEditMath;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix4f;
import java.util.*;

/**
 * Direct-in-world manipulation. F4 toggles editor. The mouse ray selects ORIGINAL
 * oriented LEGO volumes rather than Minecraft blocks. Axis + wheel commits a small,
 * server-authorized LDU / matrix delta, persisted in the projection block entity.
 */
public final class PreciseWorldEditor {
    private PreciseWorldEditor(){}
    private static boolean enabled,rotation,snapEnabled;
    private static int axis=0,index=-1;
    private static class_2338 anchor;
    private static String status="";
    public static boolean enabled(){return enabled;}
    public static void reset(){enabled=false;index=-1;anchor=null;rotation=false;snapEnabled=false;status="";}
    public static boolean toggle(class_310 client){
        enabled=!enabled;index=-1;anchor=null;rotation=false;axis=0;
        status=enabled?"Clic gauche : choisir une piece LEGO. F4 : quitter.":"";
        if(client.field_1724!=null)client.field_1724.method_7353(class_2561.method_43470(
                "BrickCraft : edition en monde "+(enabled?"ACTIVE":"DESACTIVEE")),true);
        return enabled;
    }
    private static PreciseDisplayEntity selected(class_310 client){
        if(anchor==null||index<0||client.field_1687==null)return null;
        if(!(client.field_1687.method_8321(anchor) instanceof PreciseDisplayEntity be))return null;
        return be.model()!=null&&index<be.model().parts().size()?be:null;
    }
    private static double[] bounds(String part){
        String mapped=PreciseReferenceMapper.geometryId(part);
        return mapped==null?null:LDrawLibrary.originalBounds(mapped);
    }
    private record Selection(class_2338 anchor,WorldPiecePicker.Hit hit){}
    public static boolean attack(class_310 client){
        if(!enabled||client.field_1755!=null||client.field_1724==null||client.field_1687==null)return false;
        class_243 from=client.field_1724.method_33571(),dir=client.field_1724.method_5828(1.0f);
        ArrayList<Selection> hits=new ArrayList<>();
        for(PreciseDisplayEntity be:PreciseDisplayRenderer.activeProjections(client.field_1687)){
            var model=be.model();if(model==null)continue;
            class_2338 a=be.method_11016();
            for(var hit:WorldPiecePicker.hits(model.parts(),model.minX(),model.minY(),model.minZ(),
                    a.method_10263(),a.method_10264(),a.method_10260(),from.field_1352,from.field_1351,from.field_1350,dir.field_1352,dir.field_1351,dir.field_1350,12.0,
                    PreciseWorldEditor::bounds))hits.add(new Selection(a,hit));
        }
        hits.sort(Comparator.comparingDouble(s->s.hit().distance()));
        if(hits.isEmpty()){
            index=-1;anchor=null;status="Aucune piece sous le viseur (portee : 12 blocs).";
        }else{
            int found=0;
            if(client.field_1724.method_5715()&&anchor!=null){
                for(int i=0;i<hits.size();i++)if(anchor.equals(hits.get(i).anchor()) && index==hits.get(i).hit().index()){
                    found=(i+1)%hits.size();break;
                }
            }
            Selection chosen=hits.get(found);
            index=chosen.hit().index();anchor=chosen.anchor();
            PreciseDisplayEntity be=selected(client);
            status="Piece #"+(index+1)+" : "+(be==null?"?":be.model().parts().get(index).partId());
        }
        return true; // Cancel vanilla punching / breaking while editing a virtual assembly.
    }
    /** N toggles intelligent mating only while F4 world editing is enabled. */
    public static boolean toggleSnap(){
        if(!enabled)return false;
        snapEnabled=!snapEnabled;
        status=snapEnabled?"Aimant ON : les deplacements essaient un tenon compatible.":
                           "Aimant OFF : placement totalement libre.";
        return true;
    }
    /** B requests a server-authoritative snap of the currently selected brick. */
    public static boolean snapNow(){
        if(!enabled)return false;
        send(PreciseWorldEditMath.SNAP_NOW,0);
        return true;
    }
    public static boolean modeKey(boolean rotate){
        if(!enabled)return false;rotation=rotate;
        status=rotate?"Rotation : choisis X/Y/Z, puis molette.":"Deplacement : choisis X/Y/Z, puis molette.";
        return true;
    }
    public static boolean chooseAxis(int next){
        if(!enabled)return false;axis=next;
        status="Axe "+"XYZ".charAt(axis)+(rotation?" (rotation)":" (deplacement)");return true;
    }
    public static boolean resetRotation(){
        if(!enabled)return false;
        send(PreciseWorldEditMath.RESET,0);return true;
    }
    public static boolean undo(){if(!enabled)return false;send(PreciseWorldEditMath.UNDO,0);return true;}
    private static void send(byte operation,double amount){
        class_310 client=class_310.method_1551();
        if(client.field_1724==null||client.field_1755!=null)return;
        PreciseDisplayEntity be=selected(client);
        if(be==null){status="Selectionne d'abord une piece (clic gauche).";return;}
        if(!client.field_1724.method_7337()){status="Mode Creatif requis pour modifier le monde.";return;}
        ClientPlayNetworking.send(new PreciseWorldEditPayload(anchor,index,operation,(byte)axis,amount));
        status="Piece #"+(index+1)+" : "+
                (operation==PreciseWorldEditMath.SNAP_NOW?"recherche d'attache...":
                operation==PreciseWorldEditMath.MOVE_WITH_SNAP?"deplacement + aimant":
                operation==PreciseWorldEditMath.MOVE?"deplacement":"rotation")+
                " | " +"XYZ".charAt(axis)+" "+(operation==PreciseWorldEditMath.RESET?"reset":amount);
    }
    public static boolean scroll(double vertical){
        if(!enabled)return false;
        class_310 client=class_310.method_1551();
        if(client.field_1755!=null||client.field_1724==null)return false;
        if(vertical==0)return true;
        boolean fine=client.field_1724.method_5715();
        double step=rotation?(fine?1:15):(fine?1:20);
        send(rotation?PreciseWorldEditMath.ROTATE:
                (snapEnabled?PreciseWorldEditMath.MOVE_WITH_SNAP:PreciseWorldEditMath.MOVE),
                Math.signum(vertical)*step);
        return true; // Prevent hotbar scrolling while the world editor is active.
    }
    public static void renderHud(class_332 d,class_310 client){
        if(!enabled||client.field_1724==null||client.field_1755!=null)return;
        int height=d.method_51443(),width=d.method_51421();
        int py=Math.max(8,height-70),px=8;
        String one="BRICKCRAFT WORLD EDIT | "+(rotation?"ROTATION":"DEPLACEMENT")+
                " | AXE "+"XYZ".charAt(axis)+" | AIMANT "+(snapEnabled?"ON":"OFF")+" | F4: quitter";
        String two="Clic: selection | Maj+Clic: superposees | G/R: mode | X/Y/Z: axe";
        String three="Molette: "+(rotation?"15 deg":"20 LDU")+" | N: aimant | B: connecter | H: reset | Ctrl+Z";
        int w=Math.max(client.field_1772.method_1727(one),Math.max(client.field_1772.method_1727(two),
                client.field_1772.method_1727(three)))+10;
        w=Math.min(w,width-16);
        d.method_25294(px-4,py-4,px+w,py+49,0xDD0A2534);
        d.method_25303(client.field_1772,one,px,py,0xFF5CE3DF);
        d.method_25303(client.field_1772,two,px,py+12,0xFFDBF4FA);
        d.method_25303(client.field_1772,three,px,py+24,0xFFEDC98E);
        String selected=anchor==null?status:"#"+(index+1)+" @ "+anchor.method_23854()+" | "+status;
        if(selected.length()>Math.max(12,w/6))selected=selected.substring(0,Math.max(10,w/6-3))+"...";
        d.method_25303(client.field_1772,selected,px,py+36,0xFF9EDADE);
    }
    /** Selection outline in world coordinates, including rotations. No 3D mesh allocations. */
    public static void initOverlay(){
        WorldRenderEvents.AFTER_ENTITIES.register(context->{
            if(!enabled)return;
            class_310 client=class_310.method_1551();
            PreciseDisplayEntity be=selected(client);
            if(be==null||context.consumers()==null||context.matrixStack()==null)return;
            PreciseWorldModel model=be.model();
            var p=model.parts().get(index);double[] b=bounds(p.partId());if(b==null)return;
            class_2338 a=be.method_11016();
            double[][] corners=WorldPiecePicker.corners(p,b,model.minX(),model.minY(),model.minZ(),
                    a.method_10263(),a.method_10264(),a.method_10260());
            class_4587 matrices=context.matrixStack();class_243 cam=context.camera().method_19326();
            matrices.method_22903();matrices.method_22904(-cam.field_1352,-cam.field_1351,-cam.field_1350);
            class_4588 lines=context.consumers().getBuffer(class_1921.method_23594());
            for(int i=0;i<8;i++)for(int bit:new int[]{1,2,4})if((i&bit)==0)
                line(lines,matrices,corners[i],corners[i|bit],0xFFF7D67B);
            // LDraw X/Z positive world axes, LDraw Y positive points down in Minecraft.
            double ox=a.method_10263()+p.x()/20-model.minX();
            double oy=a.method_10264()-p.y()/20-model.minY();
            double oz=a.method_10260()+p.z()/20-model.minZ();
            double[] center={ox,oy,oz};
            line(lines,matrices,center,new double[]{ox+1.2,oy,oz},0xFFFF6666);
            line(lines,matrices,center,new double[]{ox,oy+1.2,oz},0xFF77FFAA);
            line(lines,matrices,center,new double[]{ox,oy,oz+1.2},0xFF66BFFF);
            matrices.method_22909();
        });
    }
    private static void line(class_4588 lines,class_4587 stack,double[] a,double[] b,int c){
        var m=stack.method_23760().method_23761();
        lines.method_22918(m,(float)a[0],(float)a[1],(float)a[2]).method_39415(c).method_22914(0,1,0);
        lines.method_22918(m,(float)b[0],(float)b[1],(float)b[2]).method_39415(c).method_22914(0,1,0);
    }
}
