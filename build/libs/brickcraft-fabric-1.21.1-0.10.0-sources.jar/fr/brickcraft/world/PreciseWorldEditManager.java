package fr.brickcraft.world;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseProjectIO;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.client.WorldPiecePicker;
import fr.brickcraft.net.PreciseWorldEditPayload;
import fr.brickcraft.world.PreciseStudSnapper.Result;
import java.io.IOException;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/** Persistent, server-authoritative editing of one part inside a projected LEGO assembly. */
public final class PreciseWorldEditManager {
    private PreciseWorldEditManager(){}
    private record Last(String dimension,class_2338 anchor,int index,LDrawProjectReader.Instance before,
                        LDrawProjectReader.Instance after){}
    private static final Map<UUID,Deque<Last>> undo=new HashMap<>();
    private static final Map<UUID,Integer> ticks=new HashMap<>(),requests=new HashMap<>();
    private static void error(class_3222 p,String message){p.method_7353(class_2561.method_43470("BrickCraft : "+message),true);}
    private static boolean same(LDrawProjectReader.Instance a,LDrawProjectReader.Instance b){
        return a!=null&&b!=null&&a.partId().equals(b.partId())&&a.color()==b.color()&&
                a.x()==b.x()&&a.y()==b.y()&&a.z()==b.z()&&Arrays.equals(a.matrix(),b.matrix());
    }
    private static boolean nearPart(class_3222 player,PreciseWorldModel model,class_2338 pos,int index){
        var p=model.parts().get(index);
        String id=PreciseReferenceMapper.geometryId(p.partId());
        double[] b=id==null?null:LDrawLibrary.originalBounds(id);
        if(b==null)return false;
        double[][] corners=WorldPiecePicker.corners(p,b,model.minX(),model.minY(),model.minZ(),
                pos.method_10263(),pos.method_10264(),pos.method_10260());
        double loX=Double.POSITIVE_INFINITY,loY=loX,loZ=loX,hiX=-loX,hiY=-loX,hiZ=-loX;
        for(double[] v:corners){loX=Math.min(loX,v[0]);loY=Math.min(loY,v[1]);loZ=Math.min(loZ,v[2]);
            hiX=Math.max(hiX,v[0]);hiY=Math.max(hiY,v[1]);hiZ=Math.max(hiZ,v[2]);}
        class_243 eye=player.method_33571();
        double dx=Math.max(0,Math.max(loX-eye.field_1352,eye.field_1352-hiX));
        double dy=Math.max(0,Math.max(loY-eye.field_1351,eye.field_1351-hiY));
        double dz=Math.max(0,Math.max(loZ-eye.field_1350,eye.field_1350-hiZ));
        return dx*dx+dy*dy+dz*dz<=16*16;
    }
    public static void receive(class_3222 player,PreciseWorldEditPayload q){
        if(!player.method_7337()||player.method_7325()){error(player,"edition disponible en Creatif uniquement");return;}
        // Never allow a malformed client to flood serialized NBT/network updates.
        int tick=player.field_6012;
        if(ticks.getOrDefault(player.method_5667(),-1)!=tick){ticks.put(player.method_5667(),tick);requests.put(player.method_5667(),0);}
        int n=requests.merge(player.method_5667(),1,Integer::sum);
        if(n>6)return;
        class_3218 world=player.method_51469();class_2338 pos=q.anchor();
        if(!world.method_22340(pos)||!world.method_24794(pos)||
                !world.method_8320(pos).method_27852(BrickCraft.PRECISE_DISPLAY)||
                !world.method_8505(player,pos)||
                !(world.method_8321(pos) instanceof PreciseDisplayEntity anchor)){
            error(player,"projection indisponible ou zone protegee");return;
        }
        PreciseWorldModel model=anchor.model();
        if(model==null||q.index()>=model.parts().size()){error(player,"piece non chargee");return;}
        if(!nearPart(player,model,pos,q.index())){error(player,"rapproche-toi de la piece (16 blocs maximum)");return;}
        if(q.operation()==PreciseWorldEditMath.UNDO){undo(player,world,anchor,model,q.index());return;}
        var before=model.parts().get(q.index());
        LDrawProjectReader.Instance after;
        try {
            if(q.operation()==PreciseWorldEditMath.SNAP_NOW){
                if(q.amount()!=0){error(player,"snap : parametre inattendu");return;}
                after=before;
            }else if(q.operation()==PreciseWorldEditMath.MOVE_WITH_SNAP){
                after=PreciseWorldEditMath.apply(before,PreciseWorldEditMath.MOVE,q.axis(),q.amount());
            }else{
                after=PreciseWorldEditMath.apply(before,q.operation(),q.axis(),q.amount());
            }
        }catch(IllegalArgumentException ex){error(player,ex.getMessage());return;}
        ArrayList<LDrawProjectReader.Instance> parts=new ArrayList<>(model.parts());
        parts.set(q.index(),after);
        boolean didSnap=false;
        int mate=-1;
        if(q.operation()==PreciseWorldEditMath.SNAP_NOW &&
                PreciseStudSnapper.profile(before.partId())==null){
            error(player,"reference sans connecteurs verifies : placement libre disponible");return;
        }
        if(q.operation()==PreciseWorldEditMath.SNAP_NOW ||
                q.operation()==PreciseWorldEditMath.MOVE_WITH_SNAP){
            try {
                var snapped=PreciseStudSnapper.snap(parts,q.index(),10.0);
                if(snapped.snapped()){
                    didSnap=true;mate=snapped.supportIndex();
                    after=snapped.piece();parts.set(q.index(),after);
                }else if(q.operation()==PreciseWorldEditMath.SNAP_NOW){
                    error(player,"aucun tenon compatible proche (10 LDU). Piece libre conservee");
                    return;
                }
            }catch(IllegalArgumentException ex){error(player,ex.getMessage());return;}
        }
        if(same(before,after))return;
        try{anchor.setModel(PreciseWorldModel.editKeepingOrigin(parts,model));}
        catch(IllegalArgumentException|IOException ex){error(player,"deplacement impossible : "+ex.getMessage());return;}
        if(didSnap)player.method_7353(class_2561.method_43470("BrickCraft : connecte piece #"+(q.index()+1)+
                " sur #"+(mate+1)+" (tenon compatible)"),true);
        Deque<Last> history=undo.computeIfAbsent(player.method_5667(),id->new ArrayDeque<>());
        history.addFirst(new Last(world.method_27983().method_29177().toString(),pos.method_10062(),q.index(),before,after));
        while(history.size()>64)history.removeLast();
    }
    private static void undo(class_3222 player,class_3218 world,PreciseDisplayEntity be,
                             PreciseWorldModel model,int index){
        Deque<Last> history=undo.get(player.method_5667());
        if(history==null||history.isEmpty()){error(player,"aucune action a annuler");return;}
        Last last=history.peekFirst();
        if(!last.dimension().equals(world.method_27983().method_29177().toString())||
                !last.anchor().equals(be.method_11016())||last.index()!=index||
                !same(model.parts().get(index),last.after())){
            error(player,"annulation refusee : projet modifie ou autre piece selectionnee");return;
        }
        ArrayList<LDrawProjectReader.Instance> parts=new ArrayList<>(model.parts());parts.set(index,last.before());
        try{be.setModel(PreciseWorldModel.editKeepingOrigin(parts,model));history.removeFirst();}
        catch(IOException|IllegalArgumentException ex){error(player,"annulation impossible");}
    }
}
