package fr.brickcraft.core;

/** Dimensions in LEGO studs horizontally and plates vertically. */
public enum BrickKind {
    BRICK_1X1("Brique 1×1", 1, 1, 3, true),
    BRICK_1X2("Brique 1×2", 1, 2, 3, true),
    BRICK_2X2("Brique 2×2", 2, 2, 3, true),
    BRICK_2X4("Brique 2×4", 2, 4, 3, true),
    PLATE_1X2("Plaque 1×2", 1, 2, 1, true),
    TILE_1X2("Tuile 1×2", 1, 2, 1, false);

    public final String title;
    public final int width, length, plates;
    public final boolean studs;

    BrickKind(String title, int width, int length, int plates, boolean studs) {
        this.title = title;
        this.width = width;
        this.length = length;
        this.plates = plates;
        this.studs = studs;
    }

    public int width(int quarterTurn) { return (quarterTurn & 1) == 0 ? width : length; }
    public int length(int quarterTurn) { return (quarterTurn & 1) == 0 ? length : width; }
}
