package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import fr.brickcraft.core.BrickPiece;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * V0.2.1: tabbed, single-sidebar editor that adapts to Minecraft GUI scale.
 * The stage uses a clipped, interactive isometric projection (not GPU 3D yet).
 */
public final class BrickStudioScreen extends class_437 {
    private static final List<BrickPiece> ASSEMBLY = new ArrayList<>();
    private static final int GRID = 12;
    private enum Tab { PIECES, COULEURS, POSITION }

    private final class_2338 target;
    private Tab tab = Tab.PIECES;
    private StudioLayout layout;
    private int cursorX = 0, cursorZ = 0;
    private float orbit = .72f;
    private float zoom = 1f;
    private boolean orbitDragging = false;
    private String status = "Selectionne une piece, puis clique dans la grille.";

    public BrickStudioScreen(class_2338 target) {
        super(class_2561.method_43470("BrickCraft Studio - V0.2.1"));
        this.target = target;
    }

    @Override
    protected void method_25426() {
        layout = StudioLayout.calculate(field_22789, field_22790);
        final int left = layout.panelX() + 3;
        final int panel = layout.panelW() - 6;
        final int gap = 2;
        final int tabW = (panel - 2 * gap) / 3;

        button(left, 28, tabW, 19, "Pieces", () -> changeTab(Tab.PIECES));
        button(left + tabW + gap, 28, tabW, 19, "Couleurs", () -> changeTab(Tab.COULEURS));
        button(left + 2 * (tabW + gap), 28, panel - 2 * (tabW + gap), 19,
                "Pos.", () -> changeTab(Tab.POSITION));

        if (tab == Tab.PIECES) {
            final int w = (panel - 8) / 2;
            BrickKind[] kinds = BrickKind.values();
            for (int i = 0; i < kinds.length; i++) {
                BrickKind kind = kinds[i];
                int row = i / 2, col = i % 2;
                int px = left + 2 + col * (w + 4);
                int py = 65 + row * 27;
                button(px, py, w, 23, shortName(kind), () -> {
                    BrickSelection.kind = kind;
                    status = "Piece : " + kind.title;
                });
            }
        } else if (tab == Tab.POSITION) {
            final int bw = (panel - 8) / 2;
            final int step = Math.max(21, Math.min(27, (layout.footerY() - 89) / 6));
            for (int i = 0; i < 6; i++) {
                int py = 64 + i * step;
                switch (i) {
                    case 0 -> {button(left+2, py, bw, 19, "X -", () -> cursorX = Math.max(0, cursorX-1));
                               button(left+bw+6, py, bw, 19, "X +", () -> cursorX = Math.min(GRID-1, cursorX+1));}
                    case 1 -> {button(left+2, py, bw, 19, "Z -", () -> cursorZ = Math.max(0, cursorZ-1));
                               button(left+bw+6, py, bw, 19, "Z +", () -> cursorZ = Math.min(GRID-1, cursorZ+1));}
                    case 2 -> {button(left+2, py, bw, 19, "H -", () -> BrickSelection.layer = Math.max(0, BrickSelection.layer-1));
                               button(left+bw+6, py, bw, 19, "H +", () -> BrickSelection.layer = Math.min(30, BrickSelection.layer+1));}
                    case 3 -> {button(left+2, py, bw, 19, "Cam -", () -> orbit -= .25f);
                               button(left+bw+6, py, bw, 19, "Cam +", () -> orbit += .25f);}
                    case 4 -> {button(left+2, py, bw, 19, "Zoom -", () -> zoom = Math.max(.4f, zoom-.15f));
                               button(left+bw+6, py, bw, 19, "Zoom +", () -> zoom = Math.min(2.5f, zoom+.15f));}
                    case 5 -> {button(left+2, py, panel-4, 19, "Recentrer camera", () -> {orbit=.72f;zoom=1f;});}
                    default -> {}
                }
            }
        }

        final String[] names = {"Poser", "Tourner", "Annuler", "Vider", "En jeu", "Fermer"};
        final Runnable[] actions = {this::add, () -> BrickSelection.turn = (BrickSelection.turn+1)&3,
            () -> {if (!ASSEMBLY.isEmpty()) {ASSEMBLY.remove(ASSEMBLY.size()-1); status="Derniere piece retiree";}},
            () -> {ASSEMBLY.clear(); status="Atelier vide";}, this::applyToWorld, this::method_25419};
        final int spacing = 3, first = 6;
        final int available = field_22789 - 2*first - 5*spacing;
        final int base = available / names.length;
        int bx = first;
        for (int i=0;i<names.length;i++) {
            int bw = i==names.length-1 ? field_22789-first-bx : base;
            button(bx,layout.footerY(),bw,20,names[i],actions[i]);
            bx += bw+spacing;
        }
    }

    private void changeTab(Tab next) {
        if(tab==next) return;
        tab = next;
        method_41843();
    }

    private static String shortName(BrickKind kind) {
        return kind.title.replace("Brique ", "B ")
                .replace("Plaque ", "P ").replace("Tuile ", "T ")
                .replace('×', 'x');
    }

    private void button(int x, int y, int w, int h, String title, Runnable callback) {
        // Buttons must never reach the screen footer/status area or offscreen.
        if (w < 12 || h < 12 || x >= field_22789 || y < 0 || y+h > field_22790-19) return;
        if (y < layout.footerY() && y+h > layout.footerY()-3) return;
        method_37063(class_4185.method_46430(class_2561.method_43470(title), b -> callback.run())
                .method_46434(x,y,w,h).method_46431());
    }

    private void add() {
        BrickPiece p=BrickSelection.piece(cursorX,cursorZ);
        if(!p.valid() || p.x()+p.width()>GRID || p.z()+p.length()>GRID || p.top()>66) {
            status="Hors du plateau : 12 x 12 / 33 plaques";return;
        }
        if(ASSEMBLY.size()>=256) {status="Limite de 256 pieces pour le prototype";return;}
        for(BrickPiece previous: ASSEMBLY) if(p.intersects(previous)) {
            status="Collision : cette position est deja occupee";return;
        }
        ASSEMBLY.add(p);
        status="Piece ajoutee : "+p.kind().title+" ("+ASSEMBLY.size()+")";
    }

    private void applyToWorld() {
        if(field_22787==null || field_22787.field_1724==null || !field_22787.field_1724.method_6047().method_31574(BrickCraft.TOOL)) {
            status="Tiens l'outil BrickCraft dans la main";return;
        }
        if(target==null) {status="Vise le sol avant d'ouvrir le Studio";return;}
        if(ASSEMBLY.isEmpty()) {status="Ajoute une piece dans l'atelier";return;}
        for(BrickPiece local: ASSEMBLY) {
            ClientPlayNetworking.send(new BrickActionPayload(target,class_2350.field_11036,.5f,.5f,.5f,
                    false,true,local));
        }
        status=ASSEMBLY.size()+" placements envoyes au serveur";
    }

    /** Own the whole background: no second blurred UI layer over labels. */
    @Override
    public void method_25420(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Intentionally empty. render() draws a completely opaque background.
    }

    @Override
    public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
        // The screen's scaled dimensions are fixed until Minecraft calls init() on resize.
        int sx=layout.stageX(), ex=layout.stageRight();
        int top=layout.stageTop(), bottom=layout.stageBottom();
        ctx.method_25294(0,0,field_22789,field_22790,0xFF0B111A);
        ctx.method_25294(4,23,layout.panelX()+layout.panelW()+2,bottom+3,0xFF162330);
        ctx.method_25294(sx,top,ex,bottom,0xFF0B1B27);
        ctx.method_25294(sx,top,ex,top+1,0xFF345267);
        ctx.method_25294(0,layout.footerY()-3,field_22789,field_22790,0xFF192A39);
        text(ctx,"BRICKCRAFT  /  STUDIO 0.2.1",9,8,0xFFE4F4FF,field_22789-16);

        // Scissor sidebar content so no label can run behind the action row.
        ctx.method_44379(layout.panelX(),53,layout.panelX()+layout.panelW()+2,layout.footerY()-4);
        switch(tab) {
            case PIECES -> renderPiecesPanel(ctx);
            case COULEURS -> renderColorsPanel(ctx);
            case POSITION -> renderPositionPanel(ctx);
        }
        ctx.method_44380();

        ctx.method_44379(sx+2,top+2,ex-2,bottom-2);
        text(ctx,"12 x 12  |  Clic gauche : poser",sx+7,top+6,0xFFB7D8ED,ex-sx-12);
        text(ctx,"Droit-glisser : orbite  |  molette : zoom",sx+7,top+18,0xFF789AAB,ex-sx-12);
        ctx.method_44379(sx+2,top+32,ex-2,bottom-3);
        renderViewport(ctx);
        ctx.method_44380();
        text(ctx,"X="+cursorX+" Z="+cursorZ+" H="+BrickSelection.layer+" | "+ASSEMBLY.size()+" pieces",
                sx+7,bottom-14,0xFFE4D29A,ex-sx-12);
        ctx.method_44380();

        text(ctx,status,9,field_22790-16,0xFFE4D29A,field_22789-16);
        super.method_25394(ctx,mouseX,mouseY,delta);
    }

    private void renderPiecesPanel(class_332 ctx) {
        text(ctx,"FORMES",layout.panelX()+6,53,0xFF9DCCDD,layout.panelW()-12);
        text(ctx,"Selection",layout.panelX()+6,155,0xFF85A7BA,layout.panelW()-12);
        text(ctx,BrickSelection.kind.title,layout.panelX()+6,169,0xFFFFFFFF,layout.panelW()-12);
        text(ctx,"Rotation : "+(BrickSelection.turn*90)+" deg",layout.panelX()+6,189,0xFF9BBECC,layout.panelW()-12);
        text(ctx,"Hauteur : "+BrickSelection.layer+" plaques",layout.panelX()+6,203,0xFF9BBECC,layout.panelW()-12);
        text(ctx,"Couleur : "+colorName(),layout.panelX()+6,224,0xFFF4D9A1,layout.panelW()-12);
        int rx=layout.panelX()+8,ry=244;
        ctx.method_25294(rx,ry,rx+30,ry+12,0xFF000000|BrickSelection.rgb);
        text(ctx,"1 tenon = 1 bloc MC",layout.panelX()+6,269,0xFF7195A7,layout.panelW()-12);
    }

    private String colorName() {
        for(int i=0;i<BrickPalette.COLORS.length;i++)
            if(BrickPalette.COLORS[i]==BrickSelection.rgb) return BrickPalette.NAMES[i];
        return String.format("#%06X",BrickSelection.rgb);
    }

    private int swatchSize() {
        return Math.min(29,Math.max(19,(layout.panelW()-34)/4));
    }

    private void renderColorsPanel(class_332 ctx) {
        text(ctx,"PALETTE - 16 teintes",layout.panelX()+6,55,0xFF9DCCDD,layout.panelW()-12);
        int sw=swatchSize(),gap=3;
        int originX=layout.panelX()+9,originY=76;
        for(int i=0;i<BrickPalette.COLORS.length;i++) {
            int x=originX+(i%4)*(sw+gap),y=originY+(i/4)*(sw+gap);
            boolean selected=BrickSelection.rgb==BrickPalette.COLORS[i];
            ctx.method_25294(x-2,y-2,x+sw+2,y+sw+2,selected?0xFFFFFFFF:0xFF43596C);
            ctx.method_25294(x,y,x+sw,y+sw,0xFF000000|BrickPalette.COLORS[i]);
        }
        int under=originY+4*(sw+gap)+8;
        text(ctx,colorName(),layout.panelX()+6,under,0xFFF7F7F7,layout.panelW()-12);
        text(ctx,String.format("#%06X",BrickSelection.rgb),layout.panelX()+6,under+16,0xFF9DBDCD,layout.panelW()-12);
        text(ctx,"Clic sur une couleur",layout.panelX()+6,under+38,0xFF7A9CAC,layout.panelW()-12);
    }

    private void renderPositionPanel(class_332 ctx) {
        text(ctx,"DEPLACEMENT",layout.panelX()+6,53,0xFF9DCCDD,layout.panelW()-12);
        int bottom=Math.min(layout.footerY()-20,240);
        text(ctx,"X="+cursorX+"   Z="+cursorZ,layout.panelX()+6,bottom,0xFFE4F4FF,layout.panelW()-12);
        text(ctx,"H="+BrickSelection.layer+" plaques",layout.panelX()+6,bottom+13,0xFFE4D29A,layout.panelW()-12);
    }

    private void text(class_332 ctx,String str,int x,int y,int rgb,int maxWidth) {
        if(maxWidth<10)return;
        // Text length is measured, so labels cannot paint over the viewport or footer.
        if(field_22793.method_1727(str)>maxWidth) {
            String suffix="...";
            int end=str.length();
            while(end>0 && field_22793.method_1727(str.substring(0,end)+suffix)>maxWidth)end--;
            str=str.substring(0,end)+suffix;
        }
        ctx.method_25303(field_22793,str,x,y,rgb);
    }

    private int centerX() {return (layout.stageX()+layout.stageRight())/2;}
    private int centerY() {return (layout.stageTop()+32+layout.stageBottom())/2+9;}
    private float baseZoom() {
        float byWidth=(layout.stageWidth()-16)/18f;
        float byHeight=(layout.stageHeight()-44)/12f;
        return Math.max(4f,Math.min(byWidth,byHeight))*zoom;
    }
    private record P(int x,int y) {}
    private P project(float x,float y,float z) {
        float units=baseZoom();
        double u=(x-GRID/2f)*Math.cos(orbit)-(z-GRID/2f)*Math.sin(orbit);
        double d=(x-GRID/2f)*Math.sin(orbit)+(z-GRID/2f)*Math.cos(orbit);
        return new P((int)(centerX()+u*units),(int)(centerY()+d*units*.45f-y*units*.9f));
    }
    private double depth(float x,float z) {return x*Math.sin(orbit)+z*Math.cos(orbit);}

    private void renderViewport(class_332 ctx) {
        for(int k=0;k<=GRID;k++) {
            line(ctx,project(k,0,0),project(k,0,GRID),0xFF29526B);
            line(ctx,project(0,0,k),project(GRID,0,k),0xFF29526B);
        }
        List<BrickPiece> ordered=new ArrayList<>(ASSEMBLY);
        ordered.sort(Comparator.comparingDouble(p->depth(p.x()+p.width()/2f,p.z()+p.length()/2f)+p.y()*.04));
        for(BrickPiece p:ordered) drawBrick(ctx,p,false);
        BrickPiece ghost=BrickSelection.piece(cursorX,cursorZ);
        if(ghost.x()+ghost.width()<=GRID && ghost.z()+ghost.length()<=GRID) drawBrick(ctx,ghost,true);
    }

    private void drawBrick(class_332 ctx,BrickPiece p,boolean ghost) {
        float x=p.x(),z=p.z(),y=p.y()/5f,w=p.width(),d=p.length(),h=p.height()/5f;
        P a=project(x,y,z),b=project(x+w,y,z),c=project(x+w,y,z+d),e=project(x,y,z+d);
        P A=project(x,y+h,z),B=project(x+w,y+h,z),C=project(x+w,y+h,z+d),E=project(x,y+h,z+d);
        int alpha=ghost?110:255,rgb=p.rgb();
        face(ctx,new P[]{a,b,B,A},shade(rgb,.68,alpha));
        face(ctx,new P[]{b,c,C,B},shade(rgb,.75,alpha));
        face(ctx,new P[]{c,e,E,C},shade(rgb,.84,alpha));
        face(ctx,new P[]{e,a,A,E},shade(rgb,.64,alpha));
        face(ctx,new P[]{A,B,C,E},shade(rgb,1.12,alpha));
        if(p.kind().studs) {
            for(int i=0;i<p.width();i++) for(int j=0;j<p.length();j++) {
                P stud=project(x+i+.5f,y+h+.09f,z+j+.5f);
                int radius=Math.max(2,(int)(baseZoom()*.11f));
                ctx.method_25294(stud.x-radius,stud.y-radius,stud.x+radius,stud.y+radius,shade(rgb,1.32,alpha));
            }
        }
    }
    private static int shade(int rgb,double factor,int alpha) {
        int r=Math.min(255,(int)(((rgb>>16)&255)*factor));
        int g=Math.min(255,(int)(((rgb>>8)&255)*factor));
        int b=Math.min(255,(int)((rgb&255)*factor));
        return (alpha<<24)|(r<<16)|(g<<8)|b;
    }
    private static void line(class_332 ctx,P a,P b,int color) {
        int dx=Math.abs(b.x-a.x),dy=Math.abs(b.y-a.y);
        int sx=a.x<b.x?1:-1,sy=a.y<b.y?1:-1,err=dx-dy,x=a.x,y=a.y;
        while(true) {
            ctx.method_25294(x,y,x+1,y+1,color);
            if(x==b.x && y==b.y)break;
            int e2=2*err;
            if(e2>-dy) {err-=dy;x+=sx;}
            if(e2<dx) {err+=dx;y+=sy;}
        }
    }
    private static void face(class_332 ctx,P[] pts,int color) {
        int ymin=Integer.MAX_VALUE,ymax=Integer.MIN_VALUE;
        for(P p:pts) {ymin=Math.min(ymin,p.y);ymax=Math.max(ymax,p.y);}
        ymin=Math.max(0,ymin);ymax=Math.min(ctx.method_51443()-1,ymax);
        for(int y=ymin;y<=ymax;y++) {
            float min=Float.MAX_VALUE,max=-Float.MAX_VALUE;
            for(int i=0;i<pts.length;i++) {
                P a=pts[i],b=pts[(i+1)%pts.length];
                if(a.y==b.y || y<Math.min(a.y,b.y) || y>=Math.max(a.y,b.y))continue;
                float xx=a.x+(float)(y-a.y)*(b.x-a.x)/(b.y-a.y);
                min=Math.min(min,xx);max=Math.max(max,xx);
            }
            if(max>=min)ctx.method_25294((int)Math.floor(min),y,(int)Math.ceil(max)+1,y+1,color);
        }
    }

    @Override public boolean method_25402(double mx,double my,int button) {
        if(button==0 && tab==Tab.COULEURS) {
            int sw=swatchSize(),gap=3;
            int originX=layout.panelX()+9,originY=76;
            for(int i=0;i<BrickPalette.COLORS.length;i++) {
                int x=originX+(i%4)*(sw+gap),y=originY+(i/4)*(sw+gap);
                if(mx>=x && mx<x+sw && my>=y && my<y+sw) {
                    BrickSelection.rgb=BrickPalette.COLORS[i];
                    status="Couleur : "+BrickPalette.NAMES[i];
                    return true;
                }
            }
        }
        if(layout.insideStage(mx,my)) {
            if(button==1) {orbitDragging=true;return true;}
            if(button==0) {
                float s=baseZoom();
                double u=(mx-centerX())/s;
                double d=(my-centerY()+(BrickSelection.layer*2f/5f)*s*.9)/(.45*s);
                int gx=(int)Math.floor(u*Math.cos(orbit)+d*Math.sin(orbit)+GRID/2f);
                int gz=(int)Math.floor(-u*Math.sin(orbit)+d*Math.cos(orbit)+GRID/2f);
                cursorX=Math.clamp(gx,0,GRID-1);cursorZ=Math.clamp(gz,0,GRID-1);
                add();return true;
            }
        }
        return super.method_25402(mx,my,button);
    }
    @Override public boolean method_25403(double mx,double my,int button,double dx,double dy) {
        if(button==1 && orbitDragging) {orbit+=(float)dx*.013f;return true;}
        return super.method_25403(mx,my,button,dx,dy);
    }
    @Override public boolean method_25406(double mx,double my,int button) {
        if(button==1 && orbitDragging) {orbitDragging=false;return true;}
        return super.method_25406(mx,my,button);
    }
    @Override public boolean method_25401(double mx,double my,double horizontal,double vertical) {
        if(layout.insideStage(mx,my)) {zoom=Math.clamp(zoom+(float)vertical*.10f,.4f,2.5f);return true;}
        return super.method_25401(mx,my,horizontal,vertical);
    }
    @Override public boolean method_25404(int key,int scan,int mods) {
        if(key==GLFW.GLFW_KEY_Q) {orbit-=.2f;return true;}
        if(key==GLFW.GLFW_KEY_E) {orbit+=.2f;return true;}
        if(key==GLFW.GLFW_KEY_R) {BrickSelection.turn=(BrickSelection.turn+1)&3;return true;}
        if(key==GLFW.GLFW_KEY_DELETE && !ASSEMBLY.isEmpty()) {ASSEMBLY.remove(ASSEMBLY.size()-1);return true;}
        return super.method_25404(key,scan,mods);
    }
    @Override public boolean method_25421() {return false;}
}
