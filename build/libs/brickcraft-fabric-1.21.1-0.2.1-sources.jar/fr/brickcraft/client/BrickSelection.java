package fr.brickcraft.client;

import fr.brickcraft.core.BrickKind;
import fr.brickcraft.core.BrickPalette;
import fr.brickcraft.core.BrickPiece;

/** Current creative selection. Studio coordinates are in studs, Y in 1/5 blocks. */
public final class BrickSelection {
    private BrickSelection() {}
    public static BrickKind kind = BrickKind.BRICK_2X2;
    public static int rgb = BrickPalette.COLORS[4];
    public static int turn = 0;
    public static int layer = 0; // studio plate count, each plate = 2/5 Minecraft block
    public static BrickPiece piece(int x, int z) {
        return new BrickPiece(kind,rgb,x,layer*2,z,turn);
    }
    public static void nextKind() {
        BrickKind[] all = BrickKind.values();
        kind = all[(kind.ordinal()+1)%all.length];
    }
}
