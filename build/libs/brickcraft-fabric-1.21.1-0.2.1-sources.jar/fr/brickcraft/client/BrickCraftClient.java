package fr.brickcraft.client;

import fr.brickcraft.BrickCraft;
import fr.brickcraft.net.BrickActionPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_3965;
import org.lwjgl.glfw.GLFW;

public final class BrickCraftClient implements ClientModInitializer {
    private static class_304 studioKey, nextKey, turnKey;

    @Override public void onInitializeClient() {
        BlockEntityRendererRegistry.register(BrickCraft.CELL_ENTITY, BrickCellRenderer::new);
        studioKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.studio",class_3675.class_307.field_1668,GLFW.GLFW_KEY_B,"category.brickcraft"));
        nextKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.next",class_3675.class_307.field_1668,GLFW.GLFW_KEY_V,"category.brickcraft"));
        turnKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.brickcraft.turn",class_3675.class_307.field_1668,GLFW.GLFW_KEY_R,"category.brickcraft"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (studioKey.method_1436()) {
                if (client.field_1724 != null && client.field_1755 == null)
                    client.method_1507(new BrickStudioScreen(resolveTarget(client)));
            }
            while (nextKey.method_1436()) if (client.field_1755==null) {
                BrickSelection.nextKind();
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(
                    "BrickCraft : "+BrickSelection.kind.title),true);
            }
            while (turnKey.method_1436()) if (client.field_1755==null) {
                BrickSelection.turn=(BrickSelection.turn+1)&3;
                if (client.field_1724!=null) client.field_1724.method_7353(class_2561.method_43470(
                    "BrickCraft : rotation "+(BrickSelection.turn*90)+"°"),true);
            }
        });
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (hand != class_1268.field_5808 || !player.method_5998(hand).method_31574(BrickCraft.TOOL))
                return class_1269.field_5811;
            if (world.field_9236) {
                ClientPlayNetworking.send(new BrickActionPayload(
                    hit.method_17777(),hit.method_17780(),
                    (float)(hit.method_17784().field_1352-hit.method_17777().method_10263()),
                    (float)(hit.method_17784().field_1351-hit.method_17777().method_10264()),
                    (float)(hit.method_17784().field_1350-hit.method_17777().method_10260()),
                    player.method_5715(),false,BrickSelection.piece(0,0)));
            }
            return class_1269.field_5812;
        });
    }

    public static class_2338 resolveTarget(class_310 client) {
        if (client.field_1687 == null || !(client.field_1765 instanceof class_3965 hit)) return null;
        // Studio origin is placed NEXT TO a targeted normal block, vanilla-style.
        // A new model can also start from the top of an existing LEGO cell.
        if (client.field_1687.method_8320(hit.method_17777()).method_27852(BrickCraft.CELL))
            return hit.method_17780().method_10166().method_10178()
                    ? hit.method_17777().method_10084() : hit.method_17777().method_10093(hit.method_17780());
        return hit.method_17777().method_10093(hit.method_17780());
    }
}
