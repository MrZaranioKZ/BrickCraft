package fr.brickcraft.client;

import fr.brickcraft.client.PreciseLodPlanner.Candidate;
import fr.brickcraft.importer.LDrawProjectReader;
import fr.brickcraft.importer.LDrawProjectReader.Instance;
import fr.brickcraft.importer.PreciseReferenceMapper;
import fr.brickcraft.importer.PreciseWorldModel;
import fr.brickcraft.ldraw.LDrawLibrary;
import fr.brickcraft.world.PreciseDisplayEntity;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.*;
import java.util.Map.Entry;

/** Renders an anchored BCPX assembly. All transformations remain full LDraw matrices. */
public final class PreciseDisplayRenderer implements class_827<PreciseDisplayEntity> {
    private static final class_2960 WHITE=class_2960.method_60655("minecraft","textures/block/white_concrete.png");
    // Keep an LRU cache: the selection budget is PER FRAME, not a permanent decision
    // about which parts can ever be displayed in high detail.
    private final LinkedHashMap<String,LDrawLibrary.Mesh> cachedMeshes=new LinkedHashMap<>(96,.75f,true);
    private final Set<String> noMesh=new HashSet<>();
    private int totalCachedTriangles=0;
    private final int renderDistance;
    private final int maxRealTriangles;
    private final double meshRadius;
    private final int newMeshesPerFrame;
    private final int maxMeshTriangles;
    private final int cacheTriangleLimit;
    public PreciseDisplayRenderer(class_5614.class_5615 unused){
        java.nio.file.Path config=FabricLoader.getInstance().getConfigDir();
        renderDistance=BrickRenderDistanceConfig.load(config);
        java.util.Properties properties=new java.util.Properties();
        java.nio.file.Path file=config.resolve("brickcraft").resolve("precise-render.properties");
        try{
            java.nio.file.Files.createDirectories(file.getParent());
            if(java.nio.file.Files.isRegularFile(file))try(var input=java.nio.file.Files.newInputStream(file)){
                properties.load(input);
            }
            else{
                properties.setProperty("max_real_triangles","28000");
                properties.setProperty("mesh_radius_blocks","42");
                properties.setProperty("lod_profile","balanced"); // balanced, performance, photo, custom
                try(var out=java.nio.file.Files.newOutputStream(file)){
                    properties.store(out,"BrickCraft: 0.9.2 nearest-first LOD (restart Minecraft to apply)");
                }
            }
        }catch(java.io.IOException ignored){}
        // Existing manual numeric settings are retained in balanced/custom modes.
        // Photo mode deliberately spends more time and memory on large constructions.
        String profile=properties.getProperty("lod_profile","balanced").strip().toLowerCase(Locale.ROOT);
        int budget=clampInt(properties.getProperty("max_real_triangles"),28000,4000,250000);
        int radius=clampInt(properties.getProperty("mesh_radius_blocks"),42,8,160);
        int meshes=3, perMesh=6000, cache=360000;
        if(profile.equals("performance")){
            budget=16000;radius=32;meshes=2;perMesh=3000;cache=180000;
        } else if(profile.equals("photo")){
            budget=160000;radius=112;meshes=6;perMesh=12000;cache=650000;
        } else if(profile.equals("custom")){
            meshes=clampInt(properties.getProperty("new_meshes_per_frame"),3,1,12);
            perMesh=clampInt(properties.getProperty("max_triangles_per_mesh"),6000,500,20000);
            cache=clampInt(properties.getProperty("cache_triangle_limit"),360000,20000,900000);
        }
        maxRealTriangles=budget;meshRadius=radius;
        newMeshesPerFrame=meshes;maxMeshTriangles=perMesh;cacheTriangleLimit=cache;
    }
    private static int clampInt(String input,int fallback,int min,int max){
        try{return Math.max(min,Math.min(max,Integer.parseInt(input)));}
        catch(NumberFormatException ignored){return fallback;}
    }
    @Override public int method_33893(){return renderDistance;}
    @Override public boolean rendersOutsideBoundingBox(PreciseDisplayEntity be){return true;}

    private LDrawLibrary.Mesh getMesh(String id,int[] slots){
        LDrawLibrary.Mesh already=cachedMeshes.get(id);
        if(already!=null)return already;
        if(noMesh.contains(id)||slots[0]<=0)return null;
        slots[0]--;
        LDrawLibrary.Mesh mesh=LDrawLibrary.mesh(id);
        if(mesh==null || mesh.isEmpty() || mesh.triangles()>maxMeshTriangles ||
                mesh.triangles()>cacheTriangleLimit){
            noMesh.add(id);return null;
        }
        // Evict old meshes rather than blacklist a valid model when the cache is full.
        while(totalCachedTriangles+mesh.triangles()>cacheTriangleLimit && !cachedMeshes.isEmpty()){
            var iterator=cachedMeshes.entrySet().iterator();
            var oldest=iterator.next();
            totalCachedTriangles-=oldest.getValue().triangles();iterator.remove();
        }
        cachedMeshes.put(id,mesh);totalCachedTriangles+=mesh.triangles();return mesh;
    }

    /** Distance to the oriented part's enclosing world AABB, not its LDraw origin.
     * A large wall can start far away while a surface is directly in front of the camera.
     */
    private static double distanceSqToPart(LDrawProjectReader.Instance p,double[] b,
                PreciseWorldModel model,class_243 camera,double ox,double oy,double oz){
        double[] m=p.matrix();
        double cx=(b[0]+b[3])*.5,cy=(b[1]+b[4])*.5,cz=(b[2]+b[5])*.5;
        double hx=(b[3]-b[0])*.025,hy=(b[4]-b[1])*.025,hz=(b[5]-b[2])*.025;
        double wx=ox+(p.x()+m[0]*cx+m[1]*cy+m[2]*cz)/20-model.minX();
        double wy=oy-(p.y()+m[3]*cx+m[4]*cy+m[5]*cz)/20-model.minY();
        double wz=oz+(p.z()+m[6]*cx+m[7]*cy+m[8]*cz)/20-model.minZ();
        double ex=Math.abs(m[0])*hx+Math.abs(m[1])*hy+Math.abs(m[2])*hz;
        double ey=Math.abs(m[3])*hx+Math.abs(m[4])*hy+Math.abs(m[5])*hz;
        double ez=Math.abs(m[6])*hx+Math.abs(m[7])*hy+Math.abs(m[8])*hz;
        double dx=Math.max(0,Math.abs(camera.field_1352-wx)-ex);
        double dy=Math.max(0,Math.abs(camera.field_1351-wy)-ey);
        double dz=Math.max(0,Math.abs(camera.field_1350-wz)-ez);
        return dx*dx+dy*dy+dz*dz;
    }
    @Override public void render(PreciseDisplayEntity be,float tickDelta,class_4587 matrices,
                                 class_4597 provider,int light,int overlay){
        PreciseWorldModel model=be.model();if(model==null)return;
        // One consumer only, to avoid the old "Not building!" buffer lifecycle crash.
        class_4588 out=provider.getBuffer(class_1921.method_23580(WHITE));
        class_243 camera=class_310.method_1551().field_1773.method_19418().method_19326();
        double ox=be.method_11016().method_10263(),oy=be.method_11016().method_10264(),oz=be.method_11016().method_10260();
        List<LDrawProjectReader.Instance> parts=model.parts();
        List<PreciseLodPlanner.Candidate> candidates=new ArrayList<>(parts.size());
        // Phase 1: compute distances independently of MPD source order.
        for(int i=0;i<parts.size();i++){
            var p=parts.get(i);String id=PreciseReferenceMapper.geometryId(p.partId());
            if(id==null)continue;
            double[] bounds=LDrawLibrary.originalBounds(id);
            if(bounds==null)continue;
            double distanceSq=distanceSqToPart(p,bounds,model,camera,ox,oy,oz);
            candidates.add(new PreciseLodPlanner.Candidate(i,distanceSq));
        }
        // Phase 2: give the scarce triangle budget to the nearest pieces FIRST.
        // Do not draw yet: original traversal order stays unchanged for translucent faces.
        Map<Integer,LDrawLibrary.Mesh> detailed=new HashMap<>();
        int triangles=0;int[] slots={newMeshesPerFrame};
        for(var entry:PreciseLodPlanner.nearestFirst(candidates,meshRadius*meshRadius)){
            if(triangles>=maxRealTriangles)break;
            int i=entry.index();var p=parts.get(i);
            String id=PreciseReferenceMapper.geometryId(p.partId());
            LDrawLibrary.Mesh mesh=getMesh(id,slots);
            if(mesh!=null && triangles+mesh.triangles()<=maxRealTriangles){
                detailed.put(i,mesh);triangles+=mesh.triangles();
            }
        }
        // Phase 3: draw detailed/low-LOD parts using the fixed selection for this frame.
        for(int i=0;i<parts.size();i++){
            var p=parts.get(i);String id=PreciseReferenceMapper.geometryId(p.partId());
            if(id==null)continue;
            LDrawLibrary.Mesh mesh=detailed.get(i);
            if(mesh!=null){
                double[] bounds=LDrawLibrary.originalBounds(id);
                if(bounds!=null){drawMesh(out,matrices,p,mesh,bounds,model,light);continue;}
            }
            drawBox(out,matrices,p,id,model,light);
        }
    }
    /** One LDraw vertex, converted from original units through the source 3x3 matrix. */
    private static float[] transform(LDrawProjectReader.Instance p,PreciseWorldModel model,
                                     double[] m,double lx,double ly,double lz){
        return new float[]{
            (float)((p.x()+m[0]*lx+m[1]*ly+m[2]*lz)/20-model.minX()),
            (float)(-(p.y()+m[3]*lx+m[4]*ly+m[5]*lz)/20-model.minY()),
            (float)((p.z()+m[6]*lx+m[7]*ly+m[8]*lz)/20-model.minZ())
        };
    }
    private static int drawMesh(class_4588 out,class_4587 mat,LDrawProjectReader.Instance p,
                                LDrawLibrary.Mesh mesh,double[] bounds,PreciseWorldModel model,int light){
        float[] xyz=mesh.xyz();int[] faceColors=mesh.colors();double[] matrix=p.matrix();
        for(int i=0;i<mesh.triangles();i++){
            float[][] v=new float[3][3];
            for(int j=0;j<3;j++){
                int a=i*9+j*3;
                double x=bounds[0]+xyz[a]*20,y=bounds[4]-xyz[a+1]*20,z=bounds[2]+xyz[a+2]*20;
                v[j]=transform(p,model,matrix,x,y,z);
            }
            int color=LDrawLibrary.meshColor(faceColors[i],p.color(),LDrawLibrary.resolveColor(p.color(),0xD0D0D0));
            emitTriangle(out,mat,v[0],v[1],v[2],color,light);
            emitTriangle(out,mat,v[2],v[1],v[0],color,light);
        }
        return mesh.triangles();
    }
    private static void drawBox(class_4588 out,class_4587 mat,LDrawProjectReader.Instance p,
                                String id,PreciseWorldModel model,int light){
        double[] b=LDrawLibrary.originalBounds(id);
        if(b==null)return;
        double[] matrix=p.matrix();float[][] corners=new float[8][];
        for(int i=0;i<8;i++){
            double x=b[(i&1)==0?0:3],y=b[(i&2)==0?1:4],z=b[(i&4)==0?2:5];
            corners[i]=transform(p,model,matrix,x,y,z);
        }
        int color=LDrawLibrary.argb(p.color(),LDrawLibrary.resolveColor(p.color(),0xCCCCCC));
        int[][] sides={{0,1,3,2},{4,6,7,5},{0,4,5,1},{2,3,7,6},{0,2,6,4},{1,5,7,3}};
        for(int[] face:sides){
            emitTriangle(out,mat,corners[face[0]],corners[face[1]],corners[face[2]],color,light);
            emitTriangle(out,mat,corners[face[0]],corners[face[2]],corners[face[3]],color,light);
        }
    }
    private static void emitTriangle(class_4588 out,class_4587 mat,float[] a,float[] b,float[] c,
                                     int argb,int light){
        float ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2];
        float vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
        float nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx;
        float len=(float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if(len<1e-7f)return;
        nx/=len;ny/=len;nz/=len;
        float[][] v={a,b,c,c};
        for(int i=0;i<4;i++)out.method_56824(mat.method_23760(),v[i][0],v[i][1],v[i][2])
                .method_39415(argb).method_22913(i%2,i/2).method_22922(class_4608.field_21444).method_60803(light)
                .method_60831(mat.method_23760(),nx,ny,nz);
    }
}
