@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0TESTER_V0111_WINDOWS.ps1"
if errorlevel 1 pause
